# Foundry Arsenal — Bedrock development build 0.7.0

An unofficial Minecraft add-on created for Ethan Morgan. Includes 60 individually named weapon items, 24 functional attachments, seven ammunition families, six grenade types, six new ore deposits, five crafting stations and 125 station recipes, plus loot bunkers and four strategic missile tiers.

## Version 0.7 changes

- Confirmed hits, headshots and firearm defeats now have HUD cues and quiet optional sounds. Separate settings let you disable either.
- Original practice targets with ring scoring, personal range sessions and lifetime bullseye records. Newly generated bunkers and the relic include them. Craft a target with five oak planks, one redstone and one stick at a normal crafting table.
- Field Journal with six optional goals and modest, once-only rewards. Goals introduce reloading, workshop stations, attachments, practice, facility exploration and hostile mob combat. They do not gate recipes.
- Save up to eight visited facilities by operating a bunker switch or silo controller. Select one in the journal for compass direction and distance on your HUD.
- Recycle unwanted, unloaded weapons through Equipment. Confirmation consumes the weapon and returns one Steel Plate, one Polymer and the fitted attachments.

The design comparison and author-source links are in [DESIGN_REFERENCES.md](DESIGN_REFERENCES.md). These features adapt documented ideas from MrCrayfish's Gun Mod, FTB Quests, Waystones and Immersive Engineering for Bedrock. No third-party models or textures are included.

## Retained version 0.6 changes

- Rebuilt first-person gun calibration using a single inverse arm transform and a parent-before-child bone hierarchy. Generated axes are validated for all 60 weapons; actual Bedrock hand alignment still requires testing.
- Native press events start firing; stop-use, release and completion stop it. Late custom use callbacks cannot restart automatic fire. Unloading preserves ammunition in both game modes.
- Three main controller actions and three computer actions. Controller interaction automatically claims/links the silo and supplies a computer.
- Launch preparation opens the cover and waits for it, checks the route, then starts the ten-second countdown. Failed preparation and cancellation retain the missile.
- New relic sites survey their complete footprint and search elsewhere when water, frozen oceans, low ground or steep terrain is found.
- Three distinct relay, armory and expedition bunker themes. The relic facility gains a landing apron, radar, roof machinery, lighting, hazard trim and service-room details.
- Five craftable decorative blocks, plus protected-block and unloaded-chunk checks before relic repair.

See [CHANGELOG.md](CHANGELOG.md) for the full change list. Existing structures are retained; use a new test world for the new buildings and dry-land site search.

## Retained version 0.5 changes

- Revised hand transforms and muzzle-origin rays; visible installed optics. Client alignment still requires in-game testing.
- Creative and Survival reloads consume actual ammunition. Loaded rounds remain usable when inventory reserve reaches zero.
- Native 3×3 crafting grids at all five stations, with reversible packed ingredients preserving all 125 recipe costs.
- Staged entrance doors and a switch-operated silo cover, occupancy checks and a launch interlock.
- Relic repair action restores the shaft/foundation and upgrades modern relic covers. New structures include extra lighting.
- Apex initial damage falls linearly from 50 hearts at center to zero at 400 blocks, before armor/effects.

## Retained version 0.4 repairs

- Curated 60-weapon roster and seven reload families; hand-bound gun/computer geometry with property fallbacks.
- Native entity scaling keeps the missile base model visible without a client property query.
- TNT-style grenade and launcher explosions. Live laser refreshes every tick with short-lived particles; saved target stays locked when you look away.
- Five original 3D workbenches with legs, mats and tools. Eight silo decks and three lower service-room floors.
- Bunker attempt rate reduced approximately tenfold (1/4500 per variant per eligible chunk).
- Field Guide contains a 10-modpack and 10-mod/add-on reference review. Java projects are references, not dependencies.
- Sixty removed weapon IDs are not migrated. Use a new test world; existing structures are not replaced.

## Retained presentation features

- Replaced identical static view transforms with first-/third-person rigs, visible first-person gloves, recoil, cycling action/slide, animated magazine reload, cases and muzzle flash. Not individually authored replica animations for all 60 weapons.
- One Field Targeting Computer: Use opens the coordinate UI; choose Aim laser / lock new target, aim and Use to lock a surface. Sneak + Use returns to UI. Existing targeting-pad item IDs are retained.
- Original redesigned structures: shaped bunker halls, stepped roofs, observation tower, armory wing and interiors; circular silo shaft with service decks, observation/control annex and access ladder.
- Much leaner chest loot: 1–2 common supply rolls, optional 4–12 ammo, 10% component roll, and 4% rare item roll (1% gun / 3% upgrade). No chest diamonds, Netherite, power cells or missile cores. The one preloaded relic missile remains.
- Apex's cosmetic model is approximately 20 blocks tall, with a staged cylindrical body and tapered nose. Other tiers scale to about 5 / 8 / 13 blocks.
- Explosion: larger fireball, denser stem/cap particles, expanding dust ring, camera shake and a world-space growing cloud model. Per-player distant particles remain as a visibility fallback.
- Merged excavation prisms, near-impact ordering and next-region preloading. Per-tick maxima: 524,288 affected blocks, 512 calls, stopping after approximately 10 ms spent in the fill loop. This is a 32× increase in the configured block budget, NOT a measured real-game speedup. Native calls remain below 32,768 blocks.
- Old 0.2 jobs restart their current region on conversion without skipping cells. Computer status now distinguishes completed terrain from remaining fallout.

Use a new test world for the rebuilt relic site; existing buildings are not overwritten. Silos require a 3×3 clear launch route; validation checks up to 80 blocks above the controller. Use the controller repair action for an existing relic, then open its cover. Existing saved pads update to computers. The visual-property bridge extends the vanilla player behavior, which can conflict with other packs overriding minecraft:player; test this pack alone first.

The supplied mcworld contained only level.dat and four terrain database files. It had no resource/behavior packs or animation/model files to inspect. Reference research used the ActualGuns 3D author gallery, Simple Guns by Four and cmacey's military-base page. No third-party gun/build assets are bundled. The vanilla player behavior base is from Mojang bedrock-samples tag v1.21.120.4, with its original license notice in src/vendor and the behavior pack.

The included preview is an offline render of generated geometry. It does not establish client hand alignment or frame-rate performance. Client import, skin/arm alignment, effects and multiplayer remain unverified.

## Install

1. Build the project as described below, then open `output/Foundry_Arsenal_60.mcaddon` with Minecraft for Windows.
2. Create a new test world. Activate **Foundry Arsenal | 0.7** and its matching resource pack. Both pack versions must be **0.7.0**; preserved UUIDs and increased versions identify this as an update to 0.6.
3. Requires Bedrock 1.21.120 or newer with stable `@minecraft/server` 2.3.0 and `@minecraft/server-ui` 2.0.0. No native loader or experimental API dependency is included.
4. Read the Field Manual given on first join. Creative players can request any weapon and its ammunition through the catalogue.
5. Optional operator command: `/function foundry/demo`.

The HTML Field Guide is self-contained and includes the catalogue, all station recipes, controls and troubleshooting. No web connection is required to use it.

## Controls

- Use/right-click: fire. Hold Use for automatic weapons.
- Sneak: aim and scope zoom.
- Use an empty weapon: reload from matching ammunition in inventory.
- Field Manual or Maintenance Kit: equipment management, manual reload, unloading and attachment installation.
- The manual reload action selects the chosen weapon automatically if it is in hotbar slots 1–9. Inventory-only weapons must first be moved to the hotbar. Switching away cancels reloading.
- Unload before changing magazine attachments. Replaced attachments are returned.
- Field Manual → Field journal/tasks: view goals, claim rewards, select a saved facility, or change feedback/navigation settings.
- Shoot the printed face of a practice target with ordinary firearm rounds. Center scores 10, inner ring 7, outer ring 3 and edges 1. The stand and narrow sides do not score. Shotgun pellets score individually; explosive launchers do not score.
- Use a practice target with an empty hand to inspect/reset your range session. Lifetime bullseyes and task progress remain. The streak counts consecutive bullseyes among target hits.
- Equipment → select weapon → Recycle weapon: unload first, then confirm. Recycling permanently consumes that weapon.
- Stations: open the native crafting grid and recipe book. Pack large material quantities at a Foundry station before assembling the final item.

## Validation and limits

This is a downloadable development build, not a claim of completed Minecraft play-testing. The package was checked for archive integrity, JSON validity, references, crafting reachability and stable API type compatibility. Node tests cover ammo conservation, inventory affordability, attachments, state persistence, aiming math and damage falloff.

Remaining client checks: import, custom item-use events, automatic held fire, first-/third-person model alignment, scope reset, native station recipes, ore generation in new chunks, effects and multiplayer synchronization. Do not call the build in-game verified until those checks have been run.

Models are stylized block interpretations assembled from class-based geometry. Weapon names and finishes differ; this release does not contain 60 exact replica meshes or individually animated reloads. Installed optics change visible sight meshes; other attachments change stats and item lore. Goggles and vest have equipment effects without custom worn meshes.

Bullets use raycasts, while grenades and rockets use a script-driven swept movement simulation. Explosive handheld grenades and launcher rounds use native terrain-damaging explosions. Smoke and flash remain non-destructive. Silo missiles permanently excavate terrain. Smoke applies blindness within its radius rather than implementing volumetric rendering. Weapon values and recipes are fictional Minecraft balance and crafting rules, not real-world specifications or manufacturing instructions.

## Bunkers, silos and missiles

- Three random bunker variants contain weapons, rounds, upgrades and materials in newly generated Overworld land chunks.
- One relic site is reserved per world, approximately 1,400–2,100 blocks in X and 1,100–1,800 in Z from initial spawn. The script places it with one Apex ICBM using a temporary ticking area. Its entrance and pending/error status appear in the Field Manual. Taking or firing its missile does not replenish it. Placement may replace existing terrain/builds at that reserved site, so use a new test world.
- The Missile Fabricator makes expensive modules, missiles, silo blocks and targeting tools. Apex requires two Nether Stars, eight Netherite Ingots and sixteen Echo Shards in its Stellar Cores, plus the additional modules and diamond blocks listed in the guide.
- Silo layout: complete 5×5 casing foundation, controller at center one block above, four stabilizers at corners at controller height, and clear 3×3 shaft through the first 80 blocks above (or to world height). Open the cover switch and wait for motion to finish. Bind and load using the controller.
- Laser Designator: Use on a surface within 240 blocks. Sneak + Use opens the targeting pad. The pad also accepts exact XYZ and shows chunk grid, horizontal distance, damage radius, separation margin and final confirmation.
- Controller interaction automatically claims/links your silo. Choose **Target & launch**, lock a surface or enter XYZ, then **Launch missile** and confirm. Preparation opens the cover and waits for the route to be ready before the ten-second cancelable countdown.
- Launch/descent model, exhaust, boom, flash, shockwave and mushroom-cloud effects. Four tiers share one stylized missile model with scaled effects. Distant explosion particles are projected separately per observer to remain visible at normal render distances.
- Craters: Kestrel 24 wide/8 deep; Tempest 64/18; Titan 160/40; Apex 500/100. All are circular bowls. The largest also clears up to 80 blocks above impact, respects bedrock/world limits, and applies temporary fallout effects. It does not create a 500-square footprint or a cylinder with uniform depth.
- Recommended separation: 40 / 75 / 160 / 500 blocks respectively. Horizontal distance describes the modeled blast, not immunity to falling terrain, lava or other hazards.
- One strike at a time; permanent terrain work runs in saved batches with 128×128 region loading. Maximum 512 fills / 524,288 blocks per tick with a 10 ms work timer; every fill remains below 32,768 blocks. Errors pause and retry without silently skipping unloaded terrain. Resume after a world reload; large strikes can take minutes and cause lag.
- Remote features require script-issued ticking-area commands to succeed and one free ticking-area slot, plus a second optional slot for preloading (the add-on removes only its own areas). If blocked, no new launch is consumed; existing work pauses and site generation remains pending. Status screens explain failures.
- Optional operator supplies: `/function foundry/siege_demo`. This never launches automatically. Use `/function foundry/demo` for the original guns.

Client checks still needed: structure generation/loot, item use, target forms, chunk-loading permissions, all missile visuals, terrain performance, save/reload, multiplayer and pack import. Automated tests cannot establish these.

## Bedrock smoke test

1. Import the rebuilt add-on and confirm that both activated packs show version 0.7.0. Test this pack alone in a new world.
2. Run `/function foundry/demo`, reload an automatic weapon, and check hip, iron-sight and scoped alignment in first and third person.
3. Hold Use to fire, release it and confirm that ammunition stops decreasing immediately. Repeat after switching slots and opening the manual.
4. Reload and unload in Creative and Survival; the remaining magazine rounds must return to inventory.
5. Wait for the relic location in the Field Manual. Check that the entire entrance, surface apron and cover are on dry land; inspect the bunkers in new chunks.
6. For a small missile test, build a silo or unload the relic payload and load a Kestrel. Select a distant test target and launch with the cover closed: it should open automatically before countdown. Cancel once and verify the missile remains, then repeat to test flight. Remote strikes need working ticking-area commands.
7. Place a practice target, shoot its center and rings, then rotate it and repeat. Shoot the stand and narrow sides; they should not score. Reset with an empty hand and check that lifetime bullseyes remain.
8. Open Field journal/tasks in the manual. Complete and claim a reload reward once, revisit it, and save/reload: it must not pay again. Kill a hostile with a firearm and check the defeat count; melee kills and player defeats must not advance the hostile goal.
9. Operate a bunker switch or controller, select its saved location, and walk away: compass direction/distance should update. Toggle feedback, sounds and navigation separately.
10. Recycle an unloaded weapon with attachments. Cancel once, then confirm: exactly one weapon disappears, its fitted attachments return, and no ammunition is created. A loaded weapon must be refused.
11. Check save/reload and multiplayer ownership, gun input, launch synchronization and the content log. Record any rendering/input differences with the exact game version.

## Rebuild

Requirements: Python 3.10+ with Pillow, FFmpeg with libvorbis, DejaVu Sans fonts for the preview renderer, and Node.js 20+.

Run these commands from the repository root. On Debian/Ubuntu, install the system tools with `sudo apt-get update && sudo apt-get install -y ffmpeg fonts-dejavu-core python3-venv`.

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
npm ci --ignore-scripts
npm run check
```

On Windows, activate the virtual environment with `.venv\Scripts\Activate.ps1` in PowerShell and install FFmpeg separately. The preview renderer currently looks for DejaVu Sans in the Linux system font directory; WSL or the cloud environment supports the full build.

`npm run check` rebuilds the add-on, checks the generated scripts against the stable Bedrock API types, and runs the gameplay tests and pack validators. For later sessions, activate `.venv` again before running the commands. Use `npm run build` for a rebuild only, or `npm run package:source` to validate and create an editable source ZIP.

Generated downloads are written to `output/`:

- `Foundry_Arsenal_60.mcaddon`: importable behavior and resource packs.
- `Foundry_Arsenal_Field_Guide.html`: offline catalogue, recipes and controls.
- `Foundry_Arsenal_Preview.png`: offline geometry preview.
- `validation.json`: automated validation report; Minecraft play-testing is recorded as unverified.
- `Foundry_Arsenal_Source.zip`: created by `npm run package:source`.

The `build/Foundry_Arsenal_BP` and `build/Foundry_Arsenal_RP` directories are included for inspection and direct editing. A rebuild replaces `build/`, so make lasting changes in `src/`. Dependencies, caches and generated downloads are excluded from Git. No web server or database is required; the add-on runs inside Minecraft.

`src/catalog.py` owns weapon definitions, upgrades and recipes. `src/main.js` owns Bedrock integration. `src/core.js` owns testable gameplay calculations. `src/experience.js` and `src/experience_core.js` own the Field Journal, tasks, feedback, range scores, facility navigation and recycling rules. `src/release.py` defines the current release version. `src/siege_catalog.py`, `src/siege_core.js`, `src/siege.js` and `src/siege_build.py` own the expansion data, geometry, runtime and assets. The generator produces the behavior pack, resource pack, `.mcaddon`, HTML guide and preview image.

The release ZIP also includes the generated packs for direct editing. Preserve the manifest UUIDs when releasing updates so saved item dynamic properties continue to match the pack identity; increment pack and dependency versions together.

## Troubleshooting

Enable Minecraft's content log in Creator settings if the import or world load fails. Supply the exact game version and first Foundry-related error. Missing ores require newly generated Overworld chunks. A gun with zero loaded rounds must be reloaded with its matching ammunition. If a form is busy, release Use and close chat before reopening it.

Sources: Microsoft's Bedrock Creator documentation for Custom Components v2, ItemCustomComponent, attachables, ore features, and the official `@minecraft/server` / `@minecraft/server-ui` type declarations. All included pixel textures, block models, particles and synthesized sound effects were generated for this project. No manufacturer affiliation or endorsement is implied.
