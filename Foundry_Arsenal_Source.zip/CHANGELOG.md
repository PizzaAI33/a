# Foundry Arsenal 0.7.0

- Add confirmed hit, headshot and firearm defeat cues beside the ammunition HUD. Feedback sounds and visual cues can be toggled separately; shotgun pellets share one sound cue per tick.
- Add an original craftable practice target, printed on both sides, with ring scoring that follows placement rotation. Ignore its stand and narrow sides. Normal ammunition is required; session reset preserves lifetime progress. Place targets in newly generated bunkers and the relic facility.
- Add a persistent Field Journal with six optional, once-only reward tasks covering reloading, workshops, attachments, practice, exploration and hostile mob defeats. Recipes remain available independently of the tasks.
- Remember up to eight operated facilities and select one for compass direction and distance on the HUD. No teleportation or undiscovered structure reveal is added.
- Recycle an unloaded weapon with confirmation for one Steel Plate, one Polymer and its fitted attachments. Recheck the actual item instance and magazine after confirmation, remove it once, and cancel its pending firing/reload state.
- Tighten confirmed defeat attribution to recent projectile damage by the same player. Nonhostile and player defeats do not advance the hostile mob task.
- Compare author-documented features from MrCrayfish's Gun Mod, FTB Quests, Waystones and Immersive Engineering; record sources and adaptations in DESIGN_REFERENCES.md.
- Preserve the earlier gun, release-input, missile-launch, dry-land and facility changes. Increase matching pack/module/dependency versions to 0.7.0 while retaining UUIDs.

Automated checks cover gameplay, assets, structures, crafting, archive integrity and stable Bedrock API compatibility. Actual Minecraft rendering, held input, native event timing and multiplayer remain client checks.

## Retained 0.6.0 changes

- Replace the gun rig's forward-referenced cancellation bones with one inverse native arm transform, preserving recoil, reloads and installed optics. Validate the generated camera axes for all 60 weapons.
- Drive gunfire from native item press events. Stop automatic and burst fire on release, stop-use and completion; ignore late custom use callbacks. Initialize the weapon instance before held-fire tracking, and stop retrying an empty magazine every tick.
- Return unloaded ammunition in Creative as well as Survival.
- Reduce both the controller and targeting computer to three primary actions. Controller interaction claims/links the silo and supplies a computer automatically.
- Add launch preparation that opens the cover, waits for motion, checks the silo and only then consumes the stored missile and starts the countdown. Failed preparation and cancellation retain the payload.
- Breaking a controller during launch preparation/countdown cancels the job and returns its missile once, keeping storage empty.
- Survey every column of a proposed relic footprint in bounded batches. Reject liquids, frozen oceans, low ground and steep terrain; persist a search for another site.
- Give the three bunkers relay, armory and expedition themes. Add a silo landing apron, radar, roof equipment, warning borders, lighting and detailed service areas.
- Add five craftable decorative blocks: vent grille, hazard panel, status screen, facility light and radar dish.
- Check the shaft, foundation, stabilizers and replacement switch before relic repair changes any blocks. Preserve all protected command-block variants and refuse unloaded required blocks.
- Keep the original manifest UUIDs and increase both pack/module/dependency versions together so the client can import the update.

Automated checks cover gameplay logic, generated structures, recipes, archives, stable API types and documented model transforms. Actual Bedrock rendering, input, remote chunk-loading permissions, performance and multiplayer remain client checks.
