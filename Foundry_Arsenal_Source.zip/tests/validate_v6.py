"""Validate generated gun axes, rig ordering, facility assets and release identity."""
from pathlib import Path
import json, math, re, sys
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'src'))
from catalog import GUNS
from release import VERSION, VERSION_TAG
from render_review import NBT
bp=root/'build/Foundry_Arsenal_BP';rp=root/'build/Foundry_Arsenal_RP'
checks=0
def check(ok,message):
 global checks
 checks+=1
 assert ok,message
def euler(angles):
 x,y,z=map(math.radians,angles)
 cx,sx,cy,sy,cz,sz=math.cos(x),math.sin(x),math.cos(y),math.sin(y),math.cos(z),math.sin(z)
 return [[cz*cy,cz*sy*sx-sz*cx,cz*sy*cx+sz*sx],[sz*cy,sz*sy*sx+cz*cx,sz*sy*cx-cz*sx],[-sy,cy*sx,cy*cx]]
native=euler([95,-45,115])
animations=json.loads((rp/'animations/guns.animation.json').read_text())['animations']
for gun in GUNS:
 geo=json.loads((rp/'models/entity'/f'{gun["id"]}.geo.json').read_text())
 check(geo['format_version']=='1.16.0','Bone binding format')
 bones=geo['minecraft:geometry'][0]['bones'];seen=set()
 for bone in bones:
  check('parent' not in bone or bone['parent'] in seen,'Parent must precede child: '+gun['id']+'/'+bone['name']);seen.add(bone['name'])
 check(not any(name.startswith('view_cancel_') for name in seen),'No forward-referenced calibration bones')
 correction=euler(animations['animation.foundry.hold_'+gun['id']]['bones']['mount']['rotation'])
 composed=[[sum(native[i][k]*correction[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
 for i in range(3):
  for j in range(3):check(abs(composed[i][j]-(1 if i==j else 0))<1e-10,'Camera-space gun axis: '+gun['id'])
for pack in [bp,rp]:
 data=json.loads((pack/'manifest.json').read_text());check(data['header']['version']==VERSION,'Release version')
 check(all(module['version']==VERSION for module in data['modules']),'Module versions')
 check(all(dep['version']==VERSION for dep in data.get('dependencies',[]) if 'uuid' in dep),'Pack dependency versions')
for name in ['vent_grille','hazard_trim','status_screen','facility_light','radar_dish']:
 check((bp/'blocks'/f'{name}.json').is_file(),'Decorative block '+name)
 check((rp/'textures/blocks'/f'{name}.png').is_file(),'Decorative texture '+name)
 check((bp/'recipes'/f'{name}.json').is_file(),'Craftable decoration '+name)
palettes=[]
for name in ['bunker_0','bunker_1','bunker_2','relic_silo']:
 structure=NBT(bp/'structures/foundry'/f'{name}.mcstructure').read()
 palette={b['name'] for b in structure['structure']['palette']['default']['block_palette']};palettes.append(palette)
 check({'foundry:hazard_trim','foundry:status_screen','foundry:facility_light'}<=palette,'Detailed facility: '+name)
check(len({frozenset(p) for p in palettes[:3]})==3,'Three distinct bunker themes')
tap=(root/'output/node-tests.tap').read_text()
summary={name:int(re.search(r'^# '+name+r' (\d+)$',tap,re.M).group(1)) for name in ['tests','pass','fail']}
check(summary['tests']==summary['pass'] and summary['fail']==0,'Gameplay test results')
report=json.loads((root/'output/validation.json').read_text())
report.update(v6_checks=checks,logic_tests=summary['tests'],version=VERSION_TAG,gun_axes='PASS against documented native arm frame; client verification pending',dry_land_generation='Full footprint survey regression PASS',launch_preparation='Closed-cover opening/countdown/blocked-launch/cancel regression PASS')
(root/'output/validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(f'PASS: {checks} gun-axis, bone-order, version and facility checks; {summary["tests"]} gameplay tests')
