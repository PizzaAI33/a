from pathlib import Path
import json,zipfile,sys,re,io
ROOT=Path(__file__).resolve().parents[1];BP=ROOT/'build/Foundry_Arsenal_BP';RP=ROOT/'build/Foundry_Arsenal_RP'
sys.path.insert(0,str(ROOT/'src'))
from catalog import GUNS,ATTACHMENTS,RECIPES,ORES,STATIONS
errors=[];checks=0
def check(v,msg):
 global checks
 checks+=1
 if not v:errors.append(msg)
files=list(BP.rglob('*.json'))+list(RP.rglob('*.json'))
data={p:json.loads(p.read_text()) for p in files}
items={v['minecraft:item']['description']['identifier'] for p,v in data.items() if 'minecraft:item' in v}
blocks={v['minecraft:block']['description']['identifier'] for p,v in data.items() if 'minecraft:block' in v}
known=items|blocks
atlas=json.loads((RP/'textures/item_texture.json').read_text())['texture_data']
terrain=json.loads((RP/'textures/terrain_texture.json').read_text())['texture_data']
for name,v in atlas.items():check((RP/(v['textures']+'.png')).is_file(),'Missing item texture '+name)
for name,v in terrain.items():check((RP/(v['textures']+'.png')).is_file(),'Missing terrain texture '+name)
for p,v in data.items():
 if 'minecraft:item' in v:
  c=v['minecraft:item']['components'];check(c.get('minecraft:icon') in atlas,'Missing icon '+str(p))
 if 'minecraft:block' in v:
  c=v['minecraft:block']['components'];check((BP/c['minecraft:loot']).is_file(),'Missing loot '+str(p))
 if 'minecraft:attachable' in v:
  desc=v['minecraft:attachable']['description'];check(desc['identifier'] in items,'Unknown attachable item');check((RP/(desc['textures']['default']+'.png')).is_file(),'Missing model texture')
 if 'minecraft:ore_feature' in v:
  for rule in v['minecraft:ore_feature']['replace_rules']:check(rule['places_block'] in blocks,'Unknown ore block')
 if 'minecraft:feature_rules' in v:
  feature=v['minecraft:feature_rules']['description']['places_feature'].split(':')[1];check((BP/'features'/(feature+'.json')).is_file(),'Missing ore feature')
for r in RECIPES:
 check(r['output'] in known,'Unknown recipe result '+r['output']);check('foundry:'+r['station'] in blocks,'Unknown station')
 for id in r['inputs']:check(id.startswith('minecraft:') or id in known,'Unknown ingredient '+id)
for g in GUNS:
 check('foundry:'+g['id'] in items,'Missing gun '+g['id']);check((RP/'attachables'/(g['id']+'.json')).is_file(),'Missing held model '+g['id']);check('foundry:'+g['ammo'] in items,'Missing ammunition '+g['id'])
for p in BP.rglob('*.mcfunction'):
 for id in re.findall(r'give @s (foundry:\w+)',p.read_text()):check(id in known,'Unknown function item '+id)
# Reachability of every custom recipe input, starting with resources from ore drops.
reachable={id for id in known if id.startswith('foundry:raw_')}|{'foundry:sulfur_dust','foundry:fluxite_crystal','foundry:field_manual'}|{f'foundry:{k}_ingot' for k in ['zinc','cobalt','titanium','tungsten']}
for _ in range(30):
 for r in RECIPES:
  if all(i.startswith('minecraft:') or i in reachable for i in r['inputs']):reachable.add(r['output'])
for g in GUNS:check('foundry:'+g['id'] in reachable,'Uncraftable weapon '+g['id'])
for r in RECIPES:check(r['output'] in reachable,'Uncraftable recipe '+r['id'])
bp=json.loads((BP/'manifest.json').read_text());rp=json.loads((RP/'manifest.json').read_text())
check(bp['dependencies'][0]['uuid']==rp['header']['uuid'],'Pack dependency mismatch')
uuids=[p['header']['uuid'] for p in [bp,rp]]+[m['uuid'] for p in [bp,rp] for m in p['modules']];check(len(uuids)==len(set(uuids)),'Duplicate UUID')
with zipfile.ZipFile(ROOT/'output/Foundry_Arsenal_60.mcaddon') as outer:
 check(outer.testzip() is None,'Invalid mcaddon CRC');check(len(outer.namelist())==2,'Expected two embedded packs')
 for entry in outer.namelist():
  with zipfile.ZipFile(io.BytesIO(outer.read(entry))) as inner:
   check(inner.testzip() is None,'Invalid nested pack CRC');check('manifest.json' in inner.namelist(),'No root manifest')
   check(not any(x.startswith('/') or '..' in Path(x).parts for x in inner.namelist()),'Unsafe archive paths')
report={'status':'PASS' if not errors else 'FAIL','checks':checks,'json_files':len(files),'guns':len(GUNS),'attachments':len(ATTACHMENTS),'ores':len(ORES),'stations':len(STATIONS),'station_recipes':len(RECIPES),'errors':errors,'in_game_tested':False}
(ROOT/'output/validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));sys.exit(bool(errors))
