from pathlib import Path
from PIL import Image
import json,sys
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'src'))
from catalog import GUNS
bp=root/'build/Foundry_Arsenal_BP';rp=root/'build/Foundry_Arsenal_RP'
checks=0
def check(x,message):
 global checks
 checks+=1
 assert x,message
geometries={}
for p in rp.glob('models/**/*.json'):
 for g in json.loads(p.read_text())['minecraft:geometry']:geometries[g['description']['identifier']]=g
controllers={k for p in rp.glob('render_controllers/*.json') for k in json.loads(p.read_text())['render_controllers']}
for p in list(rp.glob('attachables/*.json'))+list(rp.glob('entity/*.json')):
 j=json.loads(p.read_text());desc=j.get('minecraft:attachable',j.get('minecraft:client_entity'))['description']
 for g in desc.get('geometry',{}).values():check(g in geometries,'Undefined geometry '+g)
 for name in desc.get('render_controllers',[]):
  if isinstance(name,str):check(name in controllers,'Undefined render controller '+name)
 for tex in desc.get('textures',{}).values():
  im=Image.open(rp/(tex+'.png'));check(all(v>0 and v&(v-1)==0 for v in im.size),'Non-power-of-two entity texture '+tex)
for g in GUNS:
 geo=geometries['geometry.foundry.'+g['id']];mount=geo['bones'][0]
 check(mount['binding']=='query.item_slot_to_bone_name(context.item_slot)','Hand binding '+g['id'])
 check('scale' not in mount,'Visible static base')
for p in bp.glob('feature_rules/bunker*.json'):
 chance=json.loads(p.read_text())['minecraft:feature_rules']['distribution']['scatter_chance'];check(chance=={'numerator':1,'denominator':4500},'Rare bunker chance')
for id in ['gunsmith_bench','ammo_press','attachment_bench','alloy_forge','missile_fabricator']:
 c=json.loads((bp/'blocks'/f'{id}.json').read_text())['minecraft:block']['components'];check(c['minecraft:geometry'] in geometries,'Workbench model exists');check('minecraft:crafting_table' in c and 'foundry:station' not in c,'Native crafting interaction')
a=json.loads((rp/'animations/missile.animation.json').read_text())['animations'];check(a['animation.foundry.missile_orientation']['bones']['root']['scale']==1,'Missile visible without property lookup')
e=json.loads((bp/'entities/silo_missile.json').read_text())['minecraft:entity']
for id in ['kestrel_missile','tempest_missile','titan_missile','apex_icbm']:
 check(e['component_groups']['foundry:size_'+id]['minecraft:scale']['value']>0,'Native missile size')
beam=json.loads((rp/'particles/laser_beam.json').read_text())['particle_effect']['components'];check(beam['minecraft:particle_lifetime_expression']['max_lifetime']<.1,'No long laser afterimage')
report=json.loads((root/'output/validation.json').read_text());report['revision_checks']=checks;report['logic_tests']=25;report['reference_projects']={'modpacks':10,'mods_and_addons':10};(root/'output/validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(f'PASS: {checks} binding, texture, entity, workbench, density and laser regression checks')
