import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import {impactDamage} from '../src/siege_core.js';
import {siloRequirements} from '../src/siege_core.js';
import {muzzlePoint} from '../build/Foundry_Arsenal_BP/scripts/weapon_view.js';
import {VIEW} from '../build/Foundry_Arsenal_BP/scripts/view_data.js';
const main=readFileSync(new URL('../src/main.js',import.meta.url),'utf8');
const reloadSource=main.slice(main.indexOf('function reload(p)'),main.indexOf('function rayShot(p,s)'));
test('Creative cannot reload from zero reserve; loaded rounds remain real magazine state',()=>{
 const g={ammo:'light_rounds',name:'Glock 17'},r={reload:null},state={uid:'test',loaded:0};let messages=0;
 const context={ATTACHMENTS:{},p:{selectedSlotIndex:0},selected:()=>({typeId:'foundry:glock_17'}),gunMap:new Map([['foundry:glock_17',g]]),rt:()=>r,ensureGun:()=>state,stats:()=>({capacity:17,reload:30}),count:()=>0,creative:()=>true,reloadPlan:(loaded,cap,reserve)=>Math.min(cap-loaded,reserve),message:()=>messages++,AMMO:{light_rounds:'Light rounds'},system:{currentTick:10},sound(){}};
 vm.runInNewContext(reloadSource+';reload(p)',context);assert.equal(r.reload,null);assert.equal(state.loaded,0);assert.equal(messages,1);
});
test('reload completion consumes matching inventory rounds even in Creative',()=>{
 const state={uid:'test',loaded:0},item={typeId:'foundry:glock_17'},r={reload:{slot:0,uid:'test',type:item.typeId,end:10}},costs=[];
 vm.runInNewContext(reloadSource+';finishReload(p,r,item,g,state)',{ATTACHMENTS:{},p:{selectedSlotIndex:0},r,item,g:{ammo:'light_rounds'},state,system:{currentTick:11},stats:()=>({capacity:17}),reloadPlan:(l,c,n)=>Math.min(c-l,n),count:()=>5,creative:()=>true,consume:(p,c)=>{costs.push(c);return true;},writeGun(){},recordMilestone(){},sound(){}});
 assert.equal(state.loaded,5);assert.equal(costs.length,1);assert.equal(costs[0]['foundry:light_rounds'],5);assert.equal(r.reload,null);
});
test('unloading preserves consumed ammunition in Creative and Survival',async()=>{
 const source=main.slice(main.indexOf('async function equipmentMenu(p)'),main.indexOf('async function fitAttachment(p,entry,uid)'));
 class Form{title(){return this;}body(){return this;}button(){return this;}}
 for(const isCreative of [true,false])for(const loaded of [0,5,17]){
  let state={uid:'test',loaded,wear:0,attachments:{}},selection=0;const returned=[];
  const item={typeId:'foundry:glock_17'},g={name:'Glock 17',ammo:'light_rounds'};
  const context={p:{id:'player'},ActionFormData:Form,inv:()=>({size:1,getItem:()=>item}),gunMap:new Map([[item.typeId,g]]),gunState:()=>({...state}),stats:()=>({capacity:17}),ATTACHMENTS:{},show:async()=>({canceled:false,selection:selection++===0?0:1}),writeGun:(p,slot,item,next)=>{state=next;},creative:()=>isCreative,give:(p,id,n)=>returned.push({id,n}),message(){}};
  await vm.runInNewContext(source+';equipmentMenu(p)',context);
  assert.equal(state.loaded,0);
  assert.deepEqual(returned,loaded?[{id:'foundry:light_rounds',n:loaded}]:[]);
 }
});

function relicRepairFixture(layout=3){
 const source=readFileSync(new URL('../src/siege.js',import.meta.url),'utf8');
 const repair=source.slice(source.indexOf('async function repairRelic(p,s)'));
 const blocks=new Map(),changes=[],messages=[];
 const key=p=>`${p.x},${p.y},${p.z}`;
 const blockAt=p=>{
  const k=key(p);
  if(!blocks.has(k))blocks.set(k,{location:{...p},typeId:'minecraft:stone',setType(type){changes.push({location:this.location,type});this.typeId=type;}});
  return blocks.get(k);
 };
 const s={id:'relic',pos:{x:30,y:3,z:26}},dim={getBlock:blockAt};
 class Form{title(){return this;}body(){return this;}button1(){return this;}button2(){return this;}}
 const context={p:{},s,site:{phase:'done',layout},sid:()=>s.id,sitePoint:()=>s.pos,MessageFormData:Form,H:{show:async()=>({canceled:false,selection:0})},near:()=>true,allowed:()=>true,entry:()=>({active:false}),siloRequirements,d:()=>dim,tell:(p,m)=>messages.push(m),coords:p=>key(p)};
 return {s,blocks,changes,messages,blockAt,run:()=>vm.runInNewContext(repair+';repairRelic(p,s)',context)};
}
test('relic repair refuses protected or unloaded blocks before changing the world',async()=>{
 const protectedTypes=['minecraft:bedrock','minecraft:barrier','minecraft:command_block','minecraft:chain_command_block','minecraft:repeating_command_block','minecraft:structure_block'];
 for(const part of ['shaft','foundation','stabilizer','switch'])for(const type of [...protectedTypes,'unloaded']){
  const f=relicRepairFixture(),p=f.s.pos;
  const position=part==='shaft'?{x:p.x,y:p.y+1,z:p.z}:part==='foundation'?{x:p.x,y:p.y-1,z:p.z}:part==='stabilizer'?{x:p.x-2,y:p.y,z:p.z-2}:{x:p.x-10,y:p.y+34,z:p.z};
  const block=f.blockAt(position);
  if(type==='unloaded')f.blocks.set(`${position.x},${position.y},${position.z}`,undefined);else block.typeId=type;
  await f.run();
  assert.equal(f.changes.length,0,`${part}: ${type}`);
  assert(f.messages.some(m=>m.includes(type==='unloaded'?'not loaded':'protected block')),`${part}: ${type}`);
 }
});
test('relic repair restores the shaft and foundation in legacy and modern layouts',async()=>{
 for(const layout of [2,3]){
  const f=relicRepairFixture(layout),p=f.s.pos,req=siloRequirements(p,23);
  await f.run();
  assert(req.base.every(q=>f.blockAt(q).typeId==='foundry:silo_casing'));
  assert(req.stabilizers.every(q=>f.blockAt(q).typeId==='foundry:silo_stabilizer'));
  assert.equal(f.blockAt({x:p.x,y:p.y+1,z:p.z}).typeId,'minecraft:air');
  if(layout===3){assert.equal(f.blockAt({x:p.x,y:p.y+33,z:p.z}).typeId,'foundry:blast_panel');assert.equal(f.blockAt({x:p.x-10,y:p.y+34,z:p.z}).typeId,'foundry:hatch_switch');}
  assert(f.messages.some(m=>m.includes('route repaired')));
 }
});
test('Apex initial damage falls from 50 hearts to zero and never becomes negative',()=>{
 for(const [d,health] of [[0,100],[100,75],[200,50],[300,25],[400,0],[900,0]])assert.equal(impactDamage(d,400,100),health);
});
test('muzzle follows camera yaw and pitch; hip, scope and iron offsets remain distinct',()=>{
 for(const yaw of [0,90,180,270])for(const pitch of [-60,0,60]){
  const yr=yaw*Math.PI/180,pr=pitch*Math.PI/180,v={x:-Math.sin(yr)*Math.cos(pr),y:-Math.sin(pr),z:Math.cos(yr)*Math.cos(pr)};
  const p={isSneaking:false,getHeadLocation:()=>({x:0,y:0,z:0}),getRotation:()=>({x:pitch,y:yaw}),getViewDirection:()=>v,getProperty:()=>0,dimension:{getBlockFromRay:()=>null}};
  const q=muzzlePoint(p,{id:'glock_17'}),cfg=VIEW.glock_17;
  const dot=q.x*v.x+q.y*v.y+q.z*v.z;assert(Math.abs(dot-cfg.hip[2])<1e-8);
  p.isSneaking=true;const iron=muzzlePoint(p,{id:'glock_17'});p.getProperty=()=>4;const scoped=muzzlePoint(p,{id:'glock_17'});assert(Math.hypot(iron.x-scoped.x,iron.y-scoped.y,iron.z-scoped.z)>.01);
 }
});
test('near wall clamps muzzle on player side instead of allowing a shot through it',()=>{
 const p={isSneaking:true,getHeadLocation:()=>({x:0,y:0,z:0}),getRotation:()=>({x:0,y:0}),getViewDirection:()=>({x:0,y:0,z:1}),getProperty:()=>1,dimension:{getBlockFromRay:()=>({block:{x:0,y:0,z:0},faceLocation:{x:0,y:0,z:.2}})}};
 assert(muzzlePoint(p,{id:'glock_17'}).z<.2);
});
function doorFixture(hatch=false){
 const source=readFileSync(new URL('../src/doors.js',import.meta.url),'utf8').replace(/^import .*?;\n/,'').replace(/export /g,'');
 const props=new Map(),blocks=new Map();let interval,load,startup,component;const entities=[],messages=[];
 const key=p=>`${p.x},${p.y},${p.z}`;
 const dimension={id:'minecraft:overworld',getBlock(p){const k=key(p);if(!blocks.has(k))blocks.set(k,{typeId:'minecraft:air',setType(t){this.typeId=t;}});return blocks.get(k);},getEntities:()=>entities,playSound(){}};
 const block={typeId:hatch?'foundry:hatch_switch':'foundry:bunker_switch',location:{x:0,y:5,z:0},dimension};
 const world={getDynamicProperty:k=>props.get(k),setDynamicProperty:(k,v)=>props.set(k,v),getDimension:()=>dimension,afterEvents:{worldLoad:{subscribe:f=>load=f}}};
 const system={beforeEvents:{startup:{subscribe:f=>startup=f}},run:f=>f(),runInterval:f=>interval=f};
 vm.runInNewContext(source,{world,system,console});startup({blockComponentRegistry:{registerCustomComponent:(k,c)=>component=c}});load();
 return {props,blocks,entities,messages,dimension,block,step:()=>interval(),use:()=>component.onPlayerInteract({block,player:{sendMessage:s=>messages.push(s)}})};
}
test('door closes and opens in stages, persists completion, and refuses occupied closure',()=>{
 const f=doorFixture();f.use();for(let n=0;n<3;n++)f.step();assert.equal([...f.blocks.values()].filter(b=>b.typeId==='foundry:blast_panel').length,24);
 assert.equal(f.props.get('foundry:door_motions_v1'),'[]');f.use();f.step();assert.equal([...f.blocks.values()].filter(b=>b.typeId==='foundry:blast_panel').length,16);
 f.step();f.step();assert.equal([...f.blocks.values()].filter(b=>b.typeId==='foundry:blast_panel').length,0);
 f.entities.push({location:{x:2,y:5,z:1},getComponent:()=>({})});f.use();assert(f.messages.at(-1).includes('cannot close'));assert.equal(f.props.get('foundry:door_motions_v1'),'[]');
});
test('hatch launch interlock prevents closure; foreign blocks are preserved',()=>{
 const f=doorFixture(true);f.props.set('foundry:strike_v2',JSON.stringify({phase:'countdown',start:{x:10,z:0}}));f.use();assert(f.messages.at(-1).includes('interlock'));assert.equal(f.props.get('foundry:door_motions_v1'),undefined);
 f.props.delete('foundry:strike_v2');f.dimension.getBlock({x:2,y:4,z:-8}).setType('minecraft:stone');f.use();assert(f.messages.at(-1).includes('other blocks'));assert.equal(f.dimension.getBlock({x:2,y:4,z:-8}).typeId,'minecraft:stone');
});

test('entering just after closure starts safely reopens without an endless motion',()=>{
 const f=doorFixture();f.use();f.entities.push({location:{x:2,y:5,z:1},getComponent:()=>({})});f.step();
 assert.equal(f.props.get('foundry:door_motions_v1'),'[]');assert([...f.blocks.values()].every(b=>b.typeId==='minecraft:air'));
});
