import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import * as experience from '../src/experience_core.js';
import * as core from '../src/core.js';
import {ATTACHMENTS} from '../build/Foundry_Arsenal_BP/scripts/data.js';
const source=name=>readFileSync(new URL('../src/'+name,import.meta.url),'utf8');
const plain=value=>JSON.parse(JSON.stringify(value));
const signal=()=>({handlers:[],subscribe(fn){this.handlers.push(fn);},emit(event){for(const fn of this.handlers)fn(event);}});

test('corrupt journal data recovers and persisted progress is bounded and filtered',()=>{
 for(const raw of [undefined,'not JSON','null','[]'])assert.deepEqual(experience.parseJournal(raw),experience.freshJournal());
 const j=experience.parseJournal(JSON.stringify({settings:{sounds:false,feedback:'false'},stats:{hits:-4,headshots:1e20,reloads:'3'},stations:['foundry:alloy_forge','foundry:alloy_forge','minecraft:stone'],claimed:['reload','reload','fake'],facilities:[{name:'Silo',dimension:'minecraft:overworld',x:1.9,y:64,z:-2.1},{name:'Bad',dimension:'bad',x:1,y:64,z:2}],waypoint:'0'}));
 assert.equal(j.settings.sounds,false);assert.equal(j.settings.feedback,true);
 assert.equal(j.stats.hits,0);assert.equal(j.stats.headshots,1000000);assert.equal(j.stats.reloads,3);
 assert.deepEqual(j.stations,['foundry:alloy_forge']);assert.deepEqual(j.claimed,['reload']);assert.equal(j.waypoint,null);
 assert.deepEqual(j.facilities,[{name:'Silo',dimension:'minecraft:overworld',x:1,y:64,z:-3}]);
});
test('optional tasks require real progress, pay once, and preserve claims across reload',()=>{
 const j=experience.freshJournal();assert.equal(experience.claimTask(j,'reload'),null);assert.equal(experience.claimTask(j,'fake'),null);
 j.stats.reloads=1;assert.deepEqual(experience.claimTask(j,'reload'),{'foundry:maintenance_kit':1});assert.equal(experience.claimTask(j,'reload'),null);
 const saved=experience.parseJournal(JSON.stringify(j));assert.equal(experience.claimTask(saved,'reload'),null);
 j.stations=experience.STATION_IDS.slice(0,2);assert.equal(experience.claimTask(j,'workshop'),null);
 j.stations.push(experience.STATION_IDS[2]);assert.deepEqual(experience.claimTask(j,'workshop'),{'foundry:polymer':4});
});
test('target scores follow printed ring geometry for all four rotations and ignore the stand and sides',()=>{
 for(const facing of ['north','south','east','west']){
  const sideways=['east','west'].includes(facing),face=sideways?'East':'North',point={x:.5,y:9/16,z:.5};
  assert.equal(experience.targetScore(face,point,facing),10);
  point[sideways?'z':'x']+=.16;assert.equal(experience.targetScore(face,point,facing),7);
  point[sideways?'z':'x']+=.14;assert.equal(experience.targetScore(face,point,facing),3);
  point[sideways?'z':'x']=15/16;point.y=1;assert.equal(experience.targetScore(face,point,facing),1);
  point.y=1/16;assert.equal(experience.targetScore(face,point,facing),0);
  assert.equal(experience.targetScore(sideways?'North':'East',{x:.5,y:9/16,z:.5},facing),0);
 }
 assert.equal(experience.targetScore('Up',{x:.5,y:1,z:.5}),0);
 assert.equal(experience.targetScore('North',{x:NaN,y:.5,z:.5}),0);
 assert.equal(experience.targetScore('North',null),0);
});
test('range sessions track bullseye streaks while lifetime progress remains separate',()=>{
 const j=experience.freshJournal();experience.recordRange(j,10,21.9);experience.recordRange(j,10,18);experience.recordRange(j,3,40);
 assert.deepEqual(j.range,{hits:3,score:23,streak:0,bestStreak:2});assert.equal(j.stats.bullseyes,2);assert.equal(j.stats.bestDistance,21);
});
test('discovered facilities are deduplicated, capped, and keep navigation indexes valid',()=>{
 const j=experience.freshJournal(),dim='minecraft:overworld';
 assert(experience.discoverFacility(j,'Bunker',dim,{x:0,y:64,z:0}));
 assert.equal(experience.discoverFacility(j,'Bunker',dim,{x:30,y:70,z:10}),false);
 for(let i=1;i<8;i++)experience.discoverFacility(j,'Bunker',dim,{x:i*100,y:64,z:0});
 j.waypoint=1;experience.discoverFacility(j,'Silo',dim,{x:900,y:64,z:0});assert.equal(j.facilities.length,8);assert.equal(j.waypoint,0);assert.equal(j.facilities[0].x,100);
 experience.discoverFacility(j,'Silo',dim,{x:1000,y:64,z:0});assert.equal(j.waypoint,null);
});
test('facility guidance reports direction and distance without changing the player location',()=>{
 const j=experience.freshJournal(),dim='minecraft:overworld',pos={x:0,y:64,z:0};
 experience.discoverFacility(j,'Silo',dim,{x:100,y:64,z:-100});j.waypoint=0;
 assert.equal(experience.navigation(j,dim,pos),'Silo · 141 blocks NE');assert.deepEqual(pos,{x:0,y:64,z:0});
 assert.equal(experience.navigation(j,'minecraft:nether',pos),'Silo · another dimension');
 assert.equal(experience.navigation(j,dim,{x:100,y:64,z:-100}),'Silo · HERE');
 j.settings.navigation=false;assert.equal(experience.navigation(j,dim,pos),'');
});
test('salvage requires an unloaded identified weapon and returns only valid fitted attachments',()=>{
 assert.equal(experience.salvagePlan({uid:'',loaded:0},ATTACHMENTS),null);
 assert.equal(experience.salvagePlan({uid:'gun',loaded:1},ATTACHMENTS),null);
 const optic=Object.keys(ATTACHMENTS).find(id=>ATTACHMENTS[id].slot==='optic');
 assert.deepEqual(experience.salvagePlan({uid:'gun',loaded:0,attachments:{optic,stock:'not_an_item',magazine:optic}},ATTACHMENTS),{'foundry:steel_plate':1,'foundry:polymer':1,['foundry:'+optic]:1});
});

function journalFixture(initial=experience.freshJournal()){
 const props=new Map([['foundry:journal_v1',JSON.stringify(initial)]]),sounds=[],given=[],forms=[],messages=[],answers=[],intervals=[];
 let heldItem,busy=false,component;
 const events=Object.fromEntries(['playerPlaceBlock','playerInteractWithBlock','entityDie','playerLeave'].map(name=>[name,signal()]));
 const p={id:'operator',typeId:'minecraft:player',selectedSlotIndex:0,location:{x:0,y:64,z:0},dimension:{id:'minecraft:overworld'},getDynamicProperty:k=>props.get(k),setDynamicProperty:(k,v)=>props.set(k,v),playSound:(id,o)=>sounds.push({id,...o}),getComponent:()=>({container:{getItem:()=>heldItem}})};
 const system={currentTick:0,beforeEvents:{startup:{subscribe:fn=>fn({blockComponentRegistry:{registerCustomComponent:(id,c)=>{assert.equal(id,'foundry:range_target');component=c;}}})}},run:fn=>fn(),runInterval:fn=>intervals.push(fn)};
 class Form{constructor(){this.buttons=[];}title(v){this.name=v;return this;}body(v){this.text=v;return this;}button(v){this.buttons.push(v);return this;}button1(v){return this.button(v);}button2(v){return this.button(v);}}
 const api=vm.runInNewContext(source('experience.js').replace(/^import[^\n]*\n/gm,'').replace(/export /g,'')+';({installExperience,recordMilestone,combatHit,practiceHit,fieldJournal,feedbackText,navigationText,taskMenu,rangeMenu})',{...experience,world:{afterEvents:events},system,EntityDamageCause:{projectile:'projectile'},ActionFormData:Form,MessageFormData:Form,console});
 api.installExperience({show:async(player,form)=>{forms.push(form);const answer=answers.shift();return typeof answer==='function'?answer():answer||{canceled:true};},give:(player,id,n)=>{assert(JSON.parse(props.get('foundry:journal_v1')).claimed.length,'claim must persist before delivery');given.push({id,n});},message:(player,m)=>messages.push(m),busy:()=>busy});
 return {p,api,props,events,system,sounds,given,forms,messages,answers,component,read:()=>JSON.parse(props.get('foundry:journal_v1')),hold:item=>heldItem=item,setBusy:value=>busy=value,flush:async()=>{for(let i=0;i<8;i++)await Promise.resolve();},cleanup:()=>intervals.forEach(fn=>fn())};
}
test('runtime station and facility events persist only distinct first interactions',()=>{
 const f=journalFixture();for(const typeId of [experience.STATION_IDS[0],experience.STATION_IDS[0],'minecraft:stone',experience.STATION_IDS[1]])f.events.playerPlaceBlock.emit({player:f.p,block:{typeId}});
 assert.equal(f.read().stations.length,2);
 const event={player:f.p,isFirstEvent:false,block:{typeId:'foundry:bunker_switch',dimension:f.p.dimension,location:{x:30,y:64,z:30}}};
 f.events.playerInteractWithBlock.emit(event);assert.equal(f.read().facilities.length,0);event.isFirstEvent=true;
 f.events.playerInteractWithBlock.emit(event);f.events.playerInteractWithBlock.emit(event);assert.equal(f.read().facilities.length,1);assert.equal(f.messages.length,1);
 f.events.playerLeave.emit({playerId:f.p.id});assert.match(f.api.navigationText(f.p),/^$/);
});
test('runtime reward confirmation rechecks progress and prevents repeat or simultaneous payouts',async()=>{
 const j=experience.freshJournal();j.stats.reloads=1;const f=journalFixture(j);
 f.answers.push({selection:0},{selection:0});await f.api.taskMenu(f.p);
 assert.deepEqual(f.given,[{id:'foundry:maintenance_kit',n:1}]);assert.deepEqual(f.read().claimed,['reload']);
 f.answers.push({selection:0},{selection:0});await f.api.taskMenu(f.p);assert.equal(f.given.length,1);
 // Two confirmations already open still consult the live claimed state.
 const second=journalFixture(j);let resolveFirst;
 second.answers.push({selection:0},()=>new Promise(resolve=>resolveFirst=resolve));const pending=second.api.taskMenu(second.p);await second.flush();
 second.answers.push({selection:0},{selection:0});await second.api.taskMenu(second.p);resolveFirst({selection:0});await pending;
 assert.equal(second.given.length,1);
});
test('confirmed defeat credit excludes untracked, stale, other-player, melee and nonhostile quest kills',()=>{
 const f=journalFixture(),enemy=id=>({id,typeId:'minecraft:zombie'}),die=(e,player=f.p,cause='projectile')=>f.events.entityDie.emit({deadEntity:e,damageSource:{damagingEntity:player,cause}});
 die(enemy('untracked'));
 const stale=enemy('stale');f.api.combatHit(f.p,stale,false);f.system.currentTick=101;die(stale);
 const other=enemy('other');f.api.combatHit(f.p,other,false);die(other,{id:'other',typeId:'minecraft:player'});
 const melee=enemy('melee');f.api.combatHit(f.p,melee,false);die(melee,f.p,'entityAttack');
 assert.equal(f.read().stats.kills,0);
 const hostile=enemy('hostile');f.api.combatHit(f.p,hostile,true);die(hostile);die(hostile);
 const cow={id:'cow',typeId:'minecraft:cow'};f.api.combatHit(f.p,cow,false);die(cow);
 const player={id:'enemyPlayer',typeId:'minecraft:player'};f.api.combatHit(f.p,player,false);die(player);
 assert.equal(f.read().stats.kills,3);assert.equal(f.read().stats.hostileKills,1);assert.equal(f.read().stats.headshots,1);
});
test('shotgun feedback makes one quiet cue per tick and player toggles persist',async()=>{
 const f=journalFixture();for(let i=0;i<8;i++)f.api.combatHit(f.p,{id:'mob'},false);
 assert.equal(f.sounds.length,1);assert.match(f.api.feedbackText(f.p),/HIT/);
 f.system.currentTick=25;assert.equal(f.api.feedbackText(f.p),'');f.cleanup();
 f.answers.push({selection:2},{selection:0},{selection:1});await f.api.fieldJournal(f.p);
 assert.equal(f.read().settings.feedback,false);assert.equal(f.read().settings.sounds,false);
 f.api.combatHit(f.p,{id:'mob'},true);assert.equal(f.api.feedbackText(f.p),'');assert.equal(f.sounds.length,1);
});
test('practice target empty-hand UI respects busy forms and reset keeps lifetime progress',async()=>{
 const f=journalFixture();f.api.practiceHit(f.p,'North',{x:.5,y:9/16,z:0},25);
 f.hold({typeId:'foundry:some_gun'});f.component.onPlayerInteract({player:f.p});await f.flush();assert.equal(f.forms.length,0);
 f.hold(undefined);f.setBusy(true);f.component.onPlayerInteract({player:f.p});await f.flush();assert.equal(f.forms.length,0);
 f.setBusy(false);f.answers.push({selection:0},{selection:0});f.component.onPlayerInteract({player:f.p});await f.flush();
 assert.equal(f.forms[0].name,'PRACTICE RANGE');assert.equal(f.read().range.score,0);assert.equal(f.read().stats.bullseyes,1);assert.equal(f.read().stats.bestDistance,25);
});
test('facility selection rejects a stale list changed while its form was open',async()=>{
 const j=experience.freshJournal();experience.discoverFacility(j,'Bunker','minecraft:overworld',{x:100,y:64,z:100});const f=journalFixture(j);
 f.answers.push({selection:1},()=>{f.events.playerInteractWithBlock.emit({player:f.p,isFirstEvent:true,block:{typeId:'foundry:relic_controller',dimension:f.p.dimension,location:{x:200,y:64,z:200}}});return {selection:0};});
 await f.api.fieldJournal(f.p);assert.equal(f.read().waypoint,null);assert(f.messages.some(m=>m.includes('Locations changed')));
});

function recycleFixture(change,answer={selection:0},loaded=0){
 const id='foundry:test_gun',uid='instance',optic=Object.keys(ATTACHMENTS).find(id=>ATTACHMENTS[id].slot==='optic');
 let item={typeId:id,state:{uid,loaded,attachments:{optic}}};const given=[],messages=[],runtime={held:true,burst:3,reload:{uid}};
 class Form{title(){return this;}body(){return this;}button1(){return this;}button2(){return this;}}
 const code=source('main.js'),fn=code.slice(code.indexOf('async function recycleWeapon('),code.indexOf('async function fitAttachment('));
 const recycle=vm.runInNewContext(fn+';recycleWeapon',{salvagePlan:experience.salvagePlan,ATTACHMENTS,inv:()=>({getItem:()=>item,setItem:()=>item=undefined}),gunState:it=>it.state,gunMap:new Map([[id,{name:'Test'}]]),rt:()=>runtime,MessageFormData:Form,show:async()=>{if(change)item=change(item);return answer;},give:(p,id,n)=>given.push({id,n}),message:(p,m)=>messages.push(m)});
 return {recycle:()=>recycle({}, {slot:0,id},uid),item:()=>item,given,messages,runtime};
}
test('recycling consumes exactly one unloaded instance and returns its fitted attachments',async()=>{
 const f=recycleFixture();await f.recycle();assert.equal(f.item(),undefined);assert.equal(f.given.length,3);assert.equal(f.runtime.reload,null);assert.equal(f.runtime.held,false);assert.equal(f.runtime.burst,0);
 await f.recycle();assert.equal(f.given.length,3);
});
test('recycle cancellation, moved instances and magazine changes leave inventory untouched',async()=>{
 for(const f of [recycleFixture(null,{selection:1}),recycleFixture(null,{canceled:true}),recycleFixture(item=>({...item,state:{...item.state,uid:'different'}})),recycleFixture(item=>({...item,state:{...item.state,loaded:4}})),recycleFixture(null,{selection:0},4)]){
  await f.recycle();assert(f.item());assert.equal(f.given.length,0);assert.equal(f.runtime.held,true);
 }
});
test('a ray only scores a reachable practice plate and uses its placement rotation',()=>{
 const code=source('main.js'),fn=code.slice(code.indexOf('function rayShot('),code.indexOf('function launch('));
 for(const [obstructed,effect,scores] of [[false,'normal',1],[true,'normal',0],[true,'piercing',1]]){
  const recorded=[],damaged=[],wall={block:{typeId:'foundry:range_target',location:{x:0,y:64,z:10},permutation:{getState:()=> 'east'}},face:'East',faceLocation:{x:.5,y:9/16,z:.5}};
  const mob={id:'mob',getHeadLocation:()=>({x:0,y:65,z:5})},d={getBlockFromRay:()=>wall,getEntitiesFromRay:()=>obstructed?[{entity:mob,distance:5}]:[]};
  const p={id:'shooter',dimension:d,getHeadLocation:()=>({x:0,y:64.5,z:0}),getViewDirection:()=>({x:0,y:0,z:1})};
  vm.runInNewContext(fn+';rayShot(p,s)',{...core,p,s:{range:40,spread:0,damage:5,effect},muzzlePoint:()=>p.getHeadLocation(),damageable:()=>true,hit:()=>damaged.push(true),particle(){},practiceHit:(...args)=>recorded.push(args)});
  assert.equal(recorded.length,scores);assert.equal(damaged.length,obstructed?1:0);if(scores)assert.equal(recorded[0][4],'east');
 }
});
test('rejected damage does not produce hit feedback or trigger status effects',()=>{
 const code=source('main.js'),fn=code.slice(code.indexOf('function hit('),code.indexOf('function clearAim('));
 let feedback=0,effects=0;
 const entity={applyDamage:()=>false,setOnFire:()=>effects++};
 const result=vm.runInNewContext(fn+";hit(entity,5,{},'fire',true)",{entity,damageable:()=>true,EntityDamageCause:{projectile:'projectile'},combatHit:()=>feedback++,report(){}});
 assert.equal(result,false);assert.equal(feedback,0);assert.equal(effects,0);
});
