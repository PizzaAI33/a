"""Independent NBT reader and expansion asset/structure consistency checks."""
from pathlib import Path
import json,struct,sys
ROOT=Path(__file__).resolve().parents[1];BP=ROOT/'build/Foundry_Arsenal_BP';RP=ROOT/'build/Foundry_Arsenal_RP'
sys.path.insert(0,str(ROOT/'src'))
from siege_catalog import MISSILES
from release import VERSION, VERSION_TAG
checks=0

def check(ok,message):
 global checks
 checks+=1
 assert ok,message
class Reader:
 def __init__(self,path):self.data=path.read_bytes();self.pos=0
 def read(self,n):r=self.data[self.pos:self.pos+n];self.pos+=n;return r
 def number(self,fmt):return struct.unpack(fmt,self.read(struct.calcsize(fmt)))[0]
 def string(self):return self.read(self.number('<H')).decode()
 def tag(self,t):
  if t==3:return self.number('<i')
  if t==4:return self.number('<q')
  if t==8:return self.string()
  if t==9:
   kind=self.number('B');return [self.tag(kind) for _ in range(self.number('<i'))]
  if t==10:
   result={}
   while True:
    kind=self.number('B')
    if kind==0:return result
    name=self.string();result[name]=self.tag(kind)
  raise ValueError(t)
 def root(self):
  check(self.number('B')==10,'Compound NBT root');check(self.string()=='','Unnamed root');root=self.tag(10);check(self.pos==len(self.data),'No trailing NBT bytes');return root
for path in BP.glob('structures/foundry/*.mcstructure'):
 data=Reader(path).root();sx,sy,sz=data['size'];st=data['structure'];pal=st['palette']['default'];indices=st['block_indices'][0]
 check(len(indices)==sx*sy*sz,'Structure volume');check(len(st['block_indices'][1])==len(indices),'Second block layer');check(all(-1<=i<len(pal['block_palette']) for i in indices),'Valid palette indices')
 def block(x,y,z):return 'structure_void' if indices[(x*sy+y)*sz+z]==-1 else pal['block_palette'][indices[(x*sy+y)*sz+z]]['name']
 chestcount=0
 for index,entry in pal['block_position_data'].items():
  e=entry['block_entity_data'];chestcount+=1;check(e['id']=='Chest','Chest entity');check(block(e['x'],e['y'],e['z'])=='minecraft:chest','Chest block');check(int(index)==(e['x']*sy+e['y'])*sz+e['z'],'Block entity position index');check((BP/e['LootTable']).is_file(),'Loot table exists')
 check(chestcount>=2,'At least two loot chests')
 if path.stem=='relic_silo':
  check(block(30,3,26)=='foundry:relic_controller','Preloaded controller position')
  for x in range(28,33):
   for z in range(24,29):check(block(x,2,z)=='foundry:silo_casing','Complete silo foundation')
  for x in [28,32]:
   for z in [24,28]:check(block(x,3,z)=='foundry:silo_stabilizer','Stabilizers')
  for y in range(4,28):
   for x in range(29,32):
    for z in range(25,28):check(block(x,y,z)=='minecraft:air','Open launch shaft')
  check(block(8,33,0)=='minecraft:air','Accessible manual entrance');check(block(21,26,26)=='minecraft:ladder','Ladder access')
known=set()
for path in BP.glob('items/*.json'):known.add(json.loads(path.read_text())['minecraft:item']['description']['identifier'])
for path in BP.glob('blocks/*.json'):known.add(json.loads(path.read_text())['minecraft:block']['description']['identifier'])
for path in BP.glob('loot_tables/chests/*.json'):
 for pool in json.loads(path.read_text())['pools']:
  for e in pool['entries']:
   if e['type']=='item':check(e['name'].startswith('minecraft:') or e['name'] in known,'Known chest loot '+e['name'])
for id in MISSILES:check('foundry:'+id in known,'Missile item '+id)
for path in RP.glob('particles/*.json'):
 tex=json.loads(path.read_text())['particle_effect']['description']['basic_render_parameters']['texture'];check((RP/(tex+'.png')).exists(),'Particle texture')
for definition in json.loads((RP/'sounds/sound_definitions.json').read_text())['sound_definitions'].values():
 for sound in definition['sounds']:check((RP/(sound['name']+'.ogg')).exists(),'Sound asset')
for pack in [BP,RP]:check(json.loads((pack/'manifest.json').read_text())['header']['version']==VERSION,'Pack version')
report=json.loads((ROOT/'output/validation.json').read_text());report.update(expansion_checks=checks,missile_tiers=4,structure_templates=4,logic_tests=18,typecheck='PASS',in_game_tested=False)
(ROOT/'output/validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(f'PASS: {checks} expansion structure/loot/asset checks; four missile tiers and four structure templates')
