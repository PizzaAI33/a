import test from 'node:test';
import assert from 'node:assert/strict';
import {stats,compatible,reloadPlan,canAfford,inventoryTotals,parseState,freshState,spreadRay,length,blastDamage} from '../src/core.js';
import {GUNS,ATTACHMENTS,RECIPES} from '../build/Foundry_Arsenal_BP/scripts/data.js';

test('60 distinct weapon IDs, all craftable at the gunsmith',()=>{
 assert.equal(GUNS.length,60);assert.equal(new Set(GUNS.map(g=>g.id)).size,60);
 for(const g of GUNS)assert(RECIPES.some(r=>r.output==='foundry:'+g.id&&r.station==='gunsmith_bench'));
});
test('reloading cannot create ammo, exceed capacity, or use negative reserve',()=>{
 for(let loaded=0;loaded<=200;loaded+=5)for(let cap=1;cap<=200;cap+=7)for(const reserve of [0,1,8,64,200]){
  const n=reloadPlan(loaded,cap,reserve);assert(n>=0);assert(n<=reserve);if(loaded<cap)assert(loaded+n<=cap);else assert.equal(n,0);
 }
});
test('magazine changes and reload attachments affect actual stats',()=>{
 const g=GUNS.find(g=>g.id==='glock_17');
 assert.equal(stats(g,{attachments:{magazine:'extended_mag'}},ATTACHMENTS).capacity,25);
 assert.equal(stats(g,{attachments:{magazine:'drum_mag'}},ATTACHMENTS).capacity,34);
 assert(stats(g,{attachments:{magazine:'quick_mag'}},ATTACHMENTS).reload<g.reload);
});
test('optic, suppressor, barrel, grip and all payload cores change gameplay',()=>{
 const g=GUNS.find(g=>g.id==='ak_47');
 const s=stats(g,{attachments:{optic:'scope_8x',muzzle:'long_barrel',underbarrel:'vertical_grip',payload:'cryo_core'}},ATTACHMENTS,true);
 assert.equal(s.fov,12);assert.equal(s.effect,'ice');assert(s.range>g.range);assert(s.spread<g.spread);
 const quiet=stats(g,{attachments:{muzzle:'suppressor'}},ATTACHMENTS);assert(quiet.quiet);assert(quiet.damage<g.damage);
 for(const [id,effect] of [['incendiary_core','fire'],['shock_core','shock'],['venom_core','poison'],['piercing_core','piercing']])assert.equal(stats(g,{attachments:{payload:id}},ATTACHMENTS).effect,effect);
});
test('bipod applies only while aiming; integral scopes can be overridden',()=>{
 const g=GUNS.find(g=>g.category==='Sniper rifles');
 const st={attachments:{underbarrel:'bipod'}};assert.equal(stats(g,st,ATTACHMENTS,false).fov,22);
 assert(stats(g,st,ATTACHMENTS,true).spread<stats(g,{attachments:{}},ATTACHMENTS,true).spread);
 assert.equal(stats(g,{attachments:{optic:'red_dot'}},ATTACHMENTS).fov,58);
});
test('attachment compatibility excludes launchers, revolver magazines and pistol stocks',()=>{
 const launcher=GUNS.find(g=>g.category==='Launchers'),pistol=GUNS[0],revolver=GUNS.find(g=>g.style==='revolver');
 assert(!compatible(launcher,ATTACHMENTS.cryo_core));assert(compatible(launcher,ATTACHMENTS.scope_4x));
 assert(!compatible(pistol,ATTACHMENTS.precision_stock));assert(!compatible(revolver,ATTACHMENTS.drum_mag));
 assert(!compatible(pistol,ATTACHMENTS.choke));assert(compatible(GUNS.find(g=>g.category==='Shotguns'),ATTACHMENTS.choke));
});
test('every legal attachment combination yields finite bounded stats',()=>{
 for(const g of GUNS)for(const [id,a] of Object.entries(ATTACHMENTS))if(compatible(g,a)){
  const s=stats(g,{attachments:{[a.slot]:id}},ATTACHMENTS,true);
  for(const k of ['damage','range','capacity','spread','reload'])assert(Number.isFinite(s[k])&&s[k]>0,`${g.id} ${id} ${k}`);
  assert(s.capacity<=200);assert(s.range<=240);
 }
});
test('inventory cost check aggregates split stacks and refuses missing resources',()=>{
 const totals=inventoryTotals([{typeId:'iron',amount:3},undefined,{typeId:'iron',amount:4},{typeId:'copper',amount:1}]);
 assert.equal(totals.iron,7);assert(canAfford(totals,{iron:7,copper:1}));assert(!canAfford(totals,{iron:8}));assert(!canAfford(totals,{gold:1}));
});
test('persistent gun state survives serialization and clamps corrupt values',()=>{
 const s={uid:'test-instance',loaded:17,wear:25,attachments:{optic:'scope_4x'}};assert.deepEqual(parseState(JSON.stringify(s)),s);
 assert.deepEqual(parseState('bad-json'),freshState());assert.equal(parseState('{"loaded":99999,"wear":-1}').loaded,250);
});
test('spread rays remain normalized and blast damage falls off',()=>{
 for(let i=0;i<100;i++)assert(Math.abs(length(spreadRay({x:0,y:0,z:1},.2))-1)<1e-10);
 assert.equal(blastDamage(20,0,5),20);assert.equal(blastDamage(20,5,5),0);assert(blastDamage(20,1,5)>blastDamage(20,4,5));
});
