"""Check the playable range asset, facility integration and bounded quest rewards."""
from collections import Counter
from pathlib import Path
import json, subprocess, sys
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'src'))
from render_review import NBT
from release import VERSION, VERSION_TAG
from PIL import Image
bp=root/'build/Foundry_Arsenal_BP';rp=root/'build/Foundry_Arsenal_RP';checks=0
def check(ok,message):
 global checks
 checks+=1
 assert ok,message
def read(path):return json.loads(path.read_text())
block=read(bp/'blocks/range_target.json')['minecraft:block'];components=block['components']
check(block['description']['identifier']=='foundry:range_target','Practice target block identity')
check('foundry:range_target' in components,'Interactable range component')
check("registerCustomComponent('foundry:range_target'" in (bp/'scripts/experience.js').read_text(),'Registered native range interaction')
check(block['description']['traits']['minecraft:placement_direction']['enabled_states']==['minecraft:cardinal_direction'],'Target placement direction')
check({p['components']['minecraft:transformation']['rotation'][1] for p in block['permutations']}=={90,180,270},'Four target orientations')
geo=read(rp/'models/blocks/range_target.geo.json')['minecraft:geometry'][0]
check(components['minecraft:geometry']==geo['description']['identifier'],'Target model reference')
plate=geo['bones'][0]['cubes'][1]
check(plate['origin']==[-7,2,-1] and plate['size']==[14,14,2],'Printed target geometry matches score coordinates')
check(all(plate['uv'][face]['uv']==[0,0] and plate['uv'][face]['uv_size']==[32,32] for face in ['north','south']),'Printed front and back')
with Image.open(rp/'textures/blocks/range_target.png') as image:
 check(image.size==(geo['description']['texture_width'],geo['description']['texture_height']),'Target texture dimensions')
 check(image.getpixel((15,15))!=image.getpixel((0,0)),'Visible bullseye region')
check(read(rp/'textures/terrain_texture.json')['texture_data']['range_target']['textures']=='textures/blocks/range_target','Terrain atlas link')
recipe=read(bp/'recipes/range_target.json')['minecraft:recipe_shaped'];cost=Counter()
for row in recipe['pattern']:
 for char in row:
  if char!=' ':cost[recipe['key'][char]['item']]+=1
check(cost==Counter({'minecraft:oak_planks':5,'minecraft:redstone':1,'minecraft:stick':1}),'Accessible practice target recipe')
check(recipe['tags']==['crafting_table'] and recipe['result']=={'item':'foundry:range_target','count':1},'Native table target recipe')
loot=read(bp/components['minecraft:loot'])['pools']
check(loot==[{'rolls':1,'entries':[{'type':'item','name':'foundry:range_target'}]}],'Reusable target drop')
for name,pos in [('bunker_0',(6,3,22)),('bunker_1',(6,3,22)),('bunker_2',(6,3,22)),('relic_silo',(6,4,31))]:
 s=NBT(bp/'structures/foundry'/f'{name}.mcstructure').read();sx,sy,sz=s['size'];palette=s['structure']['palette']['default']['block_palette'];indices=s['structure']['block_indices'][0]
 def at(x,y,z):
  i=indices[(x*sy+y)*sz+z]
  return 'void' if i<0 else palette[i]['name']
 x,y,z=pos
 check(at(x,y,z)=='foundry:range_target','Facility practice equipment: '+name)
 check(at(x,y-1,z) not in ['void','minecraft:air'],'Supported practice target: '+name)
 check(all(at(x,y,z-d)=='minecraft:air' for d in [1,2]),'Clear printed target face: '+name)
known=set()
for directory,kind in [('items','minecraft:item'),('blocks','minecraft:block')]:
 for path in (bp/directory).glob('*.json'):known.add(read(path)[kind]['description']['identifier'])
result=subprocess.run(['node','--input-type=module','-e',"import {TASKS} from './src/experience_core.js';console.log(JSON.stringify(TASKS))"],cwd=root,text=True,capture_output=True,check=True)
tasks=json.loads(result.stdout)
check(len({t['id'] for t in tasks})==len(tasks)==6,'Six distinct optional tasks')
for task in tasks:
 check(1<=task['goal']<=10,'Attainable field goal: '+task['id'])
 for identifier,count in task['rewards'].items():
  check(identifier in known or identifier=='minecraft:bread','Existing reward item: '+identifier)
  check(1<=count<=16 and not any(v in identifier for v in ['missile','stellar_core','power_cell','guidance_matrix']),'Modest task reward: '+identifier)
for name in ['experience.js','experience_core.js']:
 check((bp/'scripts'/name).read_bytes()==(root/'src'/name).read_bytes(),'Generated experience script matches source')
for pack in [bp,rp]:check(read(pack/'manifest.json')['header']['version']==VERSION,'Current release version')
guide=(root/'output/Foundry_Arsenal_Field_Guide.html').read_text()
check('Version 0.7 — field experience' in guide and 'five oak planks' in guide,'Current experience guide')
check('matching 0.6' not in guide and 'matching 0.4' not in guide,'Current guide activation instructions')
report=read(root/'output/validation.json')
report.update(v7_checks=checks,version=VERSION_TAG,field_experience='Optional tasks, once-only claims, combat attribution, target scoring, saved navigation and safe recycling regression PASS',in_game_tested=False)
(root/'output/validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(f'PASS: {checks} practice asset, facility, reward and current-guide checks')
