import test from 'node:test';
import assert from 'node:assert/strict';
import {grid,validTarget,safety,craterBottom,craterRegions,craterRuns,craterPrisms,siloRequirements} from '../src/siege_core.js';
const tier={radius:250,depth:100,danger:400,safe:500};
test('negative chunk coordinates use floor, not truncation',()=>assert.deepEqual(grid({x:-1,z:-17}),{x:-1,z:-2}));
test('target bounds reject non-finite and unsupported coordinates',()=>{
 assert(validTarget({x:-1000000,y:-63,z:1000000}));
 for(const p of [{x:NaN,y:64,z:0},{x:Infinity,y:64,z:0},{x:0,y:301,z:0},{x:0,y:-64,z:0},{x:1000001,y:64,z:0}])assert(!validTarget(p));
});
test('distance UI distinguishes danger, caution and recommended separation',()=>{
 const t={x:0,y:60,z:0};assert.equal(safety({x:399,y:300,z:0},t,tier).status,'DANGER');
 assert.equal(safety({x:400,z:0},t,tier).status,'CAUTION');assert.equal(safety({x:500,z:0},t,tier).status,'OUTSIDE MODELED BLAST');
 assert.equal(safety({x:300,z:400},t,tier).distance,500);
});
test('Apex circular bowl is exactly 500 columns wide and at most 100 deep',()=>{
 const t={x:0,y:100,z:0};assert.equal(craterBottom(t,tier,0,0),0);assert.equal(craterBottom(t,tier,-250,0),99);assert.equal(craterBottom(t,tier,249,0),99);
 assert.equal(craterBottom(t,tier,250,0),null);assert.equal(craterBottom(t,tier,-251,0),null);assert.equal(craterBottom(t,tier,249,249),null);
 assert.equal(craterBottom({x:0,y:-30,z:0},tier,0,0),-63);
});
test('every crater column is covered once by loaded-window runs with correct depths',()=>{
 for(const t of [{x:0,y:70,z:0},{x:-129,y:200,z:127},{x:255,y:-20,z:-257}]){
  const coverage=new Set();
  for(const r of craterRegions(t,tier)){
   assert.equal(Math.abs(r.x%128),0);assert.equal(Math.abs(r.z%128),0);
   for(const run of craterRuns(t,tier,r)){
    assert(run.x>=r.x&&run.x<r.x+128);assert(run.z0>=r.z&&run.z1<r.z+128);assert(run.volume<=32768);assert(run.bottom>=-63);assert(run.top<=319);
    for(let z=run.z0;z<=run.z1;z++){
     assert.equal(run.bottom,craterBottom(t,tier,run.x,z));const key=`${run.x},${z}`;assert(!coverage.has(key));coverage.add(key);
    }
   }
  }
  let expected=0;
  for(let x=t.x-250;x<t.x+250;x++)for(let z=t.z-250;z<t.z+250;z++)if(craterBottom(t,tier,x,z)!==null){expected++;assert(coverage.has(`${x},${z}`));}
  assert.equal(coverage.size,expected);assert(expected>196000&&expected<197000);
 }
});
test('saved region/run cursor can resume without omissions',()=>{
 const target={x:34,y:64,z:-97},small={radius:32,depth:18};
 const all=craterRegions(target,small).map(r=>craterRuns(target,small,r));
 const before=[],after=[];let stopped=false;
 for(let i=0;i<all.length;i++)for(let j=0;j<all[i].length;j++){
  if(i===1&&j===3)stopped=true;(stopped?after:before).push(all[i][j]);
 }
 assert.deepEqual([...before,...after],all.flat());
});
test('silo has a 25-block foundation, four corner stabilizers and 99 clear shaft blocks',()=>{
 const req=siloRequirements({x:12,y:3,z:12});assert.equal(req.base.length,25);assert.equal(req.stabilizers.length,4);assert.equal(req.clearance.length,99);
 assert(req.base.every(p=>p.y===2));assert(req.clearance.every(p=>p.y>=4&&p.y<=14));
});

test('merged excavation prisms exactly preserve bowl columns and stay under fill limit',()=>{
 const t={x:-37,y:160,z:113},tier={radius:250,depth:100};
 let oldCount=0,newCount=0,volume=0;
 for(const region of craterRegions(t,tier)){
  const original=craterRuns(t,tier,region),merged=craterPrisms(t,tier,region);oldCount+=original.length;newCount+=merged.length;
  const seen=new Set();
  for(const r of merged){assert(r.volume<=32768);assert.equal(r.volume,(r.x1-r.x+1)*(r.z1-r.z0+1)*(r.top-r.bottom+1));volume+=r.volume;
   for(let x=r.x;x<=r.x1;x++)for(let z=r.z0;z<=r.z1;z++){const key=x+','+z;assert(!seen.has(key));seen.add(key);assert.equal(r.bottom,craterBottom(t,tier,x,z));}}
  assert.equal(seen.size,original.reduce((n,r)=>n+r.z1-r.z0+1,0));
 }
 assert(newCount<oldCount);assert(volume>20000000);
});
