from pathlib import Path
from collections import Counter
import json,sys,subprocess
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'src'))
from render_review import NBT
bp=root/'build/Foundry_Arsenal_BP';rp=root/'build/Foundry_Arsenal_RP';audit=json.loads((bp/'crafting_audit.json').read_text());checks=0

def check(ok,msg):
 global checks
 checks+=1
 assert ok,msg
bundles=audit['bundles']
def raw(item):
 b=bundles.get(item.split(':')[-1]);return Counter({b['item']:b['count']}) if b else Counter({item:1})
for row in audit['recipes']:
 recipe=json.loads((bp/'recipes'/('assembly_'+row['id']+'.json')).read_text())['minecraft:recipe_shaped'];total=Counter()
 for line in recipe['pattern']:
  for letter in line:
   if letter!=' ':total.update(raw(recipe['key'][letter]['item']))
 check(total==Counter(row['raw']),'Native assembly cost changed: '+row['id'])
for id,b in bundles.items():
 recipe=json.loads((bp/'recipes'/f'{id}.json').read_text())['minecraft:recipe_shapeless'];total=Counter()
 for item in recipe['ingredients']:total.update(raw(item['item']))
 check(total==Counter({b['item']:b['count']}),'Packing cost '+id)
 unpack=json.loads((bp/'recipes'/f'{id}_unpack.json').read_text())['minecraft:recipe_shapeless']['result'];check(unpack=={'item':b['item'],'count':b['count']},'Unpacking conservation')
# Execute the actual runtime siloCheck against the generated voxel structure.
r=NBT(bp/'structures/foundry/relic_silo.mcstructure').read();payload={'size':r['size'],'indices':r['structure']['block_indices'][0],'palette':[x['name'] for x in r['structure']['palette']['default']['block_palette']]}
code='''import fs from 'node:fs';import vm from 'node:vm';import {siloRequirements} from './src/siege_core.js';
const j=JSON.parse(fs.readFileSync(0,'utf8')),src=fs.readFileSync('src/siege.js','utf8');let opened=false,obstacle=false,moving=false;
const block=p=>{if(obstacle&&p.x===30&&p.z===26&&p.y===40)return {typeId:'minecraft:stone'};const [sx,sy,sz]=j.size;if(p.x<0||p.x>=sx||p.y<0||p.y>=sy||p.z<0||p.z>=sz)return {typeId:'minecraft:air'};let id=j.palette[j.indices[(p.x*sy+p.y)*sz+p.z]]||'minecraft:air';if(opened&&id==='foundry:blast_panel')id='minecraft:air';return {typeId:id};};
const fn=src.slice(src.indexOf('function siloCheck(s)'),src.indexOf('function bound(p)'));
const context={s:{pos:{x:30,y:3,z:26}},siloRequirements,d:()=>({getBlock:block}),read:()=>moving?[{hatch:true,dimension:'minecraft:overworld',origin:{x:22,z:18}}]:[],air:['minecraft:air'],coords:p=>JSON.stringify(p)};
const run=()=>vm.runInNewContext(fn+';siloCheck(s)',context);
if(!run()?.includes('CLOSED'))throw Error('Closed hatch was accepted: '+run());opened=true;if(run()!==null)throw Error('Open generated silo rejected: '+run());obstacle=true;if(!run()?.includes('40'))throw Error('Overhead obstruction not reported');obstacle=false;moving=true;if(!run()?.includes('moving'))throw Error('Moving hatch accepted');console.log('Actual siloCheck: closed/open/overhead/moving states PASS');'''
result=subprocess.run(['node','--input-type=module','-e',code],cwd=root,input=json.dumps(payload),text=True,capture_output=True);check(result.returncode==0,result.stdout+result.stderr);print(result.stdout.strip())
# Every generated door's switch resolves to its panel opening, not a nearby wall.
for p in bp.glob('structures/foundry/*.mcstructure'):
 s=NBT(p).read();sx,sy,sz=s['size'];pal=[x['name'] for x in s['structure']['palette']['default']['block_palette']];ids=s['structure']['block_indices'][0]
 def block(x,y,z):return pal[ids[(x*sy+y)*sz+z]] if ids[(x*sy+y)*sz+z]>=0 else 'void'
 for x in range(sx):
  for y in range(sy):
   for z in range(sz):
    kind=block(x,y,z)
    if kind not in ['foundry:bunker_switch','foundry:hatch_switch']:continue
    hatch=kind.endswith('hatch_switch');ox,oy,oz=(x+2,y-1,z-8) if hatch else (x+1,y-1,z+1)
    for dx in range(17 if hatch else 6):
     for dy in range(1 if hatch else 4):
      for dz in range(17 if hatch else 1):check(block(ox+dx,oy+dy,oz+dz)=='foundry:blast_panel','Switch/panel alignment '+p.name)
report=json.loads((root/'output/validation.json').read_text());report['v5_checks']=checks;report['logic_tests']=33;report['native_recipes']=len(audit['recipes']);report['packed_material_types']=len(bundles);report['silo_runtime_checks']='closed/open/obstructed/moving PASS';(root/'output/validation.json').write_text(json.dumps(report,indent=2)+'\n');print(f'PASS: {checks} native-recipe, hatch, door and live-validation checks')
