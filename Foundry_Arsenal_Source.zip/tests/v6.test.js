import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import * as core from '../src/core.js';
import * as siegeCore from '../src/siege_core.js';
import {surveyDrySite,nextSiteCandidate} from '../src/site_planning.js';
import {GUNS,ATTACHMENTS,RECIPES,GRENADES,AMMO,STATIONS,NAMES} from '../build/Foundry_Arsenal_BP/scripts/data.js';
import {MISSILES,SILO} from '../build/Foundry_Arsenal_BP/scripts/siege_data.js';
const source=name=>readFileSync(new URL('../src/'+name,import.meta.url),'utf8').replace(/^import[^\n]*\n/gm,'').replace(/export /g,'');
const signal=()=>({handlers:[],subscribe(fn){this.handlers.push(fn);},emit(value){for(const fn of this.handlers)fn(value);}});

function gunFixture(){
 const g=GUNS.find(g=>g.mode==='auto'&&!g.projectile),events={};
 for(const name of ['itemStartUse','itemStopUse','itemReleaseUse','itemCompleteUse','playerLeave','playerSpawn'])events[name]=signal();
 let component;const intervals=[],props=new Map();
 const item={typeId:'foundry:'+g.id,getDynamicProperty:k=>props.get(k),setDynamicProperty:(k,v)=>props.set(k,v),setLore(){}};
 props.set('foundry:state',JSON.stringify({uid:'',loaded:60,wear:0,attachments:{}}));
 const inventory={size:1,getItem:()=>item,setItem(){}};
 const dimension={getBlockFromRay:()=>null,getEntitiesFromRay:()=>[],spawnParticle(){},playSound(){},getEntities:()=>[]};
 const p={id:'player',selectedSlotIndex:0,isSneaking:false,dimension,location:{x:0,y:64,z:0},getComponent:id=>id==='minecraft:inventory'?{container:inventory}:undefined,getGameMode:()=>1,getHeadLocation:()=>({x:0,y:65.6,z:0}),getViewDirection:()=>({x:0,y:0,z:1}),onScreenDisplay:{setActionBar(){}},sendMessage(){}};
 const system={currentTick:0,afterEvents:{scriptEventReceive:signal()},beforeEvents:{startup:{subscribe:fn=>fn({itemComponentRegistry:{registerCustomComponent:(id,c)=>component=c},blockComponentRegistry:{registerCustomComponent(){}}})}},run:fn=>fn(),runInterval:(fn,n)=>intervals.push({fn,n})};
 const context={...core,GUNS,ATTACHMENTS,RECIPES,GRENADES,AMMO,STATIONS,NAMES,world:{afterEvents:events,getAllPlayers:()=>[p],gameRules:{pvp:true}},system,GameMode:{Creative:1,Spectator:2},ItemStack:class{},EquipmentSlot:{Head:0},EntityDamageCause:{projectile:0},installSiege(){},installExperience(){},feedbackText:()=>'',navigationText:()=>'',recordMilestone(){},combatHit(){},practiceHit(){},siegeUse:()=>false,shotVisual(){},updateVisual(){},forgetVisual(){},muzzlePoint:()=>p.getHeadLocation(),console};
 vm.runInNewContext(source('main.js'),context);
 return {events,p,item,component,system,loaded:()=>JSON.parse(props.get('foundry:state')).loaded,ticks(n){for(let i=0;i<n;i++){system.currentTick++;for(const interval of intervals)if(system.currentTick%interval.n===0)interval.fn();}}};
}
test('automatic fire repeats only between press and release, including delayed use callbacks',()=>{
 const f=gunFixture();f.component.onUse({source:f.p,itemStack:f.item});assert.equal(f.loaded(),60);f.events.itemStartUse.emit({source:f.p,itemStack:f.item});
 const first=f.loaded();assert.equal(first,59);f.ticks(30);assert(f.loaded()<first,'fresh gun must keep firing while held');
 f.events.itemStopUse.emit({source:f.p});const stopped=f.loaded();
 f.system.currentTick+=3;f.component.onUse({source:f.p,itemStack:f.item});f.ticks(30);
 assert.equal(f.loaded(),stopped,'release and late custom onUse must not restart firing');
 f.events.itemStartUse.emit({source:f.p,itemStack:f.item});assert(f.loaded()<stopped,'a new press may fire again');
});
test('release and completed-use signals both end automatic fire',()=>{
 for(const name of ['itemReleaseUse','itemCompleteUse']){
  const f=gunFixture();f.events.itemStartUse.emit({source:f.p,itemStack:f.item});f.events[name].emit({source:f.p});const stopped=f.loaded();f.ticks(30);assert.equal(f.loaded(),stopped,name);
 }
});

test('site survey rejects water anywhere in the footprint, including frozen oceans',()=>{
 for(const type of ['minecraft:water','minecraft:flowing_water','minecraft:lava','minecraft:ice','minecraft:packed_ice','minecraft:blue_ice']){
  const dim={getTopmostBlock:({x,z})=>({typeId:x===13&&z===17?type:'minecraft:grass_block',y:64})};
  let state,result;do{result=surveyDrySite(dim,{x:0,z:0},[47,48,47],state);state=result.survey;}while(result.status==='scanning');
  assert.equal(result.status,'rejected',type);
 }
});
test('dry-land survey is bounded, resumes through unloaded terrain, and rejects steep sites',()=>{
 let loaded=false,calls=0;const dim={getTopmostBlock:({x,z})=>{calls++;return !loaded&&x===0&&z===4?undefined:{typeId:'minecraft:grass_block',y:64};}};
 let result=surveyDrySite(dim,{x:0,z:0},[47,48,47],null,8);assert.equal(result.status,'waiting');assert.equal(result.survey.cursor,4);
 loaded=true;result=surveyDrySite(dim,{x:0,z:0},[47,48,47],result.survey,8);assert.equal(result.survey.cursor,12);assert.equal(calls,13);
 while(result.status==='scanning')result=surveyDrySite(dim,{x:0,z:0},[47,48,47],result.survey);
 assert.equal(result.status,'ready');assert.equal(result.surface,64);
 const steep={getTopmostBlock:({x})=>({typeId:'minecraft:stone',y:x?80:64})};assert.equal(surveyDrySite(steep,{x:0,z:0},[2,3,2]).status,'rejected');
});
test('rejected sites advance to different saved candidates around the original anchor',()=>{
 let s={x:-1600,z:1400};const seen=new Set();
 for(let i=0;i<40;i++){s={...s,...nextSiteCandidate(s)};assert.equal(s.anchorX,-1600);assert.equal(s.anchorZ,1400);const key=s.x+','+s.z;assert(!seen.has(key));seen.add(key);assert.equal(Math.abs(s.x%16),0);assert.equal(Math.abs(s.z%16),0);}
});

function siloFixture({closed=true,blocked=false}={}){
 const props=new Map(),playerProps=new Map(),blocks=new Map(),intervals=[],forms=[],messages=[],given=[];
 const afterEvents={};for(const name of ['worldLoad','playerSpawn','playerBreakBlock'])afterEvents[name]=signal();
 const pos={x:30,y:3,z:26},id='30_3_26';
 props.set('foundry:relic_site_v2',JSON.stringify({phase:'done',layout:3,x:0,y:0,z:0}));
 props.set('foundry:silo_'+id,JSON.stringify({id,pos,loaded:'kestrel_missile',owner:null,active:false}));
 playerProps.set('foundry:bound_silo',id);playerProps.set('foundry:target',JSON.stringify({x:300,y:70,z:300}));
 const blockAt=q=>{const key=q.x+','+q.y+','+q.z;if(!blocks.has(key))blocks.set(key,{location:{...q},x:q.x,y:q.y,z:q.z,typeId:'minecraft:air',setType(type){this.typeId=type;}});return blocks.get(key);};
 const req=siegeCore.siloRequirements(pos,23);for(const q of req.base)blockAt(q).setType('foundry:silo_casing');for(const q of req.stabilizers)blockAt(q).setType('foundry:silo_stabilizer');blockAt(pos).setType('foundry:relic_controller');
 if(closed)for(let x=22;x<=38;x++)for(let z=18;z<=34;z++)blockAt({x,y:36,z}).setType('foundry:blast_panel');
 blockAt({x:20,y:37,z:26}).setType('foundry:hatch_switch');
 if(blocked)blockAt({x:30,y:40,z:26}).setType('minecraft:stone');
 const dim={id:'minecraft:overworld',getBlock:blockAt,isChunkLoaded:()=>true,getEntities:()=>[],playSound(){},runCommand:()=>({successCount:1}),spawnEntity:()=>({triggerEvent(){},setDynamicProperty(){},isValid:true})};
 for(const block of blocks.values())block.dimension=dim;
 const p={id:'operator',name:'Operator',dimension:dim,location:{x:30,y:3,z:25},getDynamicProperty:k=>playerProps.get(k),setDynamicProperty:(k,v)=>playerProps.set(k,v),sendMessage:m=>messages.push(m)};
 const world={afterEvents,getDimension:()=>dim,getAllPlayers:()=>[p],getDynamicProperty:k=>props.get(k),setDynamicProperty:(k,v)=>props.set(k,v),sendMessage:m=>messages.push(m)};
 const system={currentTick:0,beforeEvents:{startup:{subscribe(){}}},run:fn=>fn(),runInterval:(fn,n)=>intervals.push({fn,n})};
 class Form{constructor(){this.buttons=[];}title(v){this.name=v;return this;}body(v){this.text=v;return this;}button(v){this.buttons.push(v);return this;}button1(v){return this.button(v);}button2(v){return this.button(v);}}
 const doors=vm.runInNewContext(source('doors.js')+';({openLaunchCover})',{world,system,console});
 const H={show:async(p,f)=>{forms.push(f);return {canceled:false,selection:0};},count:()=>1,give:(p,id)=>given.push(id),consume:()=>true,message:(p,m)=>messages.push(m)};
 const context={...siegeCore,...doors,surveyDrySite,nextSiteCandidate,world,system,MISSILES,SILO,ActionFormData:Form,MessageFormData:Form,ModalFormData:Form,console};
 const api=vm.runInNewContext(source('siege.js')+';({installSiege,openSilo,pad,confirmLaunch,abort})',context);api.installSiege(H);afterEvents.worldLoad.emit();
 return {api,p,props,forms,messages,given,blockAt,breakController(){blockAt(pos).setType('minecraft:air');afterEvents.playerBreakBlock.emit({player:p,block:blockAt(pos),brokenBlockPermutation:{type:{id:'foundry:relic_controller'}}});},job:()=>JSON.parse(props.get('foundry:strike_v2')||'null'),stored:()=>JSON.parse(props.get('foundry:silo_'+id)),ticks(n){for(let i=0;i<n;i++){system.currentTick++;for(const interval of intervals)if(system.currentTick%interval.n===0)interval.fn();}}};
}
test('controller and targeting computer each expose only three main actions and link automatically',async()=>{
 const f=siloFixture();await f.api.openSilo(f.p,f.blockAt({x:30,y:3,z:26}));
 assert.equal(f.forms[0].buttons.length,3);assert.equal(f.forms[1].buttons.length,3);assert.equal(f.stored().owner,f.p.id);
});
test('launch automatically opens a closed cover and waits before consuming the stored missile',async()=>{
 const f=siloFixture();await f.api.confirmLaunch(f.p);assert.equal(f.job().phase,'arming');assert.equal(f.stored().loaded,'kestrel_missile');
 f.ticks(2);assert.equal(f.job().phase,'arming');assert.equal(f.stored().loaded,'kestrel_missile');
 f.ticks(40);assert.equal(f.job().phase,'countdown');assert.equal(f.stored().loaded,null);assert.equal(f.blockAt({x:30,y:36,z:26}).typeId,'minecraft:air');
});
test('blocked launch restores the payload and reports the obstruction; cancel also preserves it',async()=>{
 const f=siloFixture({closed:false,blocked:true});await f.api.confirmLaunch(f.p);f.ticks(2);assert.equal(f.job(),null);assert.equal(f.stored().loaded,'kestrel_missile');assert(f.messages.some(m=>m.includes('Overhead path blocked')));
 const canceled=siloFixture();await canceled.api.confirmLaunch(canceled.p);canceled.api.abort('Canceled');assert.equal(canceled.job(),null);assert.equal(canceled.stored().loaded,'kestrel_missile');
});
test('breaking a controller during preparation or countdown returns one missile without duplication',async()=>{
 for(const closed of [true,false]){
  const f=siloFixture({closed});await f.api.confirmLaunch(f.p);if(!closed)f.ticks(1);
  assert.equal(f.job().phase,closed?'arming':'countdown');f.breakController();
  assert.equal(f.job(),null);assert.equal(f.stored().loaded,null);assert.equal(f.stored().active,false);assert.deepEqual(f.given,['foundry:kestrel_missile']);
  f.ticks(40);assert.equal(f.job(),null);assert.equal(f.given.length,1);
 }
});
