from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from catalog import GUNS
from release import VERSION, VERSION_TAG
from render_review import NBT
BP=ROOT/'build/Foundry_Arsenal_BP';RP=ROOT/'build/Foundry_Arsenal_RP'
checks=0
def check(v,msg):
 global checks
 checks+=1
 assert v,msg
props=json.loads((BP/'entities/player.json').read_text())['minecraft:entity']['description']['properties']
for key in ['armed','kick','reload','aim']:check(props['foundry:'+key]['client_sync'],'Visual property synchronized')
animations=json.loads((RP/'animations/guns.animation.json').read_text())['animations']
for g in GUNS:
 geo=json.loads((RP/'models/entity'/f'{g["id"]}.geo.json').read_text())['minecraft:geometry'][0];bones=geo['bones'];names={b['name'] for b in bones}
 check(len(names)==len(bones),'Unique bones');check({'magazine','action','weapon','mount','fp_hands','flash'}<=names,'Functional rig bones')
 check(all(b.get('parent') in names or 'parent' not in b for b in bones),'No orphan bones')
 a=json.loads((RP/'attachables'/f'{g["id"]}.json').read_text())['minecraft:attachable']['description'];check(a['animations']['first']!=a['animations']['third'],'Distinct FP/TP animations')
 for name in a['animations'].values():check(name in animations,'Animation reference '+name)
 for name in a['animations'].values():check(set(animations[name]['bones'])<=names,'Animation targets existing bones')
# Survival access check, with the structure's saved block data rather than generator assumptions.
r=NBT(BP/'structures/foundry/relic_silo.mcstructure').read();sx,sy,sz=r['size'];pal=r['structure']['palette']['default']['block_palette'];idx=r['structure']['block_indices'][0]
def block(p):
 x,y,z=p
 if not(0<=x<sx and 0<=y<sy and 0<=z<sz):return 'solid'
 i=idx[(x*sy+y)*sz+z]
 return 'solid' if i<0 else pal[i]['name'].split(':')[-1]
open_types={'air','ladder','redstone_torch','blast_panel'}
def space(p):return block(p) in open_types and block((p[0],p[1]+1,p[2])) in open_types
from collections import deque
start=(8,33,0);queue=deque([start]);seen={start};reachable=False
while queue:
 x,y,z=queue.popleft()
 if abs(x-30)+abs(z-26)<=4 and y<=4:reachable=True;break
 candidates=[]
 for dx,dz in [(1,0),(-1,0),(0,1),(0,-1)]:
  for dy in [1,0,-1,-2,-3]:
   q=(x+dx,y+dy,z+dz)
   if space(q) and (block((q[0],q[1]-1,q[2])) not in open_types or block(q)=='ladder'):
    if dy<=0 or block((x,y+2,z)) in open_types:candidates.append(q)
 if block((x,y,z))=='ladder' or block((x,y-1,z))=='ladder':
  candidates.extend([(x,y+1,z),(x,y-1,z)])
 for q in candidates:
  if q not in seen and space(q):seen.add(q);queue.append(q)
check(reachable,'Walk/climb route from surface entrance to silo controller')
# Lean chest tables contain no high-end endgame materials or guaranteed guns.
for p in BP.glob('loot_tables/chests/*.json'):
 pools=json.loads(p.read_text())['pools'];check(len(pools)==4,'Sparse chest pool count')
 for pool in pools:
  for e in pool['entries']:
   check(not any(v in e.get('name','') for v in ['diamond','netherite','stellar_core','power_cell','guidance_matrix']),'No high-value chest resource')
 check(pools[-1]['entries'][0]=={'type':'empty','weight':96},'Rare-item pool is 96% empty')
report=json.loads((ROOT/'output/validation.json').read_text());report['presentation_checks']=checks;report['silo_access_route']='PASS';report['version']=VERSION_TAG;(ROOT/'output/validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(f'PASS: {checks} rig/loot/access checks. Silo entrance-to-controller path found.')
