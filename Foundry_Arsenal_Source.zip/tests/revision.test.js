import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
const main=readFileSync(new URL('../src/main.js',import.meta.url),'utf8');
const explosion=main.slice(main.indexOf('function explode(f)'),main.indexOf('function tickProjectiles()'));
for(const kind of ['frag','fire','ice','shock'])test(`${kind}: native terrain explosion, no second scripted damage pass`,()=>{
 const blasts=[],f={kind,pos:{x:2,y:65,z:-8},radius:4,owner:{isValid:true},dimension:{playSound(){},createExplosion(...a){blasts.push(a);return true;},getEntities(){throw Error('duplicate damage pass');}}};
 vm.runInNewContext(explosion+';explode(f)',{f,clouds:[],particle(){},add:(a,b)=>a,report:(s,e)=>{throw e;}});
 assert.equal(blasts.length,1);assert.equal(blasts[0][2].breaksBlocks,true);assert.equal(blasts[0][2].causesFire,kind==='fire');assert.equal(blasts[0][2].source,f.owner);
});
for(const kind of ['smoke','flash'])test(`${kind}: non-destructive utility payload`,()=>{
 let blasts=0;const f={kind,pos:{x:0,y:65,z:0},radius:4,owner:{isValid:true},dimension:{playSound(){},createExplosion(){blasts++;},getEntities(){return [];}}};
 vm.runInNewContext(explosion+';explode(f)',{f,clouds:[],particle(){},add:(a,b)=>a});assert.equal(blasts,0);
});
test('laser lock saves immutable coordinates; changing aim does not retarget launch',()=>{
 const src=readFileSync(new URL('../src/siege.js',import.meta.url),'utf8');
 const lock=src.slice(src.indexOf('function designate(p)'),src.indexOf('export async function siegeManual'));
 const store=new Map();let hit={block:{x:-21,y:68,z:31}},opened=0;
 const p={getBlockFromViewDirection:()=>hit,setDynamicProperty:(k,v)=>store.set(k,v)};
 const setTarget=(p,t)=>p.setDynamicProperty('foundry:target',JSON.stringify(t));
 vm.runInNewContext(lock+';designate(p)',{p,setTarget,validTarget:()=>true,privateParticle(){},pad(){opened++;},tell(){}});
 hit={block:{x:999,y:88,z:222}};
 assert.deepEqual(JSON.parse(store.get('foundry:target')),{x:-21,y:69,z:31});assert.equal(store.get('foundry:laser_mode'),false);assert.equal(opened,1);
});
