# Foundry Arsenal 0.7 design references

This update compares documented features from established Java mods. These are design references, not a measured popularity ranking. Author documentation and the linked quest source were read; the Java mods were not installed or play-tested here. Foundry Arsenal remains a standalone Bedrock add-on, with original assets and no added Java dependencies.

| Reference | Documented idea | Foundry adaptation |
| --- | --- | --- |
| [MrCrayfish's Gun Mod](https://raw.githubusercontent.com/MrCrayfish/MrCrayfishGunMod/1.19.X/README.md) | Weapon customization, scopes and headshots | Confirmed hit/headshot feedback accompanies the existing attachment system. Quiet feedback sounds and HUD cues can be toggled independently. |
| [FTB Quests item tasks](https://raw.githubusercontent.com/FTBTeam/FTB-Quests/main/common/src/main/java/dev/ftb/mods/ftbquests/quest/task/ItemTask.java) and [item rewards](https://raw.githubusercontent.com/FTBTeam/FTB-Quests/main/common/src/main/java/dev/ftb/mods/ftbquests/quest/reward/ItemReward.java) | Counted goals and item rewards | Six optional field tasks introduce the existing workshop, reloading, upgrades, exploration and combat. Rewards are small and claimable once per player; crafting remains open. |
| [Waystones](https://raw.githubusercontent.com/TwelveIterationMods/Waystones/1.21.1/README.md) | Returning to previously activated places | Operating a facility records its location. The journal remembers eight recent sites and offers compass direction/distance. Travel remains part of exploration. |
| [Immersive Engineering](https://raw.githubusercontent.com/BluSunrize/ImmersiveEngineering/1.21.1/README.md) | Themed equipment with practical purpose | Craftable practice targets turn bunker and silo interiors into useful spaces. Recycling gives unwanted weapons a modest material return and preserves their fitted attachments. |

The framed target texture, model and recipe are original. It uses normal ammunition, scores the printed rings for every placement rotation, and stores a personal range session. Resetting a session preserves lifetime bullseyes and task progress. Targets are added only to newly generated facilities.

Each optional feature is accessible through the Field Journal in the Field Manual. The existing three-action silo/controller screens remain intact. No extra launch steps are introduced.

Automated tests cover reward persistence, duplicate confirmations, combat attribution, target obstruction and rotation, session resets, navigation, and recycling after inventory changes. The Bedrock client still needs to verify rendering, actual input events, sound assets and multiplayer behavior; see the smoke test in README.md.
