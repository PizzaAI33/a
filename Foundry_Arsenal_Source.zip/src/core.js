// Pure gameplay math. All values describe Minecraft gameplay, not real firearms.
export const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
export const add = (a,b) => ({x:a.x+b.x,y:a.y+b.y,z:a.z+b.z});
export const mul = (a,k) => ({x:a.x*k,y:a.y*k,z:a.z*k});
export const length = a => Math.hypot(a.x,a.y,a.z);
export const distance = (a,b) => Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z);
export const normalize = a => mul(a,1/(length(a)||1));
export function spreadRay(direction,spread,random=Math.random) {
 return normalize(add(direction,{x:(random()-.5)*spread*2,y:(random()-.5)*spread*2,z:(random()-.5)*spread*2}));
}
export function compatible(gun,attachment) {
 if (attachment.categories && !attachment.categories.includes(gun.category)) return false;
 if (gun.category==='Launchers') return ['optic','stock'].includes(attachment.slot);
 if (gun.style==='revolver' && attachment.slot==='magazine') return false;
 if (gun.category==='Pistols' && ['stock','underbarrel'].includes(attachment.slot)) return false;
 return true;
}
export function stats(gun,state,attachments,aiming=false) {
 const s={...gun,effect:'normal',fov:65,quiet:!!gun.quiet,night:false,laser:false};
 const equipped={...state.attachments};
 if (!equipped.optic && gun.builtInOptic) equipped.optic=gun.builtInOptic;
 for (const id of Object.values(equipped)) {
  const a=attachments[id]; if(!a) continue;
  if (a.capacity) s.capacity=Math.floor(s.capacity*a.capacity);
  if (a.reload) s.reload*=a.reload;
  if (a.accuracy && (!a.crouchOnly||aiming)) s.spread*=a.accuracy;
  if (a.damage) s.damage*=a.damage;
  if (a.range) s.range*=a.range;
  if (a.effect) s.effect=a.effect;
  if (a.fov) s.fov=a.fov;
  if (a.quiet) s.quiet=true;
  if (a.night) s.night=true;
  if (a.laser) s.laser=true;
 }
 if (aiming) s.spread*=.35;
 s.reload=Math.max(10,Math.round(s.reload));
 s.range=Math.min(240,s.range);
 return s;
}
export function freshState() {return {uid:'',loaded:0,wear:0,attachments:{}};}
export function parseState(raw) {
 let s; try{s=JSON.parse(raw);}catch{return freshState();}
 if (!s || typeof s!=='object') return freshState();
 return {uid:typeof s.uid==='string'?s.uid:'',loaded:clamp(Math.floor(Number(s.loaded)||0),0,250),wear:clamp(Number(s.wear)||0,0,1000),attachments:s.attachments&&typeof s.attachments==='object'?s.attachments:{}};
}
export function inventoryTotals(items) {
 const totals={}; for(const i of items) if(i) totals[i.typeId]=(totals[i.typeId]||0)+i.amount;return totals;
}
export function canAfford(totals,cost) {return Object.entries(cost).every(([id,n])=>(totals[id]||0)>=n);}
export function reloadPlan(loaded,capacity,reserve) {return Math.max(0,Math.min(capacity-loaded,reserve));}
export function blastDamage(base,distance,radius) {return distance>=radius?0:Math.max(1,Math.round(base*(1-distance/radius)));}
