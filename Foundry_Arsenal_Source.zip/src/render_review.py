"""Offline geometry review, explicitly not Minecraft screenshots."""
from pathlib import Path
import json,struct,math
from PIL import Image,ImageDraw,ImageFont
from release import VERSION_TAG
ROOT=Path(__file__).resolve().parents[1];BP=ROOT/'build/Foundry_Arsenal_BP';RP=ROOT/'build/Foundry_Arsenal_RP';OUT=ROOT/'output'
class NBT:
 def __init__(self,p):self.b=p.read_bytes();self.i=0
 def num(self,f):n=struct.calcsize(f);v=struct.unpack_from(f,self.b,self.i)[0];self.i+=n;return v
 def string(self):n=self.num('<H');v=self.b[self.i:self.i+n].decode();self.i+=n;return v
 def tag(self,t):
  if t==3:return self.num('<i')
  if t==4:return self.num('<q')
  if t==8:return self.string()
  if t==9:
   k=self.num('B');return [self.tag(k) for _ in range(self.num('<i'))]
  if t==10:
   d={}
   while True:
    t=self.num('B')
    if not t:return d
    k=self.string();d[k]=self.tag(t)
 def read(self):self.num('B');self.string();return self.tag(10)
COLORS={'air':None,'stone':(112,117,119),'polished_andesite':(139,148,149),'polished_blackstone_bricks':(57,62,67),'iron_bars':(91,102,103),'glass':(109,166,173),'sea_lantern':(202,228,214),'spruce_planks':(118,88,58),'chest':(140,100,51),'ladder':(129,105,68),'silo_casing':(95,109,109),'silo_stabilizer':(204,177,83),'relic_controller':(83,119,97),'field_console':(76,141,112),'missile_fabricator':(135,153,90),'redstone_torch':(229,89,60),'blast_panel':(83,98,100),'hatch_switch':(88,177,127),'bunker_switch':(88,177,127)}
COLORS.update(stone_bricks=(132,133,126),polished_deepslate=(57,66,78),deepslate_bricks=(66,74,84),deepslate_tiles=(55,65,74),dark_oak_planks=(91,72,53),quartz_block=(220,221,205),vent_grille=(52,67,75),hazard_trim=(213,166,73),status_screen=(36,93,77),facility_light=(210,236,229),radar_dish=(119,143,147),range_target=(221,157,78))
faces=[([0,1,3,2],.65),([4,6,7,5],1),([0,4,5,1],.76),([2,3,7,6],.9),([0,2,6,4],.82),([1,5,7,3],1.12)]
def mesh_cube(o,size,color,rotation=None,pivot=None):
 verts=[[o[0]+size[0]*x,o[1]+size[1]*y,o[2]+size[2]*z] for x,y,z in [(0,0,0),(1,0,0),(0,1,0),(1,1,0),(0,0,1),(1,0,1),(0,1,1),(1,1,1)]]
 if rotation:
  p=pivot or o
  for v in verts:
   for i in range(3):v[i]-=p[i]
   for axis,angle in enumerate(rotation):
    if angle:
     a,b=[(1,2),(2,0),(0,1)][axis];c,s=math.cos(math.radians(angle)),math.sin(math.radians(angle));v[a],v[b]=v[a]*c-v[b]*s,v[a]*s+v[b]*c
   for i in range(3):v[i]+=p[i]
 return [([verts[i] for i in inds],tuple(min(255,int(c*shade)) for c in color)) for inds,shade in faces]
def project(v):x,y,z=v;return (x-z)*.866,(x+z)*.4-y

def render(mesh,width,height):
 im=Image.new('RGB',(width,height),'#14222d');dr=ImageDraw.Draw(im)
 projected=[project(v) for p,c in mesh for v in p];minx=min(x for x,y in projected);maxx=max(x for x,y in projected);miny=min(y for x,y in projected);maxy=max(y for x,y in projected)
 scale=min((width-30)/(maxx-minx),(height-30)/(maxy-miny));ox=(width-(maxx-minx)*scale)/2;oy=(height-(maxy-miny)*scale)/2
 for poly,color in sorted(mesh,key=lambda face:sum(v[0]+v[2]+v[1]*1.8 for v in face[0])/len(face[0])):
  points=[(ox+(project(v)[0]-minx)*scale,oy+(project(v)[1]-miny)*scale) for v in poly];dr.polygon(points,fill=color)
 return im

def structure(name,cut=False):
 r=NBT(BP/'structures/foundry'/f'{name}.mcstructure').read();sx,sy,sz=r['size'];palette=r['structure']['palette']['default']['block_palette'];indices=r['structure']['block_indices'][0];blocks={}
 for x in range(sx):
  for y in range(sy):
   for z in range(sz):
    idx=indices[(x*sy+y)*sz+z]
    if idx<0:continue
    name=palette[idx]['name'].split(':')[-1]
    if name=='air':continue
    if cut and x>=18 and y>4 and (x>30 or z>26):continue
    blocks[(x,y,z)]=COLORS.get(name,(110,124,124))
 mesh=[]
 for (x,y,z),col in blocks.items():
  if col in [COLORS['radar_dish'],COLORS['range_target']]:
   name='radar_dish' if col==COLORS['radar_dish'] else 'range_target';mesh.extend(model('../blocks/'+name,translation=[x+.5,y,z+.5],scale=1/16));continue
  for poly,c in mesh_cube([x,y,z],[1,1,1],col):
   cx,cy,cz=[sum(v[i] for v in poly)/4 for i in range(3)];nx=x+(-1 if cx==x else 1 if cx==x+1 else 0);ny=y+(-1 if cy==y else 1 if cy==y+1 else 0);nz=z+(-1 if cz==z else 1 if cz==z+1 else 0)
   if (nx,ny,nz) not in blocks:mesh.append((poly,c))
 if cut:mesh+=model('silo_missile',translation=[30.5,4,26.5],scale=1/16)
 return mesh

def model(name,translation=None,scale=1):
 geo=json.loads((RP/'models/entity'/f'{name}.geo.json').read_text())['minecraft:geometry'][0];mesh=[]
 colors=[(145,155,147),(54,65,71),(98,113,112),(173,89,56),(59,67,60),(103,112,99)] if name=='silo_missile' else [(56,66,73),(107,111,96),(119,132,140),(243,198,99),(61,68,63),(103,112,99)]
 for bone in geo['bones']:
  if bone['name'] in ['fp_hands','support_hand','flash','case']:continue
  if bone['name'].startswith('optic_') and bone['name']!='optic_1':continue
  for c in bone.get('cubes',[]):
   uv=c.get('uv',{});idx=int(uv.get('north',{}).get('uv',[0])[0]/8) if isinstance(uv,dict) else 0
   texpath=RP/'textures'/('blocks' if name.startswith('../blocks/') else 'entity' if name=='silo_missile' else 'models')/(name.split('/')[-1]+'.png')
   tex=Image.open(texpath).convert('RGB');col=tex.getpixel((min(tex.width-1,idx*8+4),4))
   faces=mesh_cube(c['origin'],c['size'],col,c.get('rotation'),c.get('pivot'))
   if translation:faces=[([[v[i]*scale+translation[i] for i in range(3)] for v in poly],color) for poly,color in faces]
   mesh.extend(faces)
 return mesh

def main():
 im=Image.new('RGB',(1900,1810),'#101a24');d=ImageDraw.Draw(im);font=lambda n:ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',n)
 d.text((40,26),'FOUNDRY ARSENAL / '+VERSION_TAG,font=font(38),fill='#e1e8df');d.text((40,79),'Generated geometry review • not Minecraft screenshots',font=font(19),fill='#a9bbb9')
 panels=[(structure('bunker_'+str(i)),(35+i*620,135,600,370),label) for i,label in enumerate(['Relay outpost / radar and communications','Armory vault / heavy ribs and ventilation','Expedition depot / covered loading bay'])]
 panels += [(structure('relic_silo'),(35,575,900,570),'Relic facility / landing apron / reinforced cover / roof plant'),(structure('relic_silo',True),(975,575,890,570),'Cutaway / service decks / machinery / operations annex'),(model('h_k_hk416'),(35,1210,770,240),'Rebuilt rig / optics / separate magazine and action'),(model('silo_missile'),(845,1210,430,240),'Apex / approximately 20 blocks tall'),(model('../blocks/radar_dish'),(1335,1210,480,240),'Original craftable relay radar')]
 for mesh,(x,y,w,h),label in panels:
  im.paste(render(mesh,w,h),(x,y));d.text((x,y+h+10),label,font=font(16),fill='#a9c4b3')
 d.text((40,1530),'60 firearms  /  simple launch controls  /  dry-land relic sites  /  three distinct bunker themes',font=font(21),fill='#c6cd9e')
 for i,(id,label) in enumerate([('gunsmith_bench','Gunsmith / vice'),('ammo_press','Ammunition press'),('attachment_bench','Attachment workbench'),('missile_fabricator','Missile fabricator'),('alloy_forge','Alloy forge')]):
  x=35+i*372;im.paste(render(model('../blocks/'+id),350,170),(x,1585));d.text((x,1765),label,font=font(16),fill='#a9c4b3')
 im.save(OUT/'Foundry_Arsenal_Preview.png')
if __name__=='__main__':main()
