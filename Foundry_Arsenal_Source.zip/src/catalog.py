"""Fictional Minecraft balance values; not real-world weapon specifications."""
import re

NS = 'foundry'
BASE = {
 'Pistols': dict(damage=6, range=48, spread=.025, interval=5, reload=30, ammo='light_rounds', tier=1, mode='semi', pellets=1),
 'SMGs': dict(damage=4, range=48, spread=.037, interval=2, reload=42, ammo='light_rounds', tier=2, mode='auto', pellets=1),
 'Assault rifles': dict(damage=7, range=86, spread=.023, interval=3, reload=48, ammo='rifle_rounds', tier=2, mode='auto', pellets=1),
 'Battle rifles': dict(damage=10, range=100, spread=.029, interval=4, reload=54, ammo='heavy_rounds', tier=3, mode='auto', pellets=1),
 'Marksman rifles': dict(damage=13, range=132, spread=.012, interval=10, reload=52, ammo='heavy_rounds', tier=3, mode='semi', pellets=1),
 'Sniper rifles': dict(damage=23, range=180, spread=.006, interval=24, reload=65, ammo='precision_rounds', tier=4, mode='semi', pellets=1),
 'Shotguns': dict(damage=3, range=28, spread=.11, interval=17, reload=56, ammo='shells', tier=2, mode='semi', pellets=8),
 'Machine guns': dict(damage=6, range=94, spread=.044, interval=2, reload=100, ammo='rifle_rounds', tier=3, mode='auto', pellets=1),
 'Launchers': dict(damage=24, range=100, spread=.018, interval=24, reload=85, ammo='rocket', tier=4, mode='semi', pellets=1),
}
# Name | magazine | optional style. Each is a distinct item, model and balance row.
ROWS = {
 'Pistols': '''Glock 17|17
Glock 19|15
Glock 18|19|auto
Glock 21|13
Glock 34|17
H&K USP|12
H&K P30|15
H&K VP9|17
H&K Mk 23|12
SIG Sauer P226|15
SIG Sauer P320|17
Beretta 92FS|15
Beretta M9A3|17
FN Five-seveN|20
FN FNX-45|15
Colt M1911|7|wood
CZ 75|16
Desert Eagle|7|silver
Smith & Wesson 686|6|revolver
Ruger GP100|6|revolver''',
 'SMGs': '''H&K MP5|30
H&K MP5K|30
H&K MP7|40
H&K UMP45|25
FN P90|50|bullpup
KRISS Vector|25
IMI Uzi|32
CZ Scorpion EVO 3|30
SIG Sauer MPX|30
Beretta PMX|30
Brugger & Thomet APC9|30
Thompson M1A1|30|wood
PP-19 Bizon|64
PP-2000|44
Steyr TMP|30''',
 'Assault rifles': '''AK-47|30|wood
AKM|30|wood
AK-74|30|wood
AK-74M|30
AK-12|30
AK-103|30
AK-105|30
AKS-74U|30|wood
H&K HK416|30
H&K HK433|30
H&K G36|30
H&K G36C|30
Colt M4A1|30
Colt M16A4|30|burst
FN SCAR-L|30|tan
FN F2000|30|bullpup
Steyr AUG A3|30|bullpup
FAMAS F1|25|bullpup
IWI Tavor X95|30|bullpup
IWI Galil ACE|30
SIG Sauer SG 550|30
SIG Sauer MCX|30
CZ Bren 2|30|tan
Daewoo K2|30
QBZ-95|30|bullpup''',
 'Battle rifles': '''H&K G3|20
H&K HK417|20
FN FAL|20
FN SCAR-H|20|tan
Springfield M14|20|wood
IWI Galil ACE 52|20
SIG Sauer SG 751|20
SIG Sauer MCX Spear|20|tan
Beretta ARX200|20
Howa Type 64|20|wood''',
 'Marksman rifles': '''H&K G28|20|tan
H&K PSG1|20
SVD Dragunov|10|wood
SVU|10|bullpup
Mk 12 SPR|20
M110 SASS|20|tan
SR-25|20
FN SCAR 20S|20|tan
M14 EBR|20
VSS Vintorez|10|wood''',
 'Sniper rifles': '''Accuracy International AWM|5|green
Accuracy International AX50|5|tan
Barrett M82A1|10
Barrett M107|10|tan
Barrett MRAD|10|tan
CheyTac M200|7|tan
Remington M700|5|wood
Sako TRG-42|5|green
Steyr SSG 08|10
Mosin-Nagant|5|wood''',
 'Shotguns': '''Remington 870|8|wood
Mossberg 500|8
Mossberg 590|8
Benelli M4|7
Benelli M3|8
Franchi SPAS-12|8
Saiga-12|10|auto
AA-12|20|auto
Kel-Tec KSG|14|bullpup
Winchester Model 1897|5|wood''',
 'Machine guns': '''FN M249|100
FN M240|100
FN Minimi|100
H&K MG4|100
H&K MG5|100
PKM|100|wood
PKP Pecheneg|100
RPK-74|45|wood
IWI Negev|100
MG3|100''',
 'Launchers': '''M79|1|grenade
H&K M320|1|grenade
Milkor MGL|6|grenade
GM-94|3|grenade
China Lake Launcher|3|grenade
RPG-7|1|rocket
RPG-29|1|rocket
M72 LAW|1|rocket
AT4|1|rocket
Carl Gustaf M4|1|rocket'''
}

def slug(s):
 return re.sub(r'[^a-z0-9]+','_',s.lower()).strip('_')

# Curated roster: preserve recognizable silhouettes instead of near-duplicate variants.
SELECTION = {
 'Pistols':[0,1,2,5,9,15,17,18],
 'SMGs':[0,2,3,4,5,6,7,11],
 'Assault rifles':[0,2,4,7,8,10,12,13,14,16,17,18,21,22],
 'Battle rifles':[0,1,2,3],
 'Marksman rifles':[0,2,5,8,9],
 'Sniper rifles':[0,2,5,6,9],
 'Shotguns':[0,1,3,5,7,8],
 'Machine guns':[0,1,3,5,7],
 'Launchers':[0,1,2,5,8],
}
ROWS={cat:'\n'.join(rows.splitlines()[i] for i in SELECTION[cat]) for cat,rows in ROWS.items()}
GUNS=[]
for cat, rows in ROWS.items():
 for n,line in enumerate(rows.splitlines()):
  name,cap,*style=line.split('|'); style=style[0] if style else 'black'
  g={**BASE[cat], 'id':slug(name), 'name':name, 'category':cat, 'capacity':int(cap), 'style':style}
  g['damage']+=n%3-1
  g['range']+=4*(n%4)
  g['reload']+=2*(n%5)
  g['spread']=round(g['spread']*(.85+.05*(n%7)),4)
  if style in ['auto','burst']:g['mode']=style
  if g['mode']=='burst':g['burst']=3
  if cat=='Launchers':
   g.update(projectile=style,ammo='grenade_round' if style=='grenade' else 'rocket',blast=3.2 if style=='grenade' else 4.6)
  if style=='revolver':g.update(damage=10,interval=9,ammo='heavy_rounds')
  if name=='Desert Eagle':g.update(damage=12,interval=9,ammo='heavy_rounds')
  if name=='Glock 18':g['interval']=2
  if name in ['VSS Vintorez','H&K MP5K']:g['quiet']=True
  if cat=='Sniper rifles':g['builtInOptic']='scope_4x'
  if cat=='Marksman rifles':g['builtInOptic']='scope_2x'
  GUNS.append(g)
assert len(GUNS)==60

ATTACHMENTS={
 'red_dot':dict(name='Red-dot Sight',slot='optic',accuracy=.82,fov=58,tier=1),
 'holographic':dict(name='Holographic Sight',slot='optic',accuracy=.74,fov=50,tier=2),
 'scope_2x':dict(name='2x Scope',slot='optic',accuracy=.65,fov=38,tier=2),
 'scope_4x':dict(name='4x Scope',slot='optic',accuracy=.48,fov=22,tier=3),
 'scope_8x':dict(name='8x Scope',slot='optic',accuracy=.34,fov=12,tier=4),
 'night_scope':dict(name='Night-vision Scope',slot='optic',accuracy=.55,fov=28,night=True,tier=4),
 'suppressor':dict(name='Suppressor',slot='muzzle',quiet=True,damage=.92,tier=2),
 'compensator':dict(name='Compensator',slot='muzzle',accuracy=.80,tier=2),
 'long_barrel':dict(name='Long Barrel',slot='muzzle',range=1.25,accuracy=.90,tier=3),
 'choke':dict(name='Shotgun Choke',slot='muzzle',accuracy=.52,categories=['Shotguns'],tier=2),
 'vertical_grip':dict(name='Vertical Grip',slot='underbarrel',accuracy=.78,tier=2),
 'angled_grip':dict(name='Angled Grip',slot='underbarrel',accuracy=.88,reload=.90,tier=2),
 'bipod':dict(name='Bipod',slot='underbarrel',accuracy=.62,crouchOnly=True,tier=3),
 'laser':dict(name='Laser Sight',slot='underbarrel',accuracy=.72,laser=True,tier=3),
 'extended_mag':dict(name='Extended Magazine',slot='magazine',capacity=1.5,reload=1.12,tier=2),
 'drum_mag':dict(name='Drum Magazine',slot='magazine',capacity=2,reload=1.40,tier=3),
 'quick_mag':dict(name='Quick-change Magazine',slot='magazine',reload=.65,tier=2),
 'light_stock':dict(name='Lightweight Stock',slot='stock',reload=.88,accuracy=1.08,tier=2),
 'precision_stock':dict(name='Precision Stock',slot='stock',accuracy=.75,tier=3),
 'incendiary_core':dict(name='Ember Core',slot='payload',effect='fire',tier=4),
 'cryo_core':dict(name='Frost Core',slot='payload',effect='ice',tier=4),
 'shock_core':dict(name='Arc Core',slot='payload',effect='shock',tier=4),
 'venom_core':dict(name='Venom Core',slot='payload',effect='poison',tier=4),
 'piercing_core':dict(name='Piercing Core',slot='payload',effect='piercing',tier=4),
}
AMMO={'light_rounds':'Light Rounds','rifle_rounds':'Rifle Rounds','heavy_rounds':'Heavy Rounds','precision_rounds':'Precision Rounds','shells':'Shotgun Shells','grenade_round':'Launcher Grenade','rocket':'Rocket'}
ORES={
 'zinc':dict(name='Zinc',color='#b8cebb',y=[0,80],vein=9,tries=10),
 'cobalt':dict(name='Cobalt',color='#448fec',y=[-40,40],vein=7,tries=7),
 'titanium':dict(name='Titanium',color='#c2c9e6',y=[-56,8],vein=5,tries=5),
 'tungsten':dict(name='Tungsten',color='#8b9b71',y=[-60,-16],vein=4,tries=4),
 'sulfur':dict(name='Sulfur',color='#ead255',y=[-16,64],vein=8,tries=8),
 'fluxite':dict(name='Fluxite',color='#b76bfb',y=[-60,-32],vein=3,tries=3),
}
MATERIALS={
 'raw_zinc':'Raw Zinc','raw_cobalt':'Raw Cobalt','raw_titanium':'Raw Titanium','raw_tungsten':'Raw Tungsten',
 'zinc_ingot':'Zinc Ingot','cobalt_ingot':'Cobalt Ingot','titanium_ingot':'Titanium Ingot','tungsten_ingot':'Tungsten Ingot',
 'sulfur_dust':'Sulfur Dust','fluxite_crystal':'Fluxite Crystal','steel_plate':'Steel Plate','brass_alloy':'Brass Alloy',
 'reinforced_alloy':'Reinforced Alloy','polymer':'Polymer Composite','mechanism':'Mechanism Module',
 'receiver':'Receiver Module','barrel':'Barrel Module','lens':'Optical Lens','circuit':'Control Circuit','power_cell':'Flux Power Cell',
}
GRENADES={
 'frag_grenade':dict(name='Fragmentation Grenade',effect='frag',fuse=50,radius=5,damage=20),
 'smoke_grenade':dict(name='Smoke Grenade',effect='smoke',fuse=30,radius=6,damage=0),
 'flash_grenade':dict(name='Flash Grenade',effect='flash',fuse=30,radius=7,damage=0),
 'incendiary_grenade':dict(name='Incendiary Grenade',effect='fire',fuse=40,radius=5,damage=8),
 'cryo_grenade':dict(name='Cryo Grenade',effect='ice',fuse=40,radius=5,damage=6),
 'shock_grenade':dict(name='Shock Grenade',effect='shock',fuse=35,radius=6,damage=10),
}
GEAR={
 'field_manual':'Foundry Field Manual','maintenance_kit':'Field Maintenance Kit',
 'medkit':'Medkit','night_vision_goggles':'Night-vision Goggles','tactical_vest':'Tactical Vest',
}
STATIONS={'alloy_forge':'Alloy Forge','gunsmith_bench':'Gunsmith Bench','ammo_press':'Ammo Press','attachment_bench':'Attachment Bench'}

def recipe(id,name,station,inputs,out=None,count=1,category='Components'):
 return dict(id=id,name=name,station=station,inputs=inputs,output=out or NS+':'+id,count=count,category=category)

RECIPES=[
 recipe('steel_plate','Steel Plate ×2','alloy_forge',{'minecraft:iron_ingot':3,'minecraft:coal':1},count=2),
 recipe('brass_alloy','Brass Alloy ×3','alloy_forge',{'minecraft:copper_ingot':2,'foundry:zinc_ingot':1},count=3),
 recipe('reinforced_alloy','Reinforced Alloy ×2','alloy_forge',{'foundry:steel_plate':2,'foundry:titanium_ingot':1,'foundry:tungsten_ingot':1},count=2),
 recipe('polymer','Polymer Composite ×3','alloy_forge',{'minecraft:slime_ball':1,'minecraft:charcoal':1,'minecraft:sand':2},count=3),
 recipe('mechanism','Mechanism Module ×2','alloy_forge',{'foundry:steel_plate':1,'minecraft:redstone':2},count=2),
 recipe('receiver','Receiver Module','alloy_forge',{'foundry:steel_plate':2,'foundry:mechanism':1}),
 recipe('barrel','Barrel Module','alloy_forge',{'foundry:steel_plate':2,'foundry:cobalt_ingot':1}),
 recipe('lens','Optical Lens ×2','alloy_forge',{'minecraft:glass':2,'minecraft:quartz':1},count=2),
 recipe('circuit','Control Circuit ×2','alloy_forge',{'minecraft:copper_ingot':1,'minecraft:redstone':3,'foundry:cobalt_ingot':1},count=2),
 recipe('power_cell','Flux Power Cell ×2','alloy_forge',{'foundry:fluxite_crystal':1,'foundry:circuit':1},count=2),
]
for g in GUNS:
 t=g['tier']; ins={'foundry:receiver':1,'foundry:barrel':1,'foundry:mechanism':t,'foundry:polymer':max(1,t-1),'foundry:steel_plate':t+1}
 if t>=3:ins['foundry:reinforced_alloy']=t-1
 if t>=4:ins['foundry:circuit']=1
 RECIPES.append(recipe(g['id'],g['name'],'gunsmith_bench',ins,category=g['category']))
for i,(id,name) in enumerate(AMMO.items()):
 ins={'foundry:brass_alloy':1,'foundry:sulfur_dust':1,'minecraft:iron_nugget':3}
 n=32
 if id in ['heavy_rounds','precision_rounds']:ins['foundry:tungsten_ingot']=1;n=24
 if id=='shells':ins['foundry:polymer']=1;n=16
 if id in ['rocket','grenade_round']:ins={'foundry:steel_plate':1,'foundry:sulfur_dust':2,'minecraft:gunpowder':2,'foundry:circuit':1};n=4
 RECIPES.append(recipe(id,name+f' ×{n}','ammo_press',ins,count=n,category='Ammunition'))
for id,a in ATTACHMENTS.items():
 ins={'foundry:steel_plate':a['tier'],'foundry:polymer':1}
 if a['slot']=='optic':ins.update({'foundry:lens':1,'foundry:circuit':1})
 if a['slot']=='payload':ins={'foundry:power_cell':1,'foundry:fluxite_crystal':2,'foundry:reinforced_alloy':1}
 if a['slot']=='magazine':ins['foundry:mechanism']=1
 RECIPES.append(recipe(id,a['name'],'attachment_bench',ins,category=a['slot'].title()))
for id,g in GRENADES.items():
 ins={'foundry:steel_plate':1,'foundry:sulfur_dust':1,'minecraft:gunpowder':1}
 if g['effect'] in ['ice','shock','fire']:ins['foundry:fluxite_crystal']=1
 RECIPES.append(recipe(id,g['name']+' ×2','ammo_press',ins,count=2,category='Grenades'))
RECIPES += [
 recipe('maintenance_kit','Field Maintenance Kit','attachment_bench',{'foundry:mechanism':1,'foundry:polymer':1},category='Equipment'),
 recipe('medkit','Medkit ×2','attachment_bench',{'minecraft:paper':3,'minecraft:golden_carrot':1},count=2,category='Equipment'),
 recipe('night_vision_goggles','Night-vision Goggles','attachment_bench',{'foundry:lens':2,'foundry:circuit':2,'foundry:polymer':2},category='Equipment'),
 recipe('tactical_vest','Tactical Vest','attachment_bench',{'foundry:reinforced_alloy':3,'foundry:polymer':3},category='Equipment'),
]

# Expansion content keeps the original weapon identifiers and pack UUIDs intact.
from siege_catalog import MISSILES, MATERIALS as SIEGE_MATERIALS, BLOCKS as SIEGE_BLOCKS, RECIPES as SIEGE_RECIPES
MATERIALS.update(SIEGE_MATERIALS)
MATERIALS.update({k:v['name'] for k,v in MISSILES.items()})
STATIONS['missile_fabricator']='Missile Fabricator'
RECIPES.extend(SIEGE_RECIPES)
