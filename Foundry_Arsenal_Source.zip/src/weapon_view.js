import {VIEW} from './view_data.js';
// Shared model-space muzzle offsets. Positive right; positive up; positive forward.
export function muzzlePoint(p,g){
 const eye=p.getHeadLocation(),v=p.getViewDirection(),yaw=p.getRotation().y*Math.PI/180;
 const right={x:-Math.cos(yaw),y:0,z:-Math.sin(yaw)},up={x:-v.y*right.z,y:v.x*right.z-v.z*right.x,z:v.y*right.x};
 const cfg=VIEW[g.id],q=cfg?(p.isSneaking?(p.getProperty('foundry:optic')?cfg.aim:cfg.iron):cfg.hip):[.15,-.25,.8];
 let point={x:eye.x+right.x*q[0]+up.x*q[1]+v.x*q[2],y:eye.y+up.y*q[1]+v.y*q[2],z:eye.z+right.z*q[0]+up.z*q[1]+v.z*q[2]};
 // A barrel cannot originate beyond a nearby wall and shoot through it.
 const delta={x:point.x-eye.x,y:point.y-eye.y,z:point.z-eye.z},length=Math.hypot(delta.x,delta.y,delta.z);
 if(length>.01){const direction={x:delta.x/length,y:delta.y/length,z:delta.z/length};const wall=p.dimension.getBlockFromRay(eye,direction,{maxDistance:length,includePassableBlocks:false,includeLiquidBlocks:false});
  if(wall){const hit={x:wall.block.x+wall.faceLocation.x,y:wall.block.y+wall.faceLocation.y,z:wall.block.z+wall.faceLocation.z};point={x:hit.x-direction.x*.03,y:hit.y-direction.y*.03,z:hit.z-direction.z*.03};}}
 return point;
}
