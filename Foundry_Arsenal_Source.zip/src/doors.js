import {world,system} from '@minecraft/server';
const KEY='foundry:door_motions_v1';let motions=[],ready=false;
const panels='foundry:blast_panel',air='minecraft:air';
function save(){world.setDynamicProperty(KEY,JSON.stringify(motions));}
function geometry(block){const p=block.location,hatch=block.typeId==='foundry:hatch_switch';return {dimension:block.dimension.id,switch:{...p},hatch,origin:hatch?{x:p.x+2,y:p.y-1,z:p.z-8}:{x:p.x+1,y:p.y-1,z:p.z+1},width:hatch?17:6,height:hatch?1:4,depth:hatch?17:1,steps:hatch?9:3};}
function cells(g){const a=[];for(let x=0;x<g.width;x++)for(let y=0;y<g.height;y++)for(let z=0;z<g.depth;z++)a.push({x:g.origin.x+x,y:g.origin.y+y,z:g.origin.z+z,column:x});return a;}
function clearColumn(g,x,stage){return Math.abs(x-(g.width-1)/2)<stage;}
function occupants(g,d){return d.getEntities({location:g.origin,maxDistance:32}).some(e=>e.getComponent('minecraft:health')&&e.location.x>=g.origin.x-.5&&e.location.x<g.origin.x+g.width+.5&&e.location.y>=g.origin.y-1&&e.location.y<g.origin.y+g.height+2&&e.location.z>=g.origin.z-.5&&e.location.z<g.origin.z+g.depth+.5);}
function toggle(player,block,openOnly=false){
 if(!ready)return;const g=geometry(block),d=block.dimension,key=d.id+':'+JSON.stringify(g.switch);
 const moving=motions.find(m=>m.key===key);if(moving){if(openOnly){moving.opening=true;save();}else player.sendMessage('§6Door is moving.');return;}
 const blocks=cells(g).map(p=>d.getBlock(p));
 if(blocks.some(b=>!b)){player.sendMessage('§cDoor area is not loaded.');return;}
 if(blocks.some(b=>![air,panels].includes(b.typeId))){player.sendMessage('§cDoor area contains other blocks. Clear only the marked doorway.');return;}
 const opening=blocks.some(b=>b.typeId===panels);
 if(openOnly&&!opening)return;
 if(!opening){
  if(occupants(g,d)){player.sendMessage('§cDoor cannot close while someone is in its path.');return;}
  if(g.hatch){const raw=world.getDynamicProperty('foundry:strike_v2');let j;try{j=raw&&JSON.parse(String(raw));}catch{}
   if(j&&['arming','countdown','flight'].includes(j.phase)&&Math.abs(j.start?.x-(g.origin.x+8))<2&&Math.abs(j.start?.z-(g.origin.z+8))<2){player.sendMessage('§cLaunch interlock: cover must stay open during launch.');return;}}
 }
 motions.push({...g,key,opening,stage:opening?0:g.steps});save();player.sendMessage(opening?'§aOpening blast door…':'§6Closing blast door…');
}
export function openLaunchCover(player,pos){
 const d=world.getDimension('overworld');
 for(let y=pos.y+1;y<Math.min(319,pos.y+80);y++){
  const block=d.getBlock({x:pos.x-10,y:y+1,z:pos.z});
  if(block?.typeId==='foundry:hatch_switch')toggle(player,block,true);
 }
}
system.beforeEvents.startup.subscribe(e=>e.blockComponentRegistry.registerCustomComponent('foundry:door_switch',{onPlayerInteract:e=>{if(e.player)system.run(()=>toggle(e.player,e.block));}}));
world.afterEvents.worldLoad.subscribe(()=>{try{motions=JSON.parse(String(world.getDynamicProperty(KEY)||'[]'));}catch{motions=[];}ready=true;});
system.runInterval(()=>{
 if(!ready)return;const hadMotions=motions.length>0;
 for(let i=motions.length-1;i>=0;i--){const g=motions[i],d=world.getDimension(g.dimension);try{
  if(!g.opening&&occupants(g,d)){g.opening=true;}
  const next=Math.max(0,Math.min(g.steps,g.stage+(g.opening?1:-1))),positions=cells(g),blocks=positions.map(p=>d.getBlock(p));if(blocks.some(b=>!b))continue;
  if(blocks.some(b=>![air,panels].includes(b.typeId))){motions.splice(i,1);continue;}
  for(let n=0;n<positions.length;n++){const type=clearColumn(g,positions[n].column,next)?air:panels;if(blocks[n].typeId!==type)blocks[n].setType(type);}
  g.stage=next;d.playSound('tile.piston.out',g.origin,{volume:.7,pitch:g.hatch?.65:.9});
  if(g.stage===0||g.stage===g.steps)motions.splice(i,1);
 }catch(e){console.warn('[Foundry door] '+e);motions.splice(i,1);}}
 if(hadMotions||motions.length)save();
},4);
