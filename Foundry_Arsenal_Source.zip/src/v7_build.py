"""0.7: original range equipment and optional player progression."""
import json
from PIL import Image, ImageDraw
from release import VERSION
from siege_build import dump, image

def upgrade_v7(bp,rp):
    identifier='range_target'
    im=Image.new('RGB',(64,32),'#775d3f');d=ImageDraw.Draw(im)
    d.rectangle((0,0,31,31),fill='#e0e5d5')
    for radius,color in [(14,'#273f49'),(11,'#d5dccd'),(8,'#354e56'),(5,'#d5dccd'),(3,'#dd9d4e')]:
        d.ellipse((16-radius,16-radius,16+radius,16+radius),fill=color)
    d.line((1,16,31,16),fill='#8ca59d');d.line((16,1,16,31),fill='#8ca59d')
    d.rectangle((32,0,39,7),fill='#705638');d.line((32,1,39,1),fill='#ba9260')
    image(rp/'textures/blocks/range_target.png',im)
    texture=json.loads((rp/'textures/terrain_texture.json').read_text());texture['texture_data'][identifier]={'textures':'textures/blocks/range_target'};dump(rp/'textures/terrain_texture.json',texture)
    wooden={face:{'uv':[32,0],'uv_size':[8,8]} for face in ['north','south','east','west','up','down']}
    plate={face:dict(uv) for face,uv in wooden.items()}
    for face in ['north','south']:plate[face]={'uv':[0,0],'uv_size':[32,32]}
    dump(rp/'models/blocks/range_target.geo.json',{'format_version':'1.12.0','minecraft:geometry':[{
        'description':{'identifier':'geometry.foundry.range_target','texture_width':64,'texture_height':32,'visible_bounds_width':2,'visible_bounds_height':2,'visible_bounds_offset':[0,.5,0]},
        'bones':[{'name':'target','pivot':[0,0,0],'cubes':[{'origin':[-7,0,-3],'size':[14,2,6],'uv':wooden},{'origin':[-7,2,-1],'size':[14,14,2],'uv':plate}]}]
    }]})
    dump(bp/'blocks/range_target.json',{'format_version':'1.21.120','minecraft:block':{
        'description':{'identifier':'foundry:range_target','menu_category':{'category':'construction'},'traits':{'minecraft:placement_direction':{'enabled_states':['minecraft:cardinal_direction']}}},
        'components':{'foundry:range_target':{},'minecraft:geometry':'geometry.foundry.range_target','minecraft:material_instances':{'*':{'texture':'range_target','render_method':'opaque'}},'minecraft:collision_box':{'origin':[-7,0,-3],'size':[14,16,6]},'minecraft:selection_box':{'origin':[-7,0,-3],'size':[14,16,6]},'minecraft:destructible_by_mining':{'seconds_to_destroy':.5},'minecraft:destructible_by_explosion':{'explosion_resistance':1},'minecraft:loot':'loot_tables/blocks/range_target.json','minecraft:map_color':'#dd9d4e'},
        'permutations':[{'condition':f"query.block_state('minecraft:cardinal_direction') == '{direction}'",'components':{'minecraft:transformation':{'rotation':[0,rotation,0]}}} for direction,rotation in [('east',90),('south',180),('west',270)]]
    }})
    dump(bp/'loot_tables/blocks/range_target.json',{'pools':[{'rolls':1,'entries':[{'type':'item','name':'foundry:range_target'}]}]})
    dump(bp/'recipes/range_target.json',{'format_version':'1.20.80','minecraft:recipe_shaped':{'description':{'identifier':'foundry:range_target'},'tags':['crafting_table'],'pattern':['PPP','PRP',' S '],'key':{'P':{'item':'minecraft:oak_planks'},'R':{'item':'minecraft:redstone'},'S':{'item':'minecraft:stick'}},'result':{'item':'foundry:range_target','count':1},'unlock':[{'context':'AlwaysUnlocked'}]}})
    blocks=json.loads((rp/'blocks.json').read_text());blocks['foundry:range_target']={'sound':'wood'};dump(rp/'blocks.json',blocks)
    for lang in ['en_US','en_GB']:
        with (rp/'texts'/f'{lang}.lang').open('a') as file:file.write('tile.foundry:range_target.name=Foundry Practice Target\n')
    with (bp/'functions/foundry/demo.mcfunction').open('a') as file:file.write('give @s foundry:range_target 4\n')
    for pack in [bp,rp]:
        path=pack/'manifest.json';data=json.loads(path.read_text());data['header']['version']=VERSION
        data['header']['name']='Foundry Arsenal | '+('0.7' if pack==bp else 'Resources 0.7')
        data['header']['description']='Foundry Arsenal 0.7: practice targets, combat feedback, optional field tasks, facility navigation and weapon recycling. Client testing pending.'
        for module in data['modules']:module['version']=VERSION
        for dependency in data.get('dependencies',[]):
            if 'uuid' in dependency:dependency['version']=VERSION
        dump(path,data)

def guide_v7(out,root):
    path=out/'Foundry_Arsenal_Field_Guide.html';text=path.read_text()
    text=text.replace('0.6.0','0.7.0').replace('Foundry Arsenal | 0.6','Foundry Arsenal | 0.7').replace('Resources 0.6','Resources 0.7')
    # Keep the previous release notes as history, then lead with current controls.
    text=text.replace('<h2>Version 0.6 — current controls</h2>','<h2>Retained 0.6 controls</h2>')
    note=(root/'src/v7_notes.html').read_text();text=text.replace('<h2>Retained 0.6 controls</h2>',note+'<h2>Retained 0.6 controls</h2>')
    # An older bundled review had obsolete acceptance instructions.
    text=text.replace('matching 0.4 behavior and resource packs','matching 0.7 behavior and resource packs').replace('matching 0.6','matching 0.7')
    path.write_text(text)
