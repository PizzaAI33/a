"""0.6: a single calibrated gun transform and original facility details."""
import json, math
from PIL import Image, ImageDraw
from catalog import GUNS
from siege_build import dump, image
from polish_build import box

VERSION = [0, 6, 0]

def inverse_arm_angles():
    # Bedrock/Blockbench use Z-Y-X Euler order. Negating each angle in one
    # vector is not an inverse; transpose the guide's matrix and decompose it.
    x, y, z = map(math.radians, [95, -45, 115])
    cx, sx, cy, sy, cz, sz = math.cos(x), math.sin(x), math.cos(y), math.sin(y), math.cos(z), math.sin(z)
    r = [[cz*cy, cz*sy*sx-sz*cx, cz*sy*cx+sz*sx],
         [sz*cy, sz*sy*sx+cz*cx, sz*sy*cx-cz*sx],
         [-sy, cy*sx, cy*cx]]
    t = [list(row) for row in zip(*r)]
    return [math.degrees(math.atan2(t[2][1], t[2][2])),
            math.degrees(math.asin(-t[2][0])),
            math.degrees(math.atan2(t[1][0], t[0][0]))]

def weapon_alignment(rp):
    path = rp/'animations/guns.animation.json'
    data = json.loads(path.read_text())
    animations = data['animations']
    correction = inverse_arm_angles()
    for gun in GUNS:
        path_geo = rp/'models/entity'/f'{gun["id"]}.geo.json'
        geo = json.loads(path_geo.read_text())
        bones = geo['minecraft:geometry'][0]['bones']
        # The old cancellation bones occurred after their children. Use a
        # single bound-root rotation, with a normal parent-before-child rig.
        bones[:] = [b for b in bones if not b['name'].startswith('view_cancel_')]
        next(b for b in bones if b['name'] == 'weapon')['parent'] = 'mount'
        geo['format_version'] = '1.16.0'
        dump(path_geo, geo)
        hold = animations['animation.foundry.hold_'+gun['id']]['bones']
        hold['mount']['rotation'] = correction
        hold.pop('view_cancel_y', None)
        hold.pop('view_cancel_z', None)
        # Keep cosmetic movement around the local weapon axis, away from the
        # root calibration. Scope/iron offsets and the shared muzzle stay valid.
        hold['weapon']['rotation'] = ['-v.k * 2.5 + v.reload_curve * 12', 0, 'v.reload_curve * -10']
    third = animations['animation.foundry.third_v3']['bones']
    third.pop('view_cancel_y', None)
    third.pop('view_cancel_z', None)
    dump(path, data)

def decoration_assets(bp, rp):
    terrain = json.loads((rp/'textures/terrain_texture.json').read_text())
    blocks = json.loads((rp/'blocks.json').read_text())
    definitions = {
        'vent_grille': ('Facility Vent Grille', '#34434b', 0),
        'hazard_trim': ('Hazard Stripe Panel', '#e9b34d', 0),
        'status_screen': ('Facility Status Screen', '#172e36', 5),
        'facility_light': ('Armored Facility Light', '#d2ece5', 14),
        'radar_dish': ('Relay Radar Dish', '#778f93', 0),
    }
    for identifier, (name, color, light) in definitions.items():
        im = Image.new('RGB', (32, 32), color)
        draw = ImageDraw.Draw(im)
        draw.rectangle((0, 0, 31, 31), outline='#18272e', width=2)
        if identifier == 'hazard_trim':
            for start in range(-32, 64, 12):
                draw.polygon([(start, 0), (start+6, 0), (start-26, 32), (start-32, 32)], fill='#243139')
        elif identifier == 'vent_grille':
            for y in range(5, 29, 4):
                draw.rectangle((4, y, 27, y+1), fill='#111f26')
                draw.line((5, y-1, 26, y-1), fill='#6b8186')
        elif identifier == 'status_screen':
            draw.rectangle((4, 5, 27, 25), fill='#0b181e', outline='#627e81')
            for y in [9, 14, 19]: draw.line((7, y, 21, y), fill='#69e0aa', width=2)
            draw.rectangle((24, 9, 25, 11), fill='#eda956')
        elif identifier == 'facility_light':
            for x in [4, 15, 26]: draw.line((x, 1, x, 30), fill='#3f5960', width=2)
            draw.rectangle((2, 4, 29, 27), outline='#6a8389', width=2)
        else:
            for x in range(4, 31, 7): draw.line((x, 0, x, 31), fill='#4e6368')
            draw.line((0, 15, 31, 15), fill='#b6cec9', width=2)
        image(rp/'textures/blocks'/f'{identifier}.png', im)
        terrain['texture_data'][identifier] = {'textures': 'textures/blocks/'+identifier}
        components = {
            'minecraft:geometry': 'minecraft:geometry.full_block',
            'minecraft:material_instances': {'*': {'texture': identifier, 'render_method': 'opaque'}},
            'minecraft:destructible_by_mining': {'seconds_to_destroy': 1.5},
            'minecraft:destructible_by_explosion': {'explosion_resistance': 6},
            'minecraft:loot': 'loot_tables/blocks/'+identifier+'.json',
            'minecraft:map_color': color,
        }
        if light: components['minecraft:light_emission'] = light
        if identifier == 'radar_dish':
            cubes = [box([-5, 0, -5], [10, 2, 10], 0), box([-1, 2, -1], [2, 6, 2], 0),
                     box([-6, 7, -2], [12, 7, 1], 0, [-25, 0, 0]),
                     box([-7, 7, -1], [1, 7, 2], 0, [-25, 0, 0]),
                     box([6, 7, -1], [1, 7, 2], 0, [-25, 0, 0]),
                     box([-.5, 9, 0], [1, 1, 5], 0)]
            for cube in cubes:
                for face in cube['uv'].values(): face.update(uv=[0, 0], uv_size=[8, 8])
            dump(rp/'models/blocks/radar_dish.geo.json', {'format_version': '1.12.0', 'minecraft:geometry': [{
                'description': {'identifier': 'geometry.foundry.radar_dish', 'texture_width': 32, 'texture_height': 32,
                                'visible_bounds_width': 2, 'visible_bounds_height': 2, 'visible_bounds_offset': [0, .5, 0]},
                'bones': [{'name': 'dish', 'pivot': [0, 0, 0], 'cubes': cubes}],
            }]})
            components['minecraft:geometry'] = 'geometry.foundry.radar_dish'
            components['minecraft:collision_box'] = {'origin': [-5, 0, -5], 'size': [10, 8, 10]}
        dump(bp/'blocks'/f'{identifier}.json', {'format_version': '1.21.120', 'minecraft:block': {
            'description': {'identifier': 'foundry:'+identifier, 'menu_category': {'category': 'construction'}},
            'components': components,
        }})
        dump(bp/'loot_tables/blocks'/f'{identifier}.json', {'pools': [{'rolls': 1, 'entries': [{'type': 'item', 'name': 'foundry:'+identifier}]}]})
        dump(bp/'recipes'/f'{identifier}.json', {'format_version': '1.20.80', 'minecraft:recipe_shapeless': {
            'description': {'identifier': 'foundry:'+identifier}, 'tags': ['crafting_table'],
            'ingredients': [{'item': 'minecraft:iron_ingot'}, {'item': 'minecraft:redstone'}, {'item': 'minecraft:glass' if light else 'minecraft:stone'}],
            'result': {'item': 'foundry:'+identifier, 'count': 4 if identifier != 'radar_dish' else 1},
            'unlock': [{'context': 'AlwaysUnlocked'}],
        }})
        blocks['foundry:'+identifier] = {'sound': 'metal'}
        for language in ['en_US', 'en_GB']:
            with (rp/'texts'/f'{language}.lang').open('a') as file: file.write(f'tile.foundry:{identifier}.name={name}\n')
    dump(rp/'textures/terrain_texture.json', terrain)
    dump(rp/'blocks.json', blocks)

def upgrade_v6(bp, rp):
    weapon_alignment(rp)
    decoration_assets(bp, rp)
    for pack in [bp, rp]:
        path = pack/'manifest.json'
        data = json.loads(path.read_text())
        data['header']['version'] = VERSION
        data['header']['name'] = 'Foundry Arsenal | '+('0.6' if pack == bp else 'Resources 0.6')
        data['header']['description'] = 'Foundry Arsenal 0.6: rebuilt gun rig, press-only automatic fire, simple launch controls, dry-land relic placement and detailed facilities. Bedrock client testing pending.'
        for module in data['modules']: module['version'] = VERSION
        for dependency in data.get('dependencies', []):
            if 'uuid' in dependency: dependency['version'] = VERSION
        dump(path, data)

def guide_v6(out, root):
    import re
    path = out/'Foundry_Arsenal_Field_Guide.html'
    text = path.read_text()
    text = re.sub(r'<h2>Version 0\.[345][^<]*</h2>.*?(?=<h2>|</main>)', '', text, flags=re.S)
    text = text.replace('0.5.0', '0.6.0').replace('0.5', '0.6')
    text = text.replace('Foundry Arsenal | 60 Weapons', 'Foundry Arsenal | 0.6').replace('Models &amp; Sounds', 'Resources 0.6').replace('Models & Sounds', 'Resources 0.6')
    text = text.replace('Place it, then use it with an empty hand. Choose a recipe and confirm.', 'Use a station to open its native crafting grid and recipe book.')
    note = (root/'src/v6_notes.html').read_text()
    text = text.replace('<h2>Install & start</h2>', note+'<h2>Install & start</h2>')
    path.write_text(text)
