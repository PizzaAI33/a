import {system} from '@minecraft/server';
const states=new Map();
function state(p){if(!states.has(p.id))states.set(p.id,{shot:-100,held:false,aim:0,props:{}});return states.get(p.id);}
function prop(p,s,name,v){if(s.props[name]!==v){p.setProperty('foundry:'+name,v);s.props[name]=v;}}
export function shotVisual(p){state(p).shot=system.currentTick;}
export function updateVisual(p,g,r,itemState=null){
 const s=state(p),held=!!g;
 try{
  prop(p,s,'armed',held);const optic=itemState?.attachments?.optic||g?.builtInOptic;prop(p,s,'optic',({red_dot:1,holographic:2,scope_2x:3,scope_4x:4,scope_8x:5,night_scope:6})[optic]||0);s.aim+=(held&&p.isSneaking&&!r.ui?1-s.aim:-s.aim)*.35;
  prop(p,s,'aim',Math.round(s.aim*100)/100);
  prop(p,s,'kick',held?Math.max(0,1-(system.currentTick-s.shot)/4):0);
  const reload=held&&r.reload?Math.min(.999,Math.max(.001,1-(r.reload.end-system.currentTick)/r.reload.duration)):0;
  prop(p,s,'reload',Math.round(reload*1000)/1000);
  if(held&&!s.held)system.run(()=>{try{if(p.isValid&&s.held)p.playAnimation('animation.foundry.operator_hold',{controller:'foundry_operator',stopExpression:"!query.property('foundry:armed')",blendOutTime:.15});}catch{}});
  s.held=held;
 }catch(e){if(!s.warned){console.warn('[Foundry rig] '+e);s.warned=true;}}
}
export function forgetVisual(id){states.delete(id);}
