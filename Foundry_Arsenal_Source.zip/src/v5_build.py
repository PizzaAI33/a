"""0.5: native crafting, model-coordinate correction, doors and scoped geometry."""
import json,math,copy,itertools,hashlib,shutil
from pathlib import Path
from PIL import Image,ImageDraw
from siege_build import dump,image
from polish_build import box
from catalog import GUNS,RECIPES,STATIONS

def crafting(bp,rp):
 atlas=json.loads((rp/'textures/item_texture.json').read_text());bundles={};patterns=[];used=set()
 def recipe(id,inputs,result,count,tags):
  dump(bp/'recipes'/f'{id}.json',{'format_version':'1.20.80','minecraft:recipe_shapeless':{'description':{'identifier':'foundry:'+id},'tags':tags,'ingredients':[{'item':x} for x in inputs],'result':{'item':result,'count':count},'unlock':[{'context':'AlwaysUnlocked'}]}})
 def bundle(item,n):
  if n==1:return item
  id='bundle_'+item.replace(':','_')+'_'+str(n)
  if id in bundles:return 'foundry:'+id
  bundles[id]={'item':item,'count':n}
  # Recursive groups of at most nine slots; every material unit is conserved.
  if n<=9:inputs=[item]*n
  else:
   k,rem=divmod(n,9);inputs=[bundle(item,9)]*k+([bundle(item,rem)] if rem else [])
  assert len(inputs)<=9
  name=f'{n} × '+item.split(':')[1].replace('_',' ').title()+' (packed)'
  dump(bp/'items'/f'{id}.json',{'format_version':'1.21.120','minecraft:item':{'description':{'identifier':'foundry:'+id,'menu_category':{'category':'items'}},'components':{'minecraft:display_name':{'value':name},'minecraft:icon':id,'minecraft:max_stack_size':64}}})
  im=Image.new('RGBA',(32,32));d=ImageDraw.Draw(im);d.rectangle((3,4,28,28),fill='#746c53',outline='#bcc4ab',width=2);d.rectangle((6,7,25,13),fill='#323e43');d.text((8,15),str(n),fill='#fff0bc');image(rp/'textures/items'/f'{id}.png',im);atlas['texture_data'][id]={'textures':'textures/items/'+id}
  recipe(id,inputs,'foundry:'+id,1,['foundry:packing']);recipe(id+'_unpack',['foundry:'+id],item,n,['foundry:packing']);return 'foundry:'+id
 for id,name in STATIONS.items():
  p=bp/'blocks'/f'{id}.json';j=json.loads(p.read_text());c=j['minecraft:block']['components'];c.pop('foundry:station',None);c['minecraft:crafting_table']={'table_name':name,'crafting_tags':['foundry:'+id,'foundry:packing']};dump(p,j)
 def canonical(grid):
  rows=[grid[i:i+3] for i in range(0,9,3)];rows=[row for row in rows if any(row)]
  columns=[i for i in range(3) if any(row[i] for row in rows)];return tuple(tuple(row[min(columns):max(columns)+1]) for row in rows)
 for r in RECIPES:
  tokens=[bundle(i,n) for i,n in r['inputs'].items()];tag='foundry:'+r['station']
  for places in itertools.permutations(range(9),len(tokens)):
   grid=['']*9
   for k,t in zip(places,tokens):grid[k]=t
   sig=(tag,canonical(grid))
   if sig not in used:used.add(sig);break
  else:raise ValueError('No distinct recipe layout '+r['id'])
  rows=canonical(grid);key={};lookup={}
  for token in tokens:
   if token not in lookup:lookup[token]=chr(65+len(lookup));key[lookup[token]]={'item':token}
  pattern=[''.join(lookup.get(t,' ') for t in row) for row in rows]
  dump(bp/'recipes'/('assembly_'+r['id']+'.json'),{'format_version':'1.20.80','minecraft:recipe_shaped':{'description':{'identifier':'foundry:assembly_'+r['id']},'tags':[tag],'pattern':pattern,'key':key,'assume_symmetry':False,'result':{'item':r['output'],'count':r['count']},'unlock':[{'context':'AlwaysUnlocked'}]}})
  patterns.append({'id':r['id'],'station':r['station'],'pattern':pattern,'key':key,'raw':r['inputs']})
 dump(rp/'textures/item_texture.json',atlas);dump(bp/'crafting_audit.json',{'bundles':bundles,'recipes':patterns})

def controls(bp,rp):
 terrain=json.loads((rp/'textures/terrain_texture.json').read_text())
 for id,name in [('blast_panel','Reinforced Sliding Door Panel'),('bunker_switch','Bunker Door Switch'),('hatch_switch','Silo Cover Switch')]:
  c={'minecraft:geometry':'minecraft:geometry.full_block','minecraft:material_instances':{'*':{'texture':id,'render_method':'opaque'}},'minecraft:destructible_by_mining':{'seconds_to_destroy':3},'minecraft:destructible_by_explosion':{'explosion_resistance':30},'minecraft:loot':'loot_tables/blocks/'+id+'.json'}
  if id.endswith('switch'):c['foundry:door_switch']={};c['minecraft:light_emission']=5
  dump(bp/'blocks'/f'{id}.json',{'format_version':'1.21.120','minecraft:block':{'description':{'identifier':'foundry:'+id,'menu_category':{'category':'construction'}},'components':c}})
  dump(bp/'loot_tables/blocks'/f'{id}.json',{'pools':[{'rolls':1,'entries':[{'type':'item','name':'foundry:'+id}]}]})
  im=Image.new('RGB',(32,32),'#4b585b');d=ImageDraw.Draw(im)
  if id=='blast_panel':
   d.rectangle((1,1,30,30),outline='#a5b5b3',width=2);d.rectangle((5,4,9,27),fill='#75817c');d.rectangle((22,4,26,27),fill='#75817c')
   for x in [2,27]:
    for y in [2,27]:d.rectangle((x,y,x+2,y+2),fill='#d2b963')
  else:d.rectangle((4,4,27,27),fill='#172b2f',outline='#9fada5',width=2);d.rectangle((9,8,22,13),fill='#72c093');d.rectangle((13,16,18,25),fill='#d7b467')
  image(rp/'textures/blocks'/f'{id}.png',im);terrain['texture_data'][id]={'textures':'textures/blocks/'+id}
  for lang in ['en_US','en_GB']:
   with (rp/'texts'/f'{lang}.lang').open('a') as f:f.write('tile.foundry:'+id+'.name='+name+'\n')
  if id!='blast_panel':
   dump(bp/'recipes'/f'{id}.json',{'format_version':'1.20.10','minecraft:recipe_shapeless':{'description':{'identifier':'foundry:'+id},'tags':['crafting_table'],'ingredients':[{'item':'minecraft:iron_ingot'},{'item':'minecraft:redstone'},{'item':'minecraft:lever'}]+([{'item':'minecraft:copper_ingot'}] if id=='hatch_switch' else []),'result':{'item':'foundry:'+id,'count':1}}})
 dump(rp/'textures/terrain_texture.json',terrain)

def view_models(bp,rp):
 # Inverse of the native first-person Rz(115)*Ry(-45)*Rx(95) arm frame.
 def rotate(v,axis,deg):
  x,y,z=v;c=math.cos(math.radians(deg));s=math.sin(math.radians(deg))
  return [x,y*c-z*s,y*s+z*c] if axis==0 else [x*c+z*s,y,-x*s+z*c] if axis==1 else [x*c-y*s,x*s+y*c,z]
 def unframe(desired):
  q=[desired[0]-8.5,desired[1]-12,desired[2]-12]
  for axis,angle in [(2,-115),(1,45),(0,-95)]:q=rotate(q,axis,angle)
  return [q[0]+1,q[1]+31,q[2]+1]
 views={};p=rp/'animations/guns.animation.json';j=json.loads(p.read_text());a=j['animations']
 for g in GUNS:
  pgeo=rp/'models/entity'/f'{g["id"]}.geo.json';geo=json.loads(pgeo.read_text());bones=geo['minecraft:geometry'][0]['bones'];by={b['name']:b for b in bones}
  # The previous player's arm override must not alter the first-person calibration frame.
  by['weapon']['parent']='view_cancel_z';bones.extend([{'name':'view_cancel_y','parent':'mount','pivot':[0,0,0]},{'name':'view_cancel_z','parent':'view_cancel_y','pivot':[0,0,0]}])
  if g['category'] in ['Sniper rifles','Marksman rifles']:by['weapon']['cubes']=[c for c in by['weapon']['cubes'] if c['origin'][1]<4]
  # Hollow optics: clear center, visible frame and small red reticle instead of opaque glass.
  for n in range(1,7):
   long=n>=3;length=8 if long else 1.2;radius=1.8 if n>=4 else 1.4;cy=5.2
   cubes=[box([-radius,cy-radius,-5],[radius*2,.3,length],0),box([-radius,cy+radius-.3,-5],[radius*2,.3,length],0),box([-radius,cy-radius,-5],[.3,radius*2,length],0),box([radius-.3,cy-radius,-5],[.3,radius*2,length],0),box([-.6,3.3,-2],[1.2,.5,2],2)]
   if n==2:cubes.extend([box([-.7,cy-.05,-3.75],[1.4,.1,.05],7),box([-.05,cy-.7,-3.75],[.1,1.4,.05],7)])
   else:cubes.append(box([-.07,cy-.07,-5+length+.02],[.14,.14,.05],7))
   bones.append({'name':'optic_'+str(n),'parent':'weapon','pivot':[0,0,0],'cubes':cubes})
  scale=.55 if g['category']!='Pistols' else .75
  hip=[-3,24,-8];ads=[0,28.8-5.2*scale,-8]
  h=unframe(hip);t=unframe(ads);iron=unframe([0,28.8-3.6*scale,-8])
  anim='animation.foundry.hold_'+g['id'];a[anim]={'loop':True,'bones':{'mount':{'position':[f'{v:.5f} + v.a * ({t[i]-v:.5f} + v.iron * {iron[i]-t[i]:.5f})' for i,v in enumerate(h)],'rotation':[-95,0,0],'scale':scale},'view_cancel_y':{'rotation':[0,45,0]},'view_cancel_z':{'rotation':[0,0,-115]},'weapon':{'position':[0,'-v.reload_curve * 1.2','v.k * .7'],'rotation':['-v.k*2.5+v.reload_curve*12',0,'v.reload_curve*-16']},'fp_hands':{'scale':1}}}
  # Bind third-person grip at the documented +24 model offset, independent of FP cancellation.
  for name in ['view_cancel_y','view_cancel_z']:a['animation.foundry.third_v3']['bones'][name]={'rotation':[0,0,0]}
  a['animation.foundry.third_v3']['bones']['mount'].update(position=[0,24,0],rotation=[0,0,0])
  p2=rp/'attachables'/f'{g["id"]}.json';att=json.loads(p2.read_text());d=att['minecraft:attachable']['description'];d['animations']['first']=anim;d['animations']['optics']='animation.foundry.optics';d['scripts']['animate'].append('optics');d['scripts']['pre_animation'].append("v.iron = query.has_property('foundry:optic') ? (query.property('foundry:optic') == 0 ? 1 : 0) : 1;");dump(p2,att)
  muzzle=min(c['origin'][2] for b in bones if b['name'] in ['weapon','action'] for c in b.get('cubes',[]));muzzleY=1.4
  views[g['id']]={'hip':[-hip[0]/16,(hip[1]+muzzleY*scale-28.8)/16,-(hip[2]+muzzle*scale)/16],'aim':[0,(ads[1]+muzzleY*scale-28.8)/16,-(ads[2]+muzzle*scale)/16]}
  views[g['id']]['iron']=[0,(1.4-3.6)*scale/16,views[g['id']]['aim'][2]]
  texpath=rp/'textures/models'/f'{g["id"]}.png';tex=Image.open(texpath);ImageDraw.Draw(tex).rectangle((56,0,63,7),fill='#ff433b');image(texpath,tex)
  dump(pgeo,geo)
 a['animation.foundry.optics']={'loop':True,'bones':{'optic_'+str(n):{'scale':f"query.has_property('foundry:optic') ? (query.property('foundry:optic') == {n} ? 1 : 0) : 0"} for n in range(1,7)}}
 # Apply the stance only to third person: vanilla first-person arm guide stays intact.
 a['animation.foundry.operator_hold']['bones']={}
 dump(p,j)
 p=bp/'entities/player.json';j=json.loads(p.read_text());j['minecraft:entity']['description']['properties']['foundry:optic']={'type':'int','range':[0,6],'default':0,'client_sync':True};dump(p,j)
 (bp/'scripts/view_data.js').write_text('export const VIEW = '+json.dumps(views)+';\n')

def upgrade(bp,rp,out,root):
 crafting(bp,rp);controls(bp,rp);view_models(bp,rp)
 for name in ['doors.js','weapon_view.js']:shutil.copy(root/'src'/name,bp/'scripts'/name)
 for p in [bp/'manifest.json',rp/'manifest.json']:
  j=json.loads(p.read_text());j['header']['version']=[0,5,0];j['header']['description']='Foundry Arsenal 0.5: ammunition enforcement, native crafting grids, blast doors, corrected view transforms and impact falloff. Client verification pending.'
  for m in j['modules']:m['version']=[0,5,0]
  for d in j.get('dependencies',[]):
   if 'uuid' in d:d['version']=[0,5,0]
  dump(p,j)

def guide_v5(out,root):
 p=out/'Foundry_Arsenal_Field_Guide.html';s=p.read_text().replace('0.4','0.5')
 s=s.replace('Place it, then use it with an empty hand. Choose a recipe and confirm.','Place and use it to open the native 3×3 crafting grid and recipe book.')
 s=s.replace('Leave a clear 3×3 shaft, 23 blocks high, directly above the controller.', 'Leave a clear 3×3 launch route up to 80 blocks above the controller; open the surface cover before launch.').replace('No native R-key binding, working bipod deployment animation or visible attachment swaps.', 'No native R-key binding or working bipod deployment animation. Visible attachment changes currently cover optics only.')
 note=(root/'src/v5_notes.html').read_text();s=s.replace('<h2>Install & start</h2>',note+'<h2>Install & start</h2>');p.write_text(s)
