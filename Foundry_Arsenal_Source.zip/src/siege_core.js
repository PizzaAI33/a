export const horizontalDistance=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);
export const grid=p=>({x:Math.floor(p.x/16),z:Math.floor(p.z/16)});
export function validTarget(p) {return !!p&&[p.x,p.y,p.z].every(Number.isFinite)&&Math.abs(p.x)<=1000000&&Math.abs(p.z)<=1000000&&p.y>=-63&&p.y<=300;}
export function safety(p,target,tier) {
 const d=horizontalDistance(p,target);
 return {distance:Math.floor(d),margin:Math.floor(d-tier.danger),recommended:tier.safe,status:d<tier.danger?'DANGER':d<tier.safe?'CAUTION':'OUTSIDE MODELED BLAST'};
}
// Centered on the target block; a 250-block radius has a maximum 500-block extent.
export function craterBottom(target,tier,x,z) {
 const dx=x+.5-target.x,dz=z+.5-target.z,d2=dx*dx+dz*dz;
 if(d2>=tier.radius*tier.radius)return null;
 const depth=Math.max(1,Math.ceil(tier.depth*(1-d2/(tier.radius*tier.radius))));
 return Math.max(-63,Math.floor(target.y)-depth);
}
export function craterRegions(target,tier) {
 const minX=Math.floor((target.x-tier.radius)/128)*128,minZ=Math.floor((target.z-tier.radius)/128)*128;
 const out=[];
 for(let x=minX;x<=target.x+tier.radius;x+=128)for(let z=minZ;z<=target.z+tier.radius;z+=128){
  const nx=Math.max(x+.5,Math.min(target.x,x+127.5)),nz=Math.max(z+.5,Math.min(target.z,z+127.5));
  if(Math.hypot(nx-target.x,nz-target.z)<tier.radius)out.push({x,z});
 }
 return out.sort((a,b)=>horizontalDistance(a,target)-horizontalDistance(b,target));
}
// Runs never cross the region's loaded 8×8-chunk window; equal depth columns merge.
export function craterRuns(target,tier,region) {
 const runs=[],top=Math.min(319,Math.floor(target.y)+Math.min(80,tier.radius));
 for(let x=region.x;x<region.x+128;x++){
  let start=-1,last=null;
  for(let z=region.z;z<=region.z+128;z++){
   const bottom=z===region.z+128?null:craterBottom(target,tier,x,z);
   if(bottom!==last){if(last!==null)runs.push({x,z0:start,z1:z-1,bottom:last,top,volume:(z-start)*(top-last+1)});start=z;last=bottom;}
  }
 }
 return runs;
}
export function siloRequirements(p,height=11) {
 const base=[];for(let x=-2;x<=2;x++)for(let z=-2;z<=2;z++)base.push({x:p.x+x,y:p.y-1,z:p.z+z});
 const stabilizers=[[-2,-2],[-2,2],[2,-2],[2,2]].map(([x,z])=>({x:p.x+x,y:p.y,z:p.z+z}));
 const clearance=[];for(let y=1;y<=height;y++)for(let x=-1;x<=1;x++)for(let z=-1;z<=1;z++)clearance.push({x:p.x+x,y:p.y+y,z:p.z+z});
 return {base,stabilizers,clearance};
}

// Merge identical adjacent column runs into rectangular fill volumes.
// Splitting keeps every native fill under the 32,768-block command-size ceiling.
export function craterPrisms(target,tier,region){
 const runs=craterRuns(target,tier,region),out=[],active=new Map();let column=null;
 for(const r of runs){
  const key=`${r.z0},${r.z1},${r.bottom},${r.top}`,last=active.get(key);
  if(last&&last.x1===r.x-1&&last.volume+r.volume<=32768){last.x1=r.x;last.volume+=r.volume;}
  else{const v={...r,x1:r.x};out.push(v);active.set(key,v);}
 }
 return out.sort((a,b)=>Math.hypot((a.x+a.x1)/2-target.x,(a.z0+a.z1)/2-target.z)-Math.hypot((b.x+b.x1)/2-target.x,(b.z0+b.z1)/2-target.z));
}

// Raw Minecraft health points: 100 = 50 hearts at the Apex center.
export function impactDamage(distance,radius,peak){if(!Number.isFinite(distance)||radius<=0)return 0;return Math.max(0,peak*(1-Math.max(0,distance)/radius));}
