"""0.3 original presentation assets. Reference assets are never bundled."""
import json,math,random,shutil
from pathlib import Path
from PIL import Image,ImageDraw
from siege_build import dump,image,Structure,I
from catalog import GUNS
from siege_catalog import MISSILES

SILO={'controller':{'x':30,'y':3,'z':26},'entrance':{'x':8,'y':33,'z':0},'size':[47,48,47],'surfaceOffset':32}
def box(o,s,t=0,rotation=None):
 v={'origin':o,'size':s,'uv':{f:{'uv':[t*8,0],'uv_size':[8,8]} for f in ['north','south','east','west','up','down']}}
 if rotation:v.update(rotation=rotation,pivot=list(o))
 return v

def gun_rigs(bp,rp,root):
 # Preserve the official vanilla player behavior, adding only four visual properties.
 j=json.loads((root/'src/vendor/player_1.21.120.json').read_text());j['minecraft:entity']['description']['properties']={
 'foundry:armed':{'type':'bool','default':False,'client_sync':True},
 **{'foundry:'+k:{'type':'float','range':[0,1],'default':0,'client_sync':True} for k in ['kick','reload','aim']}}
 dump(bp/'entities/player.json',j);shutil.copy(root/'src/presentation.js',bp/'scripts/presentation.js')
 animations={}
 for g in GUNS:
  path=rp/'models/entity'/f'{g["id"]}.geo.json';j=json.loads(path.read_text());geo=j['minecraft:geometry'][0];old=geo['bones'][0]['cubes']
  body=[];mag=[];slide=[];pistol=g['category']=='Pistols';launcher=g['category']=='Launchers';bull=g['style']=='bullpup'
  for i,c in enumerate(old):
   c['origin'][1]-=24
   for face in c.get('uv',{}).values():
    if face['uv'][0]==24:face['uv'][0]=48
   if 'pivot' in c:c['pivot'][1]-=24
   o,sz=c['origin'],c['size']
   if pistol and i<2:slide.append(c)
   elif not pistol and not launcher and sz[1]>=4.8 and sz[2]==3 and o[2]==(4 if bull else -3):mag.append(c)
   else:body.append(c)
  if pistol:
   mag=[box([-.65,-5.1,.35],[1.3,4.6,1.7],1)]
   body.extend([box([-.3,2.7,-5.4],[.6,.6,.6],2),box([-.8,2.7,1],[1.6,.5,.7],0)])
  elif not launcher:
   body.extend([box([-1.5,1,-3],[.2,1.3,3],2),box([-1.75,1.5,-.6],[.4,.5,.8],2),box([-1.2,3.4,2],[2.4,1.2,.7],0)])
   for z in range(-12,-4,2):body.append(box([-1.45,.6,z],[.2,1.2,.6],2))
   if not slide:slide=[box([1.45,1.6,-2],[.5,.5,2.5],2)]
  if not pistol and not launcher:
   # Raised rail teeth, sight posts and broken-up receiver contour.
   for zz in range(-6,3):body.append(box([-.85,3.55,zz],[1.7,.35,.4],0))
   body.extend([box([-.3,3.4,-12],[.6,1.5,.5],0),box([-1.65,.4,-4],[.25,1.6,1.8],0),box([-1.5,2.6,-4],[3,.35,7],2)])
   if 'ak_' in g['id'] or g['style']=='wood':
    mag=[box([-1,-3,-3],[2,3,2.7],1),box([-1,-5.5,-2.7],[2,2.8,2.7],1,[-8,0,0]),box([-1,-7.4,-1.8],[2,2.3,2.7],1,[-16,0,0])]
  muzzle=min(c['origin'][2] for c in body+slide)-.2
  bones=[{'name':'mount','pivot':[0,0,0],'binding':"query.item_slot_to_bone_name(context.item_slot)"},
   {'name':'weapon','parent':'mount','pivot':[0,0,0],'cubes':body},
   {'name':'magazine','parent':'weapon','pivot':[0,-1,-2],'cubes':mag},
   {'name':'action','parent':'weapon','pivot':[0,0,0],'cubes':slide},
   {'name':'flash','parent':'weapon','pivot':[0,1,muzzle],'cubes':[box([-.2,-.7,muzzle-2],[.4,3.5,2],3),box([-1.8,.8,muzzle-2],[3.6,.4,2],3)]},
   {'name':'case','parent':'weapon','pivot':[1,2,-1],'cubes':[box([1,2,-1],[.4,.4,1.1],3)]},
   {'name':'fp_hands','parent':'weapon','pivot':[0,0,0],'cubes':[box([-1.65,-3.6,-.3],[3.3,3.1,3.6],4),box([-1.4,-4.2,2.7],[2.8,2.8,8.3],5)]},
   {'name':'support_hand','parent':'fp_hands','pivot':[0,-1,-10],'cubes':[box([-2,-1.8,-11 if not pistol else 0],[4,2.5,4],4),box([-2.3,-3,-9 if not pistol else 2],[3,2.8,8],5)]}]
  geo['bones']=bones;geo['description']['texture_width']=64;geo['description']['visible_bounds_width']=6;dump(path,j)
  # Six swatches: gun finish, furniture, edge highlights, warm muzzle, glove, sleeve.
  oldtex=Image.open(rp/'textures/models'/f'{g["id"]}.png');tex=Image.new('RGB',(64,8));tex.paste(oldtex,(0,0));dr=ImageDraw.Draw(tex)
  for i,col in [(3,'#f4c566'),(4,'#3d443f'),(5,'#677063'),(6,'#4298ad')]:dr.rectangle((i*8,0,i*8+7,7),fill=col);dr.line((i*8,1,i*8+7,1),fill='#889080' if i>3 else '#fff0ac')
  image(rp/'textures/models'/f'{g["id"]}.png',tex)
  desc=json.loads((rp/'attachables'/f'{g["id"]}.json').read_text())['minecraft:attachable']['description']
  desc['animations']={'first':'animation.foundry.view_'+('pistol' if pistol else 'launcher' if launcher else 'rifle'),'third':'animation.foundry.third_v3','mechanism':'animation.foundry.mechanism'}
  desc['scripts']={'pre_animation':["v.k = query.has_property('foundry:kick') ? query.property('foundry:kick') : 0;","v.r = query.has_property('foundry:reload') ? query.property('foundry:reload') : 0;","v.a = query.has_property('foundry:aim') ? query.property('foundry:aim') : 0;","v.reload_curve = math.sin(v.r * 180);"], 'animate':[{'first':'context.is_first_person'},{'third':'!context.is_first_person'},'mechanism']}
  dump(rp/'attachables'/f'{g["id"]}.json',{'format_version':'1.20.30','minecraft:attachable':{'description':desc}})
  # Suppress the unrelated vanilla bow-use pose; input remains a sustained-use item.
  ip=bp/'items'/f'{g["id"]}.json';item=json.loads(ip.read_text());item['minecraft:item']['components']['minecraft:use_animation']='none';dump(ip,item)
 for cls,scale,z in [('pistol',.9,-8),('rifle',.75,-8),('launcher',.7,-5)]:
  animations['animation.foundry.view_'+cls]={'loop':True,'bones':{'mount':{'position':['-2.5 - v.a * 3','3.0 + v.a * 1.5',-4],'rotation':[90,0,0],'scale':scale},'weapon':{'position':[0,'-v.reload_curve * 1.4','v.k * 1.15'],'rotation':['-v.k * 5 + v.reload_curve * 18',0,'v.reload_curve * -22']},'fp_hands':{'scale':1}}}
 animations['animation.foundry.third_v3']={'loop':True,'bones':{'mount':{'position':[0,-.5,0],'rotation':[90,0,0],'scale':.65},'fp_hands':{'scale':0},'weapon':{'rotation':['-v.k * 4 + v.reload_curve * 15',0,'-v.reload_curve * 12']}}}
 animations['animation.foundry.mechanism']={'loop':True,'bones':{'action':{'position':[0,0,'v.k * 1.1 + (v.r > 0.8 ? math.sin((v.r-0.8)*900)*0.8 : 0)']},'magazine':{'position':['v.reload_curve * -2','-math.sin(math.clamp((v.r-0.12)/0.65,0,1)*180) * 7',0],'rotation':[0,0,'v.reload_curve * -15']},'support_hand':{'position':['v.reload_curve * 2','-v.reload_curve * 3','v.reload_curve * 6']},'flash':{'scale':'v.k > 0.7 ? 1 + v.k : 0'},'case':{'position':['(1-v.k)*9','math.sin(v.k*180)*3',0],'rotation':[0,0,'(1-v.k)*360'],'scale':'v.k > 0.05 ? 1 : 0'}}}
 animations['animation.foundry.operator_hold']={'loop':True,'override_previous_animation':True,'bones':{'rightarm':{'rotation':["-90 + query.target_x_rotation - query.property('foundry:kick')*4",-5,0]},'leftarm':{'rotation':["-88 + query.target_x_rotation + query.property('foundry:reload')*22",30,0]}}}
 dump(rp/'animations/guns.animation.json',{'format_version':'1.8.0','animations':animations})

# Buildings are original voxel architecture with multiple rooms and shaped shells.
def architecture(bp):
 from architecture_build import decorate_bunker,decorate_silo
 WALL='minecraft:polished_andesite';DARK='minecraft:polished_blackstone_bricks';TRIM='minecraft:stone';AIR='minecraft:air'
 for variant in range(3):
  s=Structure((33,18,29));s.indices=[-1]*len(s.indices)
  # Octagonal main hall and stepped protective roof.
  for y in range(1,11):
   inset=max(0,y-7)
   for x in range(3+inset,25-inset):
    for z in range(5+inset,25-inset):
     cut=max(0,6+inset-x)+max(0,x-(21-inset))+max(0,8+inset-z)+max(0,z-(21-inset))
     if cut>4:continue
     edge=x in [3+inset,24-inset] or z in [5+inset,24-inset] or cut>=3
     s.set(x,y,z,DARK if y in [1,7,10] else WALL if edge or y>=8 else AIR)
  # Projecting armory wing and connection, different silhouette from the main hall.
  s.box(22,1,10,30,6,20,WALL);s.box(23,2,11,29,5,19,AIR);s.box(21,2,13,24,4,16,AIR)
  s.box(22,7,10,30,7,20,DARK);s.box(23,8,11,29,8,19,TRIM)
  # Recessed entrance, canopy supports, broad stair approach.
  s.box(11,2,3,16,5,8,AIR);s.box(9,6,1,18,6,8,DARK)
  for x in [9,18]:s.box(x,2,2,x,5,2,WALL)
  for z in range(5):s.box(11,max(0,4-z),z,16,max(0,4-z),z,TRIM);s.box(11,max(0,4-z)+1,z,16,5,z,AIR)
  # Windows are slits, not large glazed boxes.
  for x in [7,19]:s.box(x,4,5,x+2,4,5,'minecraft:glass')
  s.box(3,4,11,3,4,16,'minecraft:iron_bars')
  # Reinforcing ribs, vents, asymmetrical observation tower.
  for z in [9,15,21]:s.box(2,1,z,2,6,z,TRIM)
  s.box(5,10,16,10,14,22,DARK);s.box(6,11,17,9,13,21,AIR)
  s.box(6,12,16,9,12,16,'minecraft:glass');s.box(5,12,18,5,12,20,'minecraft:glass');s.box(4,15,15,11,15,23,TRIM)
  s.box(7,2,22,7,13,22,TRIM)
  for y in range(2,14):s.set(7,y,21,'minecraft:ladder',{'facing_direction':I(2)})
  # Rear/side ribs and embrasures break up the long walls from every approach.
  for x in [7,13,19]:
   s.box(x,1,24,x,6,25,TRIM)
   if x!=13:s.box(x+1,4,24,x+2,4,24,'minecraft:iron_bars')
  for z in [12,17]:s.box(30,2,z,31,5,z,DARK);s.set(30,4,z+1,'minecraft:glass')
  s.box(6,12,22,9,12,22,'minecraft:glass');s.box(10,12,18,10,12,20,'minecraft:glass')
  s.box(17,11,14,20,11,17,DARK);s.box(18,12,15,19,13,16,TRIM)
  for y in range(16,18):s.set(7,y,19,'minecraft:iron_bars')
  # Service partitions, work surfaces, shelves and benches.
  s.box(13,2,17,13,5,23,WALL);s.box(13,2,18,13,3,19,AIR)
  for x in [6,8,18,20]:s.box(x,2,19,x,2,22,'minecraft:spruce_planks')
  s.box(7,2,10,10,2,10,DARK);s.set(8,3,10,'foundry:field_console');s.set(9,3,10,'foundry:field_console')
  s.set(17,2,10,['foundry:ammo_press','foundry:attachment_bench','foundry:gunsmith_bench'][variant])
  for z in [12,16,18]:s.box(28,2,z,28,3,z,'minecraft:spruce_planks')
  for x,z in [(8,13),(18,13),(26,15)]:s.set(x,6 if x<22 else 5,z,'minecraft:sea_lantern')
  s.chest(25,2,12,'bunker_'+str(variant));s.chest(17,2,21,'bunker_'+str(variant))
  s.box(11,2,6,16,5,6,'foundry:blast_panel');s.set(10,3,5,'foundry:bunker_switch')
  for x in [10,17]:s.box(x,2,6,x,5,6,DARK);s.set(x,5,5,'minecraft:sea_lantern')
  decorate_bunker(s,variant)
  s.save(bp/'structures/foundry'/f'bunker_{variant}.mcstructure')
  rule=bp/'feature_rules'/f'bunker_{variant}_rule.json';j=json.loads(rule.read_text());j['minecraft:feature_rules']['distribution']['y']='query.heightmap(variable.worldx, variable.worldz) - 4';dump(rule,j)
 # Circular buried shaft, annular service decks, reinforced ribs and separate annex.
 s=Structure(tuple(SILO['size']));s.indices=[-1]*len(s.indices)
 for x in range(18,43):
  for z in range(14,39):
   r=math.hypot(x-30,z-26)
   if r>11.5:continue
   for y in range(1,37):
    shell=r>10;deck=y in [2,11,22,32] and r>5
    s.set(x,y,z,DARK if shell and y%5==0 else WALL if shell or deck or y==1 else AIR)
    if r>8.8 and r<9.9 and y in [12,23,33]:s.set(x,y,z,'minecraft:iron_bars')
 # Tall open shaft, half-open hatch leaves flanking launch aperture.
 for x in range(20,41):
  for z in range(16,37):
   if math.hypot(x-30,z-26)<9:
    s.box(x,33,z,x,43,z,AIR)
    if abs(x-30)>5:s.set(x,36,z,TRIM)
 for x in [20,40]:
  for z in [22,30]:s.box(x,3,z,x,34,z,DARK)
 for y in [7,18,29]:
  for x,z in [(21,26),(39,26),(30,17),(30,35)]:s.set(x,y,z,'minecraft:sea_lantern')
 # Operations annex (two floors) and angled-looking stepped roof / entrance porch.
 s.box(3,23,7,17,35,34,WALL);s.box(4,24,8,16,28,33,AIR);s.box(4,30,8,16,34,33,AIR)
 s.box(2,36,6,18,36,35,DARK);s.box(4,37,8,16,37,33,TRIM);s.box(6,38,10,14,38,31,DARK)
 s.box(6,30,6,10,33,9,AIR);s.box(5,34,3,11,34,7,DARK)
 for z in range(3,8):s.box(6,29,z,10,29,z,TRIM);s.box(6,30,z,10,33,z,AIR)
 for z in range(3):s.box(6,32-z,z,10,32-z,z,TRIM);s.box(6,33-z,z,10,36,z,AIR)
 for z in [12,19,28]:s.box(3,31,z,3,32,z+2,'minecraft:glass')
 s.box(15,24,24,23,28,28,WALL);s.box(15,25,25,23,27,27,AIR);s.box(23,25,24,23,28,24,'minecraft:glass')
 # Long observation glazing toward the shaft with desk consoles on the upper floor.
 s.box(17,31,20,17,33,30,'minecraft:glass');s.box(15,30,20,15,30,30,DARK)
 for z in [21,24,27,29]:s.set(15,31,z,'foundry:field_console')
 s.box(5,30,18,10,30,18,'minecraft:spruce_planks');s.box(5,31,19,10,31,19,'minecraft:spruce_planks')
 # Access ladder from control room down to service deck and foundation.
 s.box(20,2,26,20,33,26,TRIM)
 for y in range(2,34):s.set(21,y,26,'minecraft:ladder',{'facing_direction':I(5)})
 s.box(17,30,24,20,32,27,AIR)
 for y in range(24,35):s.set(5,y,33,'minecraft:ladder',{'facing_direction':I(2)})
 s.box(28,2,24,32,2,28,'foundry:silo_casing')
 for x in [28,32]:
  for z in [24,28]:s.set(x,3,z,'foundry:silo_stabilizer')
 s.set(30,3,26,'foundry:relic_controller')
 s.set(7,24,13,'foundry:missile_fabricator');s.set(8,24,13,'foundry:ammo_press')
 s.chest(7,24,29,'relic_silo');s.chest(12,30,12,'relic_silo')
 for x,y,z in [(7,34,12),(7,34,24),(7,28,12),(7,28,24)]:s.set(x,y,z,'minecraft:sea_lantern')
 # Small vent block, mast, exterior retaining wall; no valuable metal-block facade.
 s.box(11,39,15,12,41,16,DARK);s.box(12,42,16,12,46,16,'minecraft:iron_bars');s.set(12,46,16,'minecraft:redstone_torch')
 # Eight ring decks and under-annex rooms; retain the established climb route.
 for y in [6,15,19,26]:
  for x in range(20,41):
   for z in range(16,37):
    radius=math.hypot(x-30,z-26)
    if 6.4<radius<9.9:
     s.set(x,y,z,DARK if (x+z)%3==0 else TRIM)
     if 6.4<radius<7.1:s.set(x,y+1,z,'minecraft:iron_bars')
 # Service annex below the existing surface control room, three occupied floors.
 s.box(3,1,7,17,22,34,WALL)
 for y in [3,10,17]:
  s.box(4,y,8,16,y+4,33,AIR)
  s.box(4,y-1,8,16,y-1,33,DARK)
  s.box(11,y,8,11,y+4,23,WALL);s.box(11,y,14,11,y+2,16,AIR)
  # Copper-colored cable tray, lights, instrument racks and work areas.
  s.box(5,y+3,9,5,y+3,31,'minecraft:dark_oak_planks')
  for z in [11,20,29]:s.set(8,y+4,z,'minecraft:sea_lantern')
  for z in [10,13,18,21]:s.box(15,y,z,15,y+2,z,DARK);s.set(14,y+1,z,'foundry:field_console')
  s.box(5,y,25,9,y,25,'minecraft:spruce_planks')
  s.set(7,y+1,25,'foundry:field_console')
  s.set(6,y,28,'foundry:gunsmith_bench' if y==3 else 'foundry:attachment_bench')
  # Cableway connects each level to the ladder gallery.
  s.box(16,y-1,24,23,y+3,28,WALL);s.box(16,y,25,23,y+2,27,AIR)
 # Vertical climb and two-block headroom through all gallery intersections.
 s.box(20,2,26,20,33,26,TRIM);s.box(21,2,26,21,34,26,AIR)
 for y in range(2,34):s.set(21,y,26,'minecraft:ladder',{'facing_direction':I(5)})
 # Maintain original crossing at observation level and ground-level access to controller.
 s.box(17,30,24,20,32,27,AIR);s.box(21,3,25,27,5,27,AIR)
 for y in [8,14,20,26,32]:
  s.box(37,y,20,38,y,21,'minecraft:dark_oak_planks');s.set(38,y+1,21,'minecraft:sea_lantern')
 # Recessed intake housings and paired hatch rails read clearly from the surface.
 for z in [17,35]:
  s.box(20,36,z,40,36,z,DARK)
  for x in range(21,40,3):s.set(x,37,z,'minecraft:iron_bars')
 s.box(6,30,6,11,33,6,'foundry:blast_panel');s.set(5,31,5,'foundry:bunker_switch')
 s.set(5,33,5,'minecraft:sea_lantern');s.set(12,33,5,'minecraft:sea_lantern')
 s.box(29,4,25,31,47,27,AIR)
 s.box(22,36,18,38,36,34,'foundry:blast_panel')
 s.box(19,36,24,21,36,28,DARK);s.set(20,37,26,'foundry:hatch_switch')
 for x in [21,39]:
  for z in [18,22,26,30,34]:s.set(x,36,z,'minecraft:sea_lantern')
 for y in [5,12,19,26,33]:
  for x,z in [(22,22),(22,30),(38,22),(38,30)]:s.set(x,y,z,'minecraft:sea_lantern')
 decorate_silo(s)
 s.save(bp/'structures/foundry/relic_silo.mcstructure')

def sparse_loot(bp):
 from catalog import AMMO,ATTACHMENTS
 def e(id,w=1,count=None):
  a={'type':'item','name':id,'weight':w}
  if count:a['functions']=[{'function':'set_count','count':{'min':count[0],'max':count[1]}}]
  return a
 for i in range(4):
  pools=[{'rolls':{'min':1,'max':2},'entries':[e('minecraft:bread',4,(1,3)),e('minecraft:rotten_flesh',3,(1,2)),e('minecraft:string',3,(1,3)),e('minecraft:paper',4,(1,4)),e('minecraft:iron_nugget',4,(2,6))]},
   {'rolls':1,'entries':[{'type':'empty','weight':35}]+[e('foundry:'+id,8,(4,12)) for id in AMMO if id not in ['rocket','grenade_round']]},
   {'rolls':1,'entries':[{'type':'empty','weight':90},e('foundry:circuit',3),e('foundry:polymer',4),e('foundry:reinforced_alloy',3)]},
   {'rolls':1,'entries':[{'type':'empty','weight':96},e('foundry:'+GUNS[(i*17)%len(GUNS)]['id'],1),e('foundry:'+list(ATTACHMENTS)[i],3)]}]
  dump(bp/'loot_tables/chests'/('relic_silo.json' if i==3 else f'bunker_{i}.json'),{'pools':pools})

def computer(bp,rp):
 # Existing item ID retained so saved inventories upgrade to the combined computer.
 p=bp/'items/targeting_pad.json';j=json.loads(p.read_text());j['minecraft:item']['components'].update({'minecraft:display_name':{'value':'Field Targeting Computer'},'minecraft:max_stack_size':1});dump(p,j)
 cubes=[box([-5,0,-4],[10,1,7],0),box([-5,1,-4],[10,6,.65],0),box([-4.3,1.7,-3.3],[8.6,4.6,.12],1)]
 for x in range(-4,5,2):
  for z in range(-2,2):cubes.append(box([x,1,z],[1.3,.12,.6],2))
 cubes.extend([box([3,1,1],[1,1,1],3),box([-1,2,-3.15],[2,3,.05],3)])
 dump(rp/'models/entity/targeting_pad.geo.json',{'format_version':'1.16.0','minecraft:geometry':[{'description':{'identifier':'geometry.foundry.computer','texture_width':32,'texture_height':8,'visible_bounds_width':3,'visible_bounds_height':3,'visible_bounds_offset':[0,0,0]},'bones':[{'name':'computer','pivot':[0,0,0],'binding':"query.item_slot_to_bone_name(context.item_slot)",'cubes':cubes}]}]})
 im=Image.new('RGB',(32,8));dr=ImageDraw.Draw(im)
 for n,c in enumerate(['#354447','#133c2f','#7e8982','#90d697']):dr.rectangle((n*8,0,n*8+7,7),fill=c)
 image(rp/'textures/models/computer.png',im)
 dump(rp/'attachables/targeting_pad.json',{'format_version':'1.20.30','minecraft:attachable':{'description':{'identifier':'foundry:targeting_pad','materials':{'default':'entity_alphatest'},'textures':{'default':'textures/models/computer'},'geometry':{'default':'geometry.foundry.computer'},'animations':{'first':'animation.foundry.computer_first','third':'animation.foundry.computer_third'},'scripts':{'animate':[{'first':'context.is_first_person'},{'third':'!context.is_first_person'}]},'render_controllers':['controller.render.foundry.gun']}}})
 dump(rp/'animations/computer.json',{'format_version':'1.8.0','animations':{'animation.foundry.computer_first':{'loop':True,'bones':{'computer':{'position':[-3,2,-4],'rotation':[75,0,0],'scale':.85}}},'animation.foundry.computer_third':{'loop':True,'bones':{'computer':{'position':[0,0,0],'rotation':[70,0,0],'scale':.7}}}}})
 # Original pixel inventory laptop icon.
 im=Image.new('RGBA',(32,32));dr=ImageDraw.Draw(im);dr.polygon([(3,19),(25,19),(30,28),(2,28)],fill='#536266',outline='#182a32');dr.rectangle((5,3,25,20),fill='#3d4a52',outline='#19252c');dr.rectangle((7,5,23,17),fill='#173e32')
 for n in [10,15,20]:dr.line((n,5,n,17),fill='#396b50')
 dr.ellipse((12,8,19,15),outline='#b5e69d');dr.line((15,6,15,17),fill='#b5e69d');image(rp/'textures/items/targeting_pad.png',im)
 # Decorative control-console blocks use stone-cost salvage, not valuable ores.
 id='field_console';dump(bp/'blocks'/f'{id}.json',{'format_version':'1.21.120','minecraft:block':{'description':{'identifier':'foundry:'+id,'menu_category':{'category':'construction'}},'components':{'minecraft:geometry':'minecraft:geometry.full_block','minecraft:material_instances':{'*':{'texture':id,'render_method':'opaque'}},'minecraft:destructible_by_mining':{'seconds_to_destroy':2},'minecraft:light_emission':2,'minecraft:loot':'loot_tables/blocks/'+id+'.json'}}})
 dump(bp/'loot_tables/blocks'/f'{id}.json',{'pools':[{'rolls':1,'entries':[{'type':'item','name':'minecraft:cobblestone'}]}]})
 im=Image.new('RGB',(16,16),'#35434a');dr=ImageDraw.Draw(im);dr.rectangle((2,2,13,10),fill='#172f27');dr.line((3,6,6,6,7,4,9,8,11,5,12,5),fill='#92c976');dr.rectangle((2,12,10,13),fill='#83847b');dr.point((13,12),fill='#d17a42');image(rp/'textures/blocks/field_console.png',im)
 p=rp/'textures/terrain_texture.json';j=json.loads(p.read_text());j['texture_data'][id]={'textures':'textures/blocks/'+id};dump(p,j)
 for lang in ['en_US','en_GB']:
  with (rp/'texts'/f'{lang}.lang').open('a') as f:f.write('tile.foundry:field_console.name=Operations Console\n')

def icbm(bp,rp):
 # Long stepped cylindrical silhouette with staged bands and tapered nose; cosmetic only.
 cubes=[]
 def ring(y,height,radius,swatch):
  # Overlapping rotated narrow boxes approximate a 16-sided cylinder.
  for n in range(8):
   angle=n*22.5;c=box([-radius,y,-radius*.198],[radius*2,height,radius*.396],swatch);c.update(pivot=[0,y,0],rotation=[0,angle,0]);cubes.append(c)
 ring(10,223,11,0)
 for y in [12,75,145,220]:ring(y,4,11.5,2)
 for y,r in [(233,10.5),(242,9.5),(251,8.5),(260,7.2),(269,6),(278,4.8),(287,3.5),(296,2.2),(305,1)]:ring(y,9,r,1)
 ring(0,10,7,2)
 # Service stripe, access covers and minimal base stabilizers.
 cubes.extend([box([-2,25,-11.1],[4,188,.25],3),box([-4,105,-11.4],[8,12,.5],2),box([-2,175,-11.4],[4,18,.5],2)])
 for n in range(4):
  c=box([9,8,-1],[7,16,2],2);c.update(pivot=[0,0,0],rotation=[0,n*90,0]);cubes.append(c)
 dump(rp/'models/entity/silo_missile.geo.json',{'format_version':'1.12.0','minecraft:geometry':[{'description':{'identifier':'geometry.foundry.silo_missile','texture_width':32,'texture_height':8,'visible_bounds_width':6,'visible_bounds_height':44,'visible_bounds_offset':[0,10,0]},'bones':[{'name':'root','pivot':[0,0,0],'cubes':cubes}]}]})
 im=Image.new('RGB',(32,8));dr=ImageDraw.Draw(im)
 for n,c in enumerate(['#c2c7bd','#383f44','#626c68','#9b4535']):dr.rectangle((n*8,0,n*8+7,7),fill=c);dr.line((n*8,0,n*8+7,0),fill='#a7b0a8')
 image(rp/'textures/entity/silo_missile.png',im)
 p=bp/'entities/silo_missile.json';j=json.loads(p.read_text());j['minecraft:entity']['description']['properties']={'foundry:scale':{'type':'float','range':[.2,1],'default':1,'client_sync':True}};dump(p,j)
 p=rp/'animations/missile.animation.json';j=json.loads(p.read_text());bone=j['animations']['animation.foundry.missile_orientation']['bones']['root'];bone['scale']=1;dump(p,j)
 # World-anchored expanding mushroom geometry, in addition to near-view particles.
 parts=[]
 def cloud(o,size):parts.append(box(o,size,0))
 for y in range(0,192,16):
  r=10+y*.07;cloud([-r,y,-r],[r*2,21,r*2])
 for layer,radius,height in [(168,78,24),(188,108,30),(212,94,24),(233,64,18)]:
  for n in range(20):
   a=n*math.pi/10;rr=radius*(.45 if n%3==0 else .8);size=radius*.6
   cloud([math.cos(a)*rr-size/2,layer,math.sin(a)*rr-size/2],[size,height,size])
 dump(rp/'models/entity/blast_cloud.geo.json',{'format_version':'1.12.0','minecraft:geometry':[{'description':{'identifier':'geometry.foundry.blast_cloud','texture_width':8,'texture_height':8,'visible_bounds_width':700,'visible_bounds_height':700,'visible_bounds_offset':[0,130,0]},'bones':[{'name':'cloud','pivot':[0,0,0],'cubes':parts}]}]})
 image(rp/'textures/entity/blast_cloud.png',Image.new('RGBA',(8,8),(106,96,80,220)))
 dump(bp/'entities/blast_cloud.json',{'format_version':'1.21.0','minecraft:entity':{'description':{'identifier':'foundry:blast_cloud','is_spawnable':False,'is_summonable':True,'properties':{'foundry:growth':{'type':'float','range':[.01,18],'default':.01,'client_sync':True}}},'components':{'minecraft:collision_box':{'width':0,'height':0},'minecraft:physics':{'has_gravity':False,'has_collision':False},'minecraft:timer':{'time':50,'looping':False,'time_down_event':{'event':'foundry:expire','target':'self'}}},'component_groups':{'foundry:remove':{'minecraft:instant_despawn':{}}},'events':{'foundry:expire':{'add':{'component_groups':['foundry:remove']}}}}})
 dump(rp/'entity/blast_cloud.entity.json',{'format_version':'1.10.0','minecraft:client_entity':{'description':{'identifier':'foundry:blast_cloud','materials':{'default':'entity_alphablend'},'textures':{'default':'textures/entity/blast_cloud'},'geometry':{'default':'geometry.foundry.blast_cloud'},'animations':{'growth':'animation.foundry.cloud_growth'},'scripts':{'animate':['growth']},'render_controllers':['controller.render.foundry.gun']}}})
 dump(rp/'animations/cloud.json',{'format_version':'1.8.0','animations':{'animation.foundry.cloud_growth':{'loop':True,'bones':{'cloud':{'scale':"query.has_property('foundry:growth') ? math.max(0.01, query.property('foundry:growth')) : 1"}}}}})
 # Stronger, rounder cloud sprites; transparent edge but opaque inner billows.
 im=Image.new('RGBA',(64,64));dr=ImageDraw.Draw(im)
 for r,a in [(31,0),(30,35),(28,90),(25,160),(21,220),(16,245)]:dr.ellipse((32-r,32-r,32+r,32+r),fill=(255,255,255,a))
 image(rp/'textures/particle/cloud.png',im)
 for id in ['nuclear_fire','nuclear_cloud','shockwave_dust','launch_exhaust','missile_smoke']:
  p=rp/'particles'/f'{id}.json';j=json.loads(p.read_text());c=j['particle_effect']['components'];c['minecraft:particle_appearance_billboard']['uv'].update(texture_width=64,texture_height=64,uv_size=[64,64]);dump(p,j)

def polish(bp,rp,out,root):
 gun_rigs(bp,rp,root);computer(bp,rp);architecture(bp);sparse_loot(bp);icbm(bp,rp)
 with (bp/'scripts/siege_data.js').open('a') as f:f.write('export const SILO = '+json.dumps(SILO)+';\n')
 for p in [bp/'manifest.json',rp/'manifest.json']:
  j=json.loads(p.read_text());j['header']['version']=[0,3,0];j['header']['description']='Foundry Arsenal 0.3: animated weapon rigs, field computer, redesigned bunkers and large ICBM visuals. Development build.'
  for m in j['modules']:m['version']=[0,3,0]
  for d in j.get('dependencies',[]):
   if 'uuid' in d:d['version']=[0,3,0]
  dump(p,j)
 if (root/'src/vendor/Mojang-LICENSE.txt').exists():shutil.copy(root/'src/vendor/Mojang-LICENSE.txt',bp/'Mojang-LICENSE.txt')

def polish_guide(out):
 p=out/'Foundry_Arsenal_Field_Guide.html';s=p.read_text().replace('BUILD 0.2.0','BUILD 0.3.0').replace('new in 0.2','updated in 0.3')
 s=s.replace('No custom per-weapon reload animation.','Shared rig families now animate recoil, the action/slide, magazine reload and support-hand motion; these are not 120 individually hand-authored animations.')
 s=s.replace('Shared class animations','Animated weapon rigs').replace('11 blocks high','23 blocks high')
 s=s.replace('randomized weapon, ammunition, attachment and component chests','sparse supplies and small ammunition finds; weapons and upgrades are rare')
 s=s.replace('receive its targeting pad','receive its Field Targeting Computer')
 start=s.index('<p><b>Laser Designator:</b>');end=s.index('</p>',start)+4
 s=s[:start]+'''<p><b>Field Targeting Computer:</b> equip it from your inventory and Use/right-click to open its interface. Enter XYZ directly or select <b>Activate computer laser</b>. Aim at a surface and Use again to lock it; the computer then shows impact coordinates, chunk grid and your horizontal distance. <b>Sneak + Use</b> exits laser mode and returns to the computer. Laser range is 240 blocks; coordinate entry supports distant targets. The old Laser Designator still works for saved inventories. Y is the impact surface and controls crater depth.</p>'''+s[end:]
 s=s.replace('The four missile tiers share a missile model and use scaled effects.','Apex now has an approximately 20-block-tall staged cylindrical silhouette, tapered nose and minimal base fins. The other three tiers scale down to approximately 5, 8 and 13 blocks. The cloud combines a growing world-space mesh with denser distant-view particles.')
 s=s.replace('It may take minutes and can cause lag on slower worlds.','Version 0.3 merges compatible cuts into rectangular fills, preloads the next region when an extra ticking-area slot is available, and raises the maximum work budget to 524,288 blocks / 512 fills per tick with a 10 ms work timer. This is a budget increase, not a measured 32× speedup. Actual completion depends on chunk generation and hardware; large strikes can still cause lag.')
 new='''<h2>Version 0.3 — presentation and performance revision</h2><p>Gun rigs now separate first- and third-person holding poses, include visible first-person gloves, and animate recoil, muzzle flash, ejected cases, magazine movement and the weapon action. Aim transitions blend toward the center. Detailed rig timing and alignment still require Minecraft testing.</p><p>Bunkers now have clipped corners, stepped roofs, recessed entrances, work rooms, an armory wing, narrow windows and an observation tower. The relic silo has a circular shaft, service decks, lighting, a separate control-room annex and a nearly 20-block-tall Apex model. The download's generated asset preview is an offline render, not a game screenshot.</p><p><b>Reduced loot:</b> each chest has 1–2 small common supply rolls, an optional small ammunition roll, a 10% component roll and a 4% rare gun/upgrade roll (1% gun, 3% upgrade). No diamonds, Netherite, power cells or missile cores appear in these chest tables. The guaranteed relic ICBM is retained. Building facades no longer consist of iron blocks.</p><p><b>Updating:</b> import 0.3 and enable its behavior and resource packs. Use a fresh test world to see the new guaranteed silo. Existing structures are not replaced, and an already-taken relic missile is not replenished. Existing targeting-pad items become Field Targeting Computers. Silos validate a 3×3 route up to 80 blocks above the controller. Repair older relics at their controller, then open the surface cover before launching. A saved 0.2 excavation resumes from the start of its current region to convert the work cursor safely.</p><p><b>Pack compatibility:</b> the visual properties extend the vanilla player behavior definition. Other add-ons replacing <code>minecraft:player</code> can conflict; first test this pack by itself. Player skins are retained; the first-person gloves/sleeves are a fixed tactical style.</p><p><b>Reference limitation:</b> the supplied gun-world export contained only level data and a terrain database, with no bundled behavior/resource packs, weapon models or animation files. No assets from that world or other gun add-ons are included.</p>'''
 s=s.replace('<h2>Install & start</h2>',new+'<h2>Install & start</h2>')
 s=s.replace('<h2>Technical references</h2>', '<h2>Visual and technical references</h2><p><a href="https://www.curseforge.com/minecraft-bedrock/addons/actualguns-3d">ActualGuns 3D author gallery</a>; <a href="https://www.curseforge.com/minecraft-bedrock/addons/simple-guns">Simple Guns by Four</a>; <a href="https://www.minecraft-schematics.com/schematic/1283/">cmacey’s multi-room military base</a>. Used as references for presentation and architectural vocabulary, not copied assets. The player behavior base comes from <a href="https://github.com/Mojang/bedrock-samples/tree/v1.21.120.4">Mojang’s 1.21.120 samples</a>; its license notice is included.</p><h2>API references</h2>')
 p.write_text(s)
