"""Package editable sources, generated packs and the current validation report."""
from pathlib import Path
import zipfile
root=Path(__file__).resolve().parents[1]
paths=[]
for directory in ['src','tests','build/Foundry_Arsenal_BP','build/Foundry_Arsenal_RP']:
 paths.extend(p for p in (root/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
paths.extend(root/p for p in ['README.md','CHANGELOG.md','DESIGN_REFERENCES.md','.gitignore','requirements.txt','package.json','package-lock.json','tsconfig.json','output/validation.json','output/node-tests.tap'])
with zipfile.ZipFile(root/'output/Foundry_Arsenal_Source.zip','w',zipfile.ZIP_DEFLATED) as archive:
 for p in sorted(paths):archive.write(p,p.relative_to(root))
with zipfile.ZipFile(root/'output/Foundry_Arsenal_Source.zip') as archive:
 assert archive.testzip() is None
 assert 'src/siege.js' in archive.namelist() and 'tests/siege.test.js' in archive.namelist()
print('Source archive packaged:',len(paths),'files')
