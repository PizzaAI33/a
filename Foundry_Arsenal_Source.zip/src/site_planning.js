// Survey the complete surface footprint in bounded batches before placing a silo.
const fluids=new Set(['minecraft:water','minecraft:flowing_water','minecraft:lava','minecraft:flowing_lava','minecraft:bubble_column','minecraft:ice','minecraft:packed_ice','minecraft:blue_ice']);
const vegetation=id=>id.endsWith('_leaves')||id.endsWith('_log')||id.endsWith('_stem')||['minecraft:air','minecraft:leaves','minecraft:leaves2','minecraft:log','minecraft:log2','minecraft:snow_layer','minecraft:short_grass','minecraft:tall_grass','minecraft:vine'].includes(id);
export function surveyDrySite(d,site,size,previous=null,budget=128){
 const survey=previous||{cursor:0,min:320,max:-64};
 for(let n=0;n<budget&&survey.cursor<size[0]*size[2];n++){
  const x=site.x+Math.floor(survey.cursor/size[2]),z=site.z+survey.cursor%size[2];
  let block;try{block=d.getTopmostBlock({x,z});}catch{return {status:'waiting',survey};}
  if(!block)return {status:'waiting',survey};
  for(let down=0;vegetation(block.typeId)&&down<32;down++){
   try{block=d.getBlock({x,y:block.y-1,z});}catch{return {status:'waiting',survey};}
   if(!block)return {status:'waiting',survey};
  }
  if(block.isLiquid||fluids.has(block.typeId)||vegetation(block.typeId)||block.y<63||block.y>250)return {status:'rejected',survey};
  survey.min=Math.min(survey.min,block.y);survey.max=Math.max(survey.max,block.y);
  if(survey.max-survey.min>6)return {status:'rejected',survey};
  survey.cursor++;
 }
 return survey.cursor===size[0]*size[2]?{status:'ready',surface:survey.max,survey}:{status:'scanning',survey};
}
export function nextSiteCandidate(site){
 const anchorX=site.anchorX??site.x,anchorZ=site.anchorZ??site.z,search=(site.search||0)+1;
 const angle=search*2.399963229728653,radius=128*Math.sqrt(search);
 return {anchorX,anchorZ,search,x:Math.floor((anchorX+Math.cos(angle)*radius)/16)*16,z:Math.floor((anchorZ+Math.sin(angle)*radius)/16)*16};
}
