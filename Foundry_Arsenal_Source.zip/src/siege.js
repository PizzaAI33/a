import {world,system,BlockVolume,EntityDamageCause,MolangVariableMap} from '@minecraft/server';
import {ActionFormData,MessageFormData,ModalFormData} from '@minecraft/server-ui';
import {MISSILES,SILO} from './siege_data.js';
import {impactDamage,horizontalDistance,grid,validTarget,safety,craterRegions,craterRuns,craterPrisms,siloRequirements} from './siege_core.js';
import {openLaunchCover} from './doors.js';
import {surveyDrySite,nextSiteCandidate} from './site_planning.js';

// Minecraft-only fictional weapons. All targeting distances are game-block units.
const JOB='foundry:strike_v2',SITE='foundry:relic_site_v2',INDEX='foundry:silos_v2';
const AREA='foundry_strike_v2',SITEAREA='foundry_relic_v2',PREFETCH='foundry_prefetch_v3';
let H,job=null,site=null,loaded=false,frame=0,areaRegion='',siteArea=false,runCache=null,visual=null;
let blastEntity=null,prefetchTag='',siteSurvey=null;
const seenErrors=new Set();
const air=['minecraft:air','minecraft:cave_air','minecraft:void_air'];
function error(where,e){if(!seenErrors.has(where)){console.warn(`[Foundry Siege] ${where}: ${e}`);seenErrors.add(where);}}
function read(key,fallback=null){try{const raw=world.getDynamicProperty(key);return raw?JSON.parse(String(raw)):fallback;}catch{return fallback;}}
function write(key,value){world.setDynamicProperty(key,JSON.stringify(value));}
function sid(p){return `${Math.floor(p.x)}_${Math.floor(p.y)}_${Math.floor(p.z)}`;}
function entry(id){return read('foundry:silo_'+id);}
function store(s){write('foundry:silo_'+s.id,s);let ids=read(INDEX,[]);if(!ids.includes(s.id)){ids.push(s.id);write(INDEX,ids.slice(-256));}}
function tell(p,s){H.message(p,s);}
function d(){return world.getDimension('overworld');}
function coords(p){return `X ${Math.floor(p.x)} / Y ${Math.floor(p.y)} / Z ${Math.floor(p.z)}`;}
function initialize(){
 if(loaded)return;loaded=true;job=read(JOB);site=read(SITE);areaRegion='';runCache=null;
 // Area names belong only to this pack. Never remove anyone else's ticking areas.
 removeArea(AREA);removeArea(SITEAREA);removeArea(PREFETCH);
 if(!site){const spawn=world.getDefaultSpawnLocation(),sx=Math.random()<.5?-1:1,sz=Math.random()<.5?-1:1;
  site={layout:3,x:Math.floor((spawn.x+sx*(1400+Math.random()*700))/16)*16,z:Math.floor((spawn.z+sz*(1100+Math.random()*700))/16)*16,phase:'pending',attempts:0};write(SITE,site);
 }
 // A v0.2 crater cursor referred to one-column runs. Restarting its current region is idempotent.
 if(job?.phase==='crater'&&job.prismVersion!==3){job.run=0;job.prismVersion=3;saveJob();}
 if(job&&!job.strikeId){job.strikeId=Date.now().toString(36)+'-resume';saveJob();}
 if(site.phase!=='done'&&site.layout!==3){site.layout=3;site.phase='pending';write(SITE,site);}
}
function saveJob(){write(JOB,job);}
function removeArea(name){try{d().runCommand('tickingarea remove '+name);}catch{}}
function loadArea(name,x,z,width=128){
 removeArea(name);
 try{const r=d().runCommand(`tickingarea add ${x} -64 ${z} ${x+width-1} 319 ${z+width-1} ${name} true`);return r.successCount>0;}catch(e){error('chunk-loading',e);return false;}
}
function areaLoaded(x,z,width=128){return [ [x,z],[x+width-1,z],[x,z+width-1],[x+width-1,z+width-1] ].every(([x,z])=>d().isChunkLoaded({x,y:64,z}));}
function registerSilo(pos,relic=false){
 const id=sid(pos);let s=entry(id);
 if(!s){s={id,pos:{x:pos.x,y:pos.y,z:pos.z},loaded:relic?'apex_icbm':null,owner:null,ownerName:null,active:false,spent:false};store(s);}
 return s;
}
function siloCheck(s){
 if(s.pos.y< -62||s.pos.y>294)return 'Controller height must be between Y −62 and 294.';
 const moving=read('foundry:door_motions_v1',[]).some(g=>g.hatch&&g.dimension==='minecraft:overworld'&&Math.abs(g.origin.x+8-s.pos.x)<2&&Math.abs(g.origin.z+8-s.pos.z)<2);if(moving)return 'Hatch is moving. Wait until fully open.';
 const dim=d(),core=dim.getBlock(s.pos);
 if(!core||!['foundry:silo_controller','foundry:relic_controller'].includes(core.typeId))return 'Silo controller is missing or its chunk is unloaded.';
 const req=siloRequirements(s.pos,23);
 for(const p of req.base)if(dim.getBlock(p)?.typeId!=='foundry:silo_casing')return 'Foundation fault at '+coords(p)+': requires Silo Casing.';
 for(const p of req.stabilizers)if(dim.getBlock(p)?.typeId!=='foundry:silo_stabilizer')return 'Stabilizer missing at '+coords(p)+'.';
 for(const p of req.clearance){const b=dim.getBlock(p);if(b?.typeId==='foundry:blast_panel')return 'Silo cover CLOSED: open the cover before launch.';if(!air.includes(b?.typeId))return 'Launch shaft blocked at '+coords(p)+' by '+(b?.typeId||'an unloaded chunk')+'.';}
 for(let y=s.pos.y+24;y<Math.min(320,s.pos.y+80);y++)for(let x=-1;x<=1;x++)for(let z=-1;z<=1;z++){
  const q={x:s.pos.x+x,y,z:s.pos.z+z},b=dim.getBlock(q);
  if(!b)return 'Flight-path chunk is not loaded at '+coords(q)+'.';
  if(b.typeId==='foundry:blast_panel')return 'Silo cover CLOSED: use the surface hatch switch and wait until it opens.';
  if(!air.includes(b.typeId))return 'Overhead path blocked at '+coords(q)+' by '+b.typeId+'.';
 }
 return null;
}
function bound(p){const id=p.getDynamicProperty('foundry:bound_silo');return typeof id==='string'?entry(id):null;}
function target(p){try{const raw=p.getDynamicProperty('foundry:target');return raw?JSON.parse(String(raw)):null;}catch{return null;}}
function setTarget(p,t){p.setDynamicProperty('foundry:target',JSON.stringify(t));}
function near(p,s){return p.dimension.id==='minecraft:overworld'&&horizontalDistance(p.location,s.pos)<8&&Math.abs(p.location.y-s.pos.y)<8;}
function allowed(p,s){return !s.owner||s.owner===p.id;}
function announce(text){world.sendMessage('§6[Foundry Missile Network] §r'+text);}

export function installSiege(helpers){
 H=helpers;
 system.beforeEvents.startup.subscribe(e=>e.blockComponentRegistry.registerCustomComponent('foundry:siege_control',{
  onPlayerInteract:event=>{if(event.player)system.run(()=>openSilo(event.player,event.block));},
 }));
 world.afterEvents.worldLoad.subscribe(()=>initialize());
 world.afterEvents.playerSpawn.subscribe(()=>{if(!loaded)system.run(()=>initialize());});
 world.afterEvents.playerBreakBlock.subscribe(e=>{
  const type=e.brokenBlockPermutation.type.id;if(!['foundry:silo_controller','foundry:relic_controller'].includes(type))return;
  try{const s=registerSilo(e.block.location,type==='foundry:relic_controller');
   if(job?.silo===s.id&&['arming','countdown'].includes(job.phase)){abort('Controller broken; missile recovered.');s.loaded=entry(s.id)?.loaded;s.active=false;}
   if(s.loaded){H.give(e.player,'foundry:'+s.loaded);s.loaded=null;}s.spent=true;store(s);removeDisplay(s);
  }catch(err){error('silo-break',err);}
 });
 system.runInterval(tick,1);
 system.runInterval(()=>{if(!loaded)return;for(const id of read(INDEX,[])){const s=entry(id);if(s&&!s.active&&d().isChunkLoaded(s.pos))syncDisplay(s);}},100);
}
export function siegeUse(p,item){
 if(!['foundry:targeting_pad','foundry:laser_designator'].includes(item.typeId))return false;
 system.run(()=>{
  if(p.dimension.id!=='minecraft:overworld'){tell(p,'Missile targeting is available in the Overworld.');return;}
  if(p.isSneaking){p.setDynamicProperty('foundry:laser_mode',false);pad(p);return;}
  if(item.typeId==='foundry:laser_designator'||p.getDynamicProperty('foundry:laser_mode')){designate(p);return;}
  pad(p);
 });return true;
 return false;
}
function designate(p){
 const h=p.getBlockFromViewDirection({maxDistance:240,includeLiquidBlocks:true});
 if(!h){tell(p,'No surface within 240 blocks. Sneak + Use returns to the computer.');return;}
 const t={x:h.block.x,y:h.block.y+1,z:h.block.z};if(!validTarget(t))return;
 setTarget(p,{...t});p.setDynamicProperty('foundry:laser_mode',false);privateParticle(p,'target_marker',{x:t.x+.5,y:t.y+.2,z:t.z+.5},2);pad(p);
}
export async function siegeManual(p){
 initialize();
 const status=site?.phase==='done'?coords(sitePoint('entrance')):site?.error||'Preparing the guaranteed relic silo…';
 const text='BUNKERS: three architectural variants generate in new Overworld chunks. Most loot is sparse supplies or small ammunition finds; weapons and upgrades are rare.\n\nRELIC SILO: one site is reserved per world and starts with one Apex ICBM. Taking or firing it does not replenish it.\nSite entrance: '+status+'\n\nBUILD: 5×5 Silo Casing foundation; controller at its center, one block above; four stabilizers at the corners, level with the controller; a clear 3×3 launch route up to 80 blocks above. Open the cover with its surface switch and wait until it stops moving. Existing relics have a repair option at the controller.\n\nCraft missiles and targeting equipment at the Missile Fabricator. Bind the Field Targeting Computer at a controller and load a missile. Use the computer for XYZ entry or activate its laser; point and Use to lock a surface. Sneak + Use returns to the computer.\n\nMissiles permanently destroy terrain. Apex makes a 500-block-wide circular bowl, up to 100 blocks deep. Bedrock and world-height limits remain. Destruction runs in saved batches and may take minutes.\n\nChunk-loading must be available for remote strikes. If Minecraft rejects it, the status screen explains the error instead of silently skipping terrain.';
 await H.show(p,new ActionFormData().title('SILO OPERATIONS / 0.6').body(text).button('Open targeting computer').button('Close')).then(a=>{if(!a.canceled&&a.selection===0)return pad(p);});
}
async function openSilo(p,b){
 initialize();if(p.dimension.id!=='minecraft:overworld'){tell(p,'Build missile silos in the Overworld.');return;}
 const s=registerSilo(b.location,b.typeId==='foundry:relic_controller');syncDisplay(s);
 if(!allowed(p,s)){tell(p,'This silo belongs to '+s.ownerName+'.');return;}
 // Operating a controller claims and links it; no separate bind menu is needed.
 s.owner=p.id;s.ownerName=p.name;store(s);p.setDynamicProperty('foundry:bound_silo',s.id);
 if(!H.count(p,'foundry:targeting_pad'))H.give(p,'foundry:targeting_pad');
 const fault=siloCheck(s),name=s.loaded?MISSILES[s.loaded].name:'Empty';
 const form=new ActionFormData().title('SILO CONTROL').body(`${coords(s.pos)}\nOwner: ${s.ownerName||'Unclaimed'}\nPayload: ${name}\nStructure: ${fault||'READY'}\n${s.active?'Missile operation in progress.':''}`)
 .button('Target & launch').button(s.loaded?'Unload missile':'Load missile').button('Maintenance / help');
 const a=await H.show(p,form);if(a.canceled)return;
 const live=entry(s.id);if(!near(p,live)){tell(p,'Return to the silo controller.');return;}
 if(!allowed(p,live)){tell(p,'This silo is bound to '+live.ownerName+'.');return;}
 if(a.selection===0)return pad(p);
 if(a.selection===2){
  const f=new ActionFormData().title('SILO MAINTENANCE').body(fault||'Launch route ready.').button('Open cover').button('Repair relic shaft').button('Field guide');
  const answer=await H.show(p,f);if(answer.canceled||!near(p,live)||!allowed(p,entry(s.id)))return;
  if(answer.selection===0){openLaunchCover(p,s.pos);return;}
  if(answer.selection===2)return siegeManual(p);
  if(live.active){tell(p,'Wait for the active missile operation.');return;}return repairRelic(p,live);
 }
 if(live.active){tell(p,'This silo is busy.');return;}
 if(a.selection===1&&s.loaded){if(!live.loaded||live.loaded!==s.loaded){tell(p,'Payload changed. Reopen this controller.');return;}const payload=live.loaded;live.loaded=null;store(live);removeDisplay(live);H.give(p,'foundry:'+payload);tell(p,'Missile unloaded.');return;}
 if(a.selection===1){
  if(live.loaded){tell(p,'Unload the existing missile first.');return;}
  const ids=Object.keys(MISSILES).filter(id=>H.count(p,'foundry:'+id)>0);if(!ids.length){tell(p,'Craft a missile at the Missile Fabricator first.');return;}
  const f=new ActionFormData().title('LOAD SILO');ids.forEach(id=>f.button(MISSILES[id].name));const answer=await H.show(p,f);if(answer.canceled)return;
  const now=entry(s.id);if(!near(p,now)||now.active||now.loaded||!allowed(p,now))return;
  const id=ids[answer.selection];if(!H.consume(p,{['foundry:'+id]:1}))return;
  now.loaded=id;store(now);syncDisplay(now);tell(p,'Loaded '+MISSILES[id].name+'.');
 }
}
async function pad(p){
 initialize();if(p.dimension.id!=='minecraft:overworld'){tell(p,'Targeting works in the Overworld.');return;}
 const s=bound(p),t=target(p),tier=s?.loaded&&MISSILES[s.loaded],safe=t&&tier?safety(p.location,t,tier):null;
 let body=`Linked silo: ${s?coords(s.pos):'NONE — bind at a Silo Controller'}\nPayload: ${tier?.name||'No missile loaded'}\n\n`;
 if(t)body+=`Target: ${coords(t)}\nDistance: ${Math.floor(horizontalDistance(p.location,t))} blocks\n`;
 else body+='No target selected.\n';
 if(safe)body+=`${safe.status} · recommended distance ${tier.safe}+ blocks\n`;
 if(job)body+=`\nACTIVE: ${MISSILES[job.type].name} / ${job.terrainDone?'aftereffects — terrain finished':job.phase}\n${job.error||''}${job.phase==='crater'?`\nTerrain progress: ${progress()}%`:''}`;
 const form=new ActionFormData().title('TARGET & LAUNCH').body(body);
 if(job){
  const cancel=job.owner===p.id&&['arming','countdown'].includes(job.phase);form.button(cancel?'Cancel launch':'Refresh status').button('Close');
  const a=await H.show(p,form);if(!a.canceled&&a.selection===0){if(cancel&&job?.owner===p.id&&['arming','countdown'].includes(job.phase))abort('Launch canceled by operator.');else return pad(p);}return;
 }
 form.button('Aim & lock target').button('Enter XYZ').button('Launch missile');
 const a=await H.show(p,form);if(a.canceled)return;
 if(a.selection===0){p.setDynamicProperty('foundry:laser_mode',true);tell(p,'Aim at the impact surface. Use again to LOCK. Looking away after locking will not move the target.');return;}
 if(a.selection===1)return enterCoordinates(p);
 if(a.selection===2)return confirmLaunch(p);
}
async function enterCoordinates(p){
 const t=target(p)||{x:Math.floor(p.location.x),y:Math.floor(p.location.y),z:Math.floor(p.location.z)};
 const f=new ModalFormData().title('EXACT IMPACT COORDINATES').textField('X (−1,000,000 to +1,000,000)','X',{defaultValue:String(t.x)}).textField('Y / ground surface (−63 to 300)','Y',{defaultValue:String(t.y)}).textField('Z (−1,000,000 to +1,000,000)','Z',{defaultValue:String(t.z)});
 const a=await H.show(p,f);if(a.canceled)return;
 const values=a.formValues.map(v=>String(v).trim());const next={x:Number(values[0]),y:Number(values[1]),z:Number(values[2])};
 if(values.some(v=>!/^[-+]?\d+$/.test(v))||!validTarget(next)){tell(p,'Enter whole-number coordinates within the shown limits.');return;}
 setTarget(p,next);return pad(p);
}
async function confirmLaunch(p){
 if(job){tell(p,'Wait for the current missile and terrain operation to finish.');return;}
 const s=bound(p),t=target(p);if(!s?.loaded||!t||!validTarget(t)){tell(p,'Bind a loaded silo and select a valid target first.');return;}
 if(!allowed(p,s)){tell(p,'Only the bound operator can launch this silo.');return;}
 const tier=MISSILES[s.loaded],snapshot=JSON.stringify(t),payload=s.loaded,info=safety(p.location,t,tier),c=grid(t);
 const f=new MessageFormData().title('CONFIRM LIVE MISSILE LAUNCH').body(`${tier.name}\nImpact: ${coords(t)}\nChunk grid: ${c.x}, ${c.z}\nDistance now: ${info.distance} blocks\n${info.status}\nRecommended: ${tier.safe}+ blocks\n\nPERMANENT TERRAIN DAMAGE\nCircular crater: ${tier.radius*2} blocks across; up to ${tier.depth} deep.\n\n10-second countdown; flight approximately ${tier.flight/20} seconds. Confirm only after checking your target.`).button1('LAUNCH — verified target').button2('Cancel');
 const a=await H.show(p,f);if(a.canceled||a.selection!==0)return;
 const live=entry(s.id);if(job||!live||live.loaded!==payload||!allowed(p,live)||JSON.stringify(target(p))!==snapshot){tell(p,'Silo or target changed. Review again.');return;}
 // Remote controller chunks must be loaded for multiblock validation.
 if(!loadArea(AREA,Math.floor(s.pos.x/16)*16-16,Math.floor(s.pos.z/16)*16-16,48)){tell(p,'Minecraft could not reserve a chunk-loading area. Check command permission / available ticking-area slots. Missile was not consumed.');return;}
 job={strikeId:Date.now().toString(36)+'-'+system.currentTick,phase:'arming',silo:s.id,type:payload,target:{...t},start:{...s.pos},owner:p.id,ownerName:p.name,count:200,elapsed:0,region:0,run:0,visualAge:0,error:null,armingWait:0};saveJob();
 live.active=true;store(live);areaRegion='launch';
 tell(p,'Preparing launch: opening the cover and checking the silo. Countdown starts when the route is clear.');
}
function abort(reason){
 if(!job)return;const s=entry(job.silo);if(s){s.loaded=job.type;s.active=false;store(s);}
 announce(reason);job=null;saveJob();removeArea(AREA);removeArea(PREFETCH);prefetchTag='';areaRegion='';removeVisual();
}
function privateParticle(p,id,pos,size=1){
 try{const m=new MolangVariableMap();m.setFloat('variable.foundry_size',size);p.spawnParticle('foundry:'+id,pos,m);}catch(e){error('particle-'+id,e);}
}
function puff(id,pos,size=1){try{const m=new MolangVariableMap();m.setFloat('variable.foundry_size',size);d().spawnParticle('foundry:'+id,pos,m);}catch(e){error('world-particle-'+id,e);}}
function removeVisual(){try{visual?.remove();}catch{}visual=null;}
function removeDisplay(s){try{for(const e of d().getEntities({type:'foundry:silo_missile',location:s.pos,maxDistance:4}))if(e.getDynamicProperty('foundry:silo')===s.id)e.remove();}catch{}}
function syncDisplay(s){
 try{
  const block=d().getBlock(s.pos);if(!block||!['foundry:silo_controller','foundry:relic_controller'].includes(block.typeId)){removeDisplay(s);return;}
  const entities=d().getEntities({type:'foundry:silo_missile',location:s.pos,maxDistance:4}).filter(e=>e.getDynamicProperty('foundry:silo')===s.id);
  if(!s.loaded){entities.forEach(e=>e.remove());return;}
  entities.forEach(e=>e.triggerEvent('foundry:size_'+s.loaded));
  if(!entities.length){const e=d().spawnEntity('foundry:silo_missile',{x:s.pos.x+.5,y:s.pos.y+1,z:s.pos.z+.5});e.setDynamicProperty('foundry:silo',s.id);e.triggerEvent('foundry:size_'+s.loaded);}
 }catch(e){error('silo-display',e);}
}
function sitePoint(kind){const local=site.layout===3?SILO[kind]:kind==='controller'?{x:12,y:3,z:12}:{x:4,y:26,z:12};return {x:site.x+local.x,y:site.y+local.y,z:site.z+local.z};}
function missileScale(type){return ({kestrel_missile:.25,tempest_missile:.4,titan_missile:.65,apex_icbm:1})[type]||1;}
function guaranteeSite(){
 if(!site||site.phase==='done'||job)return;
 if(!siteArea){siteArea=loadArea(SITEAREA,site.x,site.z,64);if(!siteArea){site.error='Relic site pending: chunk loading unavailable. Reserved X '+site.x+' / Z '+site.z+'.';write(SITE,site);return;}}
 if(!areaLoaded(site.x,site.z,64))return;
 try{
  if(site.phase==='pending'){
   const result=surveyDrySite(d(),site,SILO.size,siteSurvey);siteSurvey=result.survey;
   if(result.status==='waiting')return;
   if(result.status==='rejected'){
    site={...site,...nextSiteCandidate(site),phase:'pending',error:'Searching for dry, level land for the relic silo.'};siteSurvey=null;removeArea(SITEAREA);siteArea=false;write(SITE,site);return;
   }
   if(result.status!=='ready')return;
   site.layout=3;site.y=result.surface-SILO.surfaceOffset;site.phase='placing';site.error=null;siteSurvey=null;write(SITE,site);
   world.structureManager.place('foundry:relic_silo',d(),{x:site.x,y:site.y,z:site.z});return;
  }
  const p=sitePoint('controller');
  if(d().getBlock(p)?.typeId!=='foundry:relic_controller'){
   site.attempts=(site.attempts||0)+1;
   if(site.attempts%10===0)world.structureManager.place('foundry:relic_silo',d(),{x:site.x,y:site.y,z:site.z});write(SITE,site);return;
  }
  const s=registerSilo(p,true);syncDisplay(s);site.phase='done';site.error=null;write(SITE,site);removeArea(SITEAREA);siteArea=false;
  announce('A preloaded relic silo has been established. Its entrance coordinates are recorded in the Field Manual.');
 }catch(e){site.error='Relic silo generation paused: '+String(e).slice(0,180);write(SITE,site);error('relic-generation',e);}
}
function tick(){
 frame++;if(!loaded)return;
 for(const p of world.getAllPlayers())try{if(!p.getDynamicProperty('foundry:laser_mode'))continue;const item=p.getComponent('minecraft:inventory')?.container?.getItem(p.selectedSlotIndex);if(item?.typeId!=='foundry:targeting_pad')continue;const h=p.getBlockFromViewDirection({maxDistance:240,includeLiquidBlocks:true});const dir=p.getViewDirection(),head=p.getHeadLocation();const beamLength=h?Math.min(48,Math.hypot(h.block.x+h.faceLocation.x-head.x,h.block.y+h.faceLocation.y-head.y,h.block.z+h.faceLocation.z-head.z)):48;for(let n=1;n<=beamLength;n+=.75)privateParticle(p,'laser_beam',{x:head.x+dir.x*n,y:head.y+dir.y*n,z:head.z+dir.z*n},.025);if(h){privateParticle(p,'laser_beam',{x:h.block.x+h.faceLocation.x,y:h.block.y+h.faceLocation.y,z:h.block.z+h.faceLocation.z},.1);p.onScreenDisplay.setActionBar('§aLASER → '+coords({x:h.block.x,y:h.block.y+1,z:h.block.z})+' | Use to LOCK' );}}catch{}
 try{
  if(frame%10===0)guaranteeSite();
  if(!job)return;
  const tier=MISSILES[job.type];if(!tier)return;
  if(job.phase==='arming'){
   if(areaRegion!=='launch'){if(!loadArea(AREA,Math.floor(job.start.x/16)*16-16,Math.floor(job.start.z/16)*16-16,48)){job.error='Waiting for silo chunks to load.';return;}areaRegion='launch';}
   if(!d().isChunkLoaded(job.start)){if(++job.armingWait>1200)abort('Silo chunks did not load; missile remains in storage.');return;}
   const operator=world.getAllPlayers().find(p=>p.id===job.owner);if(!operator){abort('Operator left before launch. Missile returned to storage.');return;}
   openLaunchCover(operator,job.start);
   const fault=siloCheck(entry(job.silo));
   if(fault){if(fault.startsWith('Hatch is moving')){job.error='Opening silo cover…';if(++job.armingWait>1200)abort('Cover did not finish opening; missile remains in storage.');return;}abort('Launch canceled: '+fault);return;}
   const live=entry(job.silo);if(!live||live.loaded!==job.type||!allowed(operator,live)){abort('Payload or operator changed before launch.');return;}
   live.loaded=null;live.active=true;store(live);job.phase='countdown';job.error=null;saveJob();
   announce(`${job.ownerName} armed ${tier.name}. Impact ${coords(job.target)}. Launch in 10 seconds; recommended separation ${tier.safe} blocks.`);
  }else if(job.phase==='countdown'){
   if(areaRegion!=='launch'){if(!loadArea(AREA,Math.floor(job.start.x/16)*16-16,Math.floor(job.start.z/16)*16-16,48)){job.error='Countdown paused: cannot load silo chunks.';if(frame%40===0)saveJob();return;}areaRegion='launch';}
   if(!d().isChunkLoaded(job.start)){job.armingWait++;if(job.armingWait>1200)abort('Silo chunks did not load; missile returned to storage.');return;}
   if(job.count===200){const fault=siloCheck(entry(job.silo));if(fault){abort('Launch canceled: '+fault);return;}}
   job.count--;if(job.count%20===0){try{d().playSound('foundry.siren',job.start,{volume:1,pitch:1});}catch{}saveJob();}
   if(job.count<=0){const fault=siloCheck(entry(job.silo));if(fault){abort('Launch canceled: '+fault);return;}removeDisplay(entry(job.silo));job.phase='flight';job.elapsed=0;job.error=null;saveJob();announce(tier.name+' launched. Impact '+coords(job.target)+'.');}
  }else if(job.phase==='flight')flight(tier);
  else if(job.phase==='crater'){
   job.visualAge++;if(job.visualAge<=900&&frame%2===0)detonationVisual(tier);
   if(job.type==='apex_icbm'&&job.visualAge<=2400&&frame%20===0)fallout(tier);
   excavate(tier);
  }
 }catch(e){error('worker',e);if(job){job.error=String(e).slice(0,180);if(frame%40===0)saveJob();}}
}
function flight(tier){
 job.elapsed++;
 if(job.elapsed<=90){
  if(!visual?.isValid){visual=d().spawnEntity('foundry:silo_missile',{x:job.start.x+.5,y:job.start.y+1,z:job.start.z+.5});visual.triggerEvent('foundry:flight');visual.triggerEvent('foundry:size_'+job.type);}
  const y=Math.min(308,job.start.y+1+Math.pow(job.elapsed/8,1.7));visual.teleport({x:job.start.x+.5,y,z:job.start.z+.5});
  if(frame%2===0){puff('launch_exhaust',{x:job.start.x+.5,y:y-.3,z:job.start.z+.5},1.6);puff('missile_smoke',{x:job.start.x+.5,y:y-1,z:job.start.z+.5},2);}
 }else{
  if(areaRegion!=='target'){
   removeVisual();const x=Math.floor(job.target.x/16)*16-16,z=Math.floor(job.target.z/16)*16-16;
   if(!loadArea(AREA,x,z,48)){job.elapsed--;job.error='Flight waiting for impact chunks to load.';return;}areaRegion='target';job.error=null;
  }
  if(job.elapsed>=tier.flight-80&&d().isChunkLoaded(job.target)){
   if(!visual?.isValid){visual=d().spawnEntity('foundry:silo_missile',{x:job.target.x+.5,y:Math.min(307,job.target.y+80),z:job.target.z+.5});visual.triggerEvent('foundry:flight');visual.triggerEvent('foundry:size_'+job.type);}
   const frac=Math.max(0,(tier.flight-job.elapsed)/80),y=job.target.y+(Math.min(307,job.target.y+80)-job.target.y)*frac;
   visual.teleport({x:job.target.x+.5,y,z:job.target.z+.5});visual.setRotation({x:180,y:0});if(frame%2===0)puff('launch_exhaust',{x:job.target.x+.5,y:y+20*missileScale(job.type),z:job.target.z+.5},2);
  }
 }
 if(frame%20===0)saveJob();
 if(job.elapsed>=tier.flight){if(!d().isChunkLoaded(job.target)){job.elapsed=tier.flight;job.error='Impact paused until the target chunk loads.';return;}detonate(tier);}
}
function detonate(tier){
 removeVisual();job.phase='crater';job.prismVersion=3;job.visualAge=0;job.region=0;job.run=0;job.error=null;runCache=null;saveJob();
 const s=entry(job.silo);if(s){s.active=false;s.spent=true;store(s);}
 announce(`${tier.name} impacted at ${coords(job.target)}. Terrain excavation has started; it will continue in saved batches.`);
 hurtInRadius(tier);
 if(job.type==='apex_icbm')try{blastEntity=d().spawnEntity('foundry:blast_cloud',job.target);}catch(e){error('blast-model',e);}
 for(const p of world.getAllPlayers())if(p.dimension.id==='minecraft:overworld'&&horizontalDistance(p.location,job.target)<tier.safe*3){
  try{p.camera.fade({fadeColor:{red:1,green:.96,blue:.8},fadeTime:{fadeInTime:.1,holdTime:job.type==='apex_icbm'?.6:.12,fadeOutTime:job.type==='apex_icbm'?2.5:.8}});p.playSound('foundry.nuclear_boom',{volume:1,pitch:job.type==='apex_icbm'?.6:1});}catch{}
 }
}
function hurtInRadius(tier,region=null){
 for(const e of d().getEntities({location:job.target,maxDistance:tier.danger}))try{
  if(!e.getComponent('minecraft:health')||e.typeId==='foundry:silo_missile'||e.getDynamicProperty('foundry:blast_seen')===job.strikeId)continue;
  if(region&&(e.location.x<region.x||e.location.x>=region.x+128||e.location.z<region.z||e.location.z>=region.z+128))continue;
  const dist=Math.hypot(e.location.x-job.target.x,e.location.y-job.target.y,e.location.z-job.target.z);const amount=impactDamage(dist,tier.danger,tier.damage);
  if(amount>0){e.setDynamicProperty('foundry:blast_seen',job.strikeId);e.applyDamage(Math.max(1,Math.round(amount)),{cause:EntityDamageCause.blockExplosion});if(dist<tier.radius)e.setOnFire(5,true);}
 }catch{}
}
function fallout(tier){
 for(const p of world.getAllPlayers())if(p.dimension.id==='minecraft:overworld'&&horizontalDistance(p.location,job.target)<tier.radius+50){
  try{p.addEffect('poison',45,{amplifier:0,showParticles:true});p.addEffect('weakness',45,{amplifier:1,showParticles:false});p.onScreenDisplay.setActionBar('§aFALLOUT ZONE — move beyond 300 blocks from impact');}catch{}
 }
}
function detonationVisual(tier){
 const nuclear=job.type==='apex_icbm',t=job.visualAge/20,center=job.target,growth=Math.min(1,t/7);
 if(nuclear&&blastEntity?.isValid)try{blastEntity.setProperty('foundry:growth',Math.max(.01,growth*16));}catch{}
 for(const p of world.getAllPlayers()){
  if(p.dimension.id!=='minecraft:overworld')continue;const dist=horizontalDistance(p.location,center);if(dist>2200)continue;
  const head=p.getHeadLocation(),scale=Math.min(1,90/Math.max(90,dist));
  const render=(id,x,y,z,size)=>privateParticle(p,id,{x:head.x+(x-head.x)*scale,y:head.y+(y-head.y)*scale,z:head.z+(z-head.z)*scale},Math.max(.2,size*scale));
  const height=(nuclear?235:tier.radius*1.8)*growth,cap=(nuclear?135:tier.radius)*growth;
  if(t<4){const radius=(nuclear?95:tier.radius)*Math.min(1,t/1.5);for(let k=0;k<20;k++){const a=k*Math.PI/10+t;render('nuclear_fire',center.x+Math.cos(a)*radius*.65,center.y+radius*.65,center.z+Math.sin(a)*radius*.65,radius*.75+4);}}
  // Thick rising stem, toroidal cap and rolling dust, all anchored on the real impact.
  for(let k=0;k<(nuclear?24:8);k++){
   const a=k*2.39996+t*.14,h=(k%8)/8*height,rad=(nuclear?12+h*.055:3)*growth;
   render(t<5?'nuclear_fire':'nuclear_cloud',center.x+Math.cos(a)*rad,center.y+h,center.z+Math.sin(a)*rad,nuclear?22:7);
  }
  for(let k=0;k<(nuclear?40:16);k++){
   const a=k*2.39996+t*.09,ring=.55+.4*Math.sin(k*1.71)**2,rad=cap*ring;
   render(t<4?'nuclear_fire':'nuclear_cloud',center.x+Math.cos(a)*rad,center.y+height+Math.sin(k*2.4)*cap*.22,center.z+Math.sin(a)*rad,nuclear?38:10);
  }
  if(t<10){const radius=t*(nuclear?60:16);for(let k=0;k<48;k++){const a=k*Math.PI/24;render('shockwave_dust',center.x+Math.cos(a)*radius,center.y+3,center.z+Math.sin(a)*radius,nuclear?22:5);}}
  if(t<3&&frame%10===0&&dist<1200)try{p.runCommand('camerashake add @s 0.25 0.4 positional');}catch{}
 }
}
function progress(){if(!job)return 0;if(job.terrainDone)return 100;const regions=craterRegions(job.target,MISSILES[job.type]);return Math.min(99,Math.floor((job.region+(runCache?.runs.length?job.run/runCache.runs.length:0))/regions.length*100));}
function excavate(tier){
 const regions=craterRegions(job.target,tier);
 if(job.region>=regions.length){
  if(!job.terrainDone){job.terrainDone=true;saveJob();announce('Crater excavation finished. Blast aftereffects are still active.');}
  // Keep fallout and cinematic time active even if a fast machine finished terrain early.
  if(job.visualAge<(job.type==='apex_icbm'?2400:160))return;
  announce('Missile operation complete. Crater excavation finished.');job=null;saveJob();removeArea(AREA);removeArea(PREFETCH);prefetchTag='';areaRegion='';runCache=null;return;
 }
 const region=regions[job.region],tag=region.x+','+region.z;
 if(areaRegion!==tag){
  if(!loadArea(AREA,region.x,region.z)){job.error='Terrain paused: cannot reserve its chunk-loading area. Free a ticking-area slot, then it retries automatically.';if(frame%100===0)saveJob();return;}
  areaRegion=tag;runCache=null;
  const next=regions[job.region+1];if(next){const key=next.x+','+next.z;if(prefetchTag!==key&&loadArea(PREFETCH,next.x,next.z))prefetchTag=key;}
  return;
 }
 if(!areaLoaded(region.x,region.z)){job.error='Loading terrain region '+(job.region+1)+'/'+regions.length;if(frame%40===0)saveJob();return;}
 if(!runCache||runCache.region!==tag){runCache={region:tag,runs:craterPrisms(job.target,tier,region)};}
 job.error=null;let volume=0,ops=0;const started=Date.now();
 while(job.run<runCache.runs.length&&ops<512){
  const r=runCache.runs[job.run];if(volume&&volume+r.volume>524288 || (ops>0 && Date.now()-started>=10))break;
  d().fillBlocks(new BlockVolume({x:r.x,y:r.bottom,z:r.z0},{x:r.x1,y:r.top,z:r.z1}),'minecraft:air',{blockFilter:{excludeTypes:['minecraft:bedrock','minecraft:barrier','minecraft:command_block','minecraft:chain_command_block','minecraft:repeating_command_block','minecraft:structure_block']}});
  volume+=r.volume;ops++;job.run++;
 }
 if(job.run>=runCache.runs.length){job.region++;job.run=0;runCache=null;saveJob();}
 else if(frame%10===0)saveJob();
 if(frame%200===0)for(const p of world.getAllPlayers())if(p.id===job.owner)p.onScreenDisplay.setActionBar(`§6Crater excavation ${progress()}% — work resumes after a world reload`);
}

async function repairRelic(p,s){
 if(!site||site.phase!=='done'||sid(sitePoint('controller'))!==s.id){tell(p,'This repair is only for the generated relic silo. Other silos show the exact fault coordinates.');return;}
 const f=new MessageFormData().title('REPAIR RELIC SHAFT').body('Rebuild this relic foundation and four stabilizers; clear a 3×3 vertical launch route from the controller to 80 blocks above it. The modern relic also receives a closed 17×17 cover and surface switch. Blocks in the narrow shaft will be removed. Surrounding rooms remain.').button1('Repair this relic').button2('Cancel');
 const a=await H.show(p,f);if(a.canceled||a.selection!==0||!near(p,s)||!allowed(p,s)||entry(s.id)?.active)return;
 const req=siloRequirements(s.pos,23),clear=[],base=[],stabilizers=[];
 const protectedTypes=['minecraft:bedrock','minecraft:barrier','minecraft:command_block','minecraft:chain_command_block','minecraft:repeating_command_block','minecraft:structure_block'];
 function checked(q){const b=d().getBlock(q);if(!b){tell(p,'Repair paused: required chunks are not loaded.');return null;}if(protectedTypes.includes(b.typeId)){tell(p,'Repair blocked by protected block at '+coords(b.location));return null;}return b;}
 for(let y=s.pos.y+1;y<Math.min(320,s.pos.y+80);y++)for(let x=-1;x<=1;x++)for(let z=-1;z<=1;z++){
  const b=checked({x:s.pos.x+x,y,z:s.pos.z+z});if(!b)return;
  if(b.typeId!=='foundry:blast_panel')clear.push(b);
 }
 for(const q of req.base){const b=checked(q);if(!b)return;base.push(b);}
 for(const q of req.stabilizers){const b=checked(q);if(!b)return;stabilizers.push(b);}
 const switchBlock=site.layout===3?checked({x:s.pos.x-10,y:s.pos.y+34,z:s.pos.z}):null;if(site.layout===3&&!switchBlock)return;
 base.forEach(b=>b.setType('foundry:silo_casing'));
 stabilizers.forEach(b=>b.setType('foundry:silo_stabilizer'));
 clear.forEach(b=>b.setType('minecraft:air'));
 if(site.layout===3){
  const y=s.pos.y+33;for(let x=-8;x<=8;x++)for(let z=-8;z<=8;z++){
   const b=d().getBlock({x:s.pos.x+x,y,z:s.pos.z+z});if(b&&['minecraft:air','minecraft:stone','minecraft:polished_andesite','minecraft:polished_blackstone_bricks','foundry:blast_panel'].includes(b.typeId))b.setType('foundry:blast_panel');
  }
  switchBlock.setType('foundry:hatch_switch');
 }
 tell(p,'Relic route repaired. Open any hatch cover before launch.');
}
