"""Original facility silhouettes and interiors; no imported building assets."""
from siege_build import I

def decorate_bunker(s, variant):
    wall = ['minecraft:polished_andesite', 'minecraft:stone_bricks', 'minecraft:polished_deepslate'][variant]
    for entry in s.palette:
        if entry['name'][1] == 'minecraft:polished_andesite': entry['name'] = (8, wall)
    # Ribbed blast entrance, warning borders, inset lights and ventilation.
    for x in [9, 18]:
        s.box(x, 2, 3, x, 5, 3, wall)
        s.set(x, 5, 2, 'foundry:facility_light')
    s.box(11, 1, 7, 16, 1, 7, 'foundry:hazard_trim')
    for z in [11, 17, 22]: s.set(2, 4, z, 'foundry:vent_grille')
    s.box(23, 3, 20, 29, 3, 20, 'foundry:vent_grille')
    s.set(6, 3, 22, 'foundry:range_target')
    for x, z in [(6, 11), (18, 11)]: s.set(x, 5, z, 'foundry:status_screen')
    # Reinforced lockers and cargo shelving occupy the walls, not the corridor.
    for z in [12, 16, 18]:
        s.box(29, 2, z, 29, 4, z, 'minecraft:dark_oak_planks')
        s.set(29, 3, z-1, 'foundry:hazard_trim')
    if variant == 0:  # Relay outpost: radio roof, gantry, equipment consoles.
        s.box(17, 11, 14, 20, 11, 17, 'minecraft:polished_blackstone_bricks')
        s.set(18, 12, 15, 'foundry:radar_dish')
        s.box(19, 12, 16, 19, 16, 16, 'minecraft:iron_bars')
        s.set(19, 17, 16, 'minecraft:redstone_torch')
        s.box(6, 2, 14, 10, 2, 14, 'minecraft:polished_blackstone_bricks')
        for x in [6, 8, 10]: s.set(x, 3, 14, 'foundry:status_screen')
    elif variant == 1:  # Armory vault: heavy ribs, ammunition bays and roof vents.
        for x in [4, 21]:
            for z in [8, 14, 21]: s.box(x, 2, z, x, 7, z, 'minecraft:deepslate_bricks')
        for x in [14, 17, 20]:
            s.box(x, 9, 11, x+1, 10, 14, 'minecraft:polished_blackstone_bricks')
            s.box(x, 11, 11, x+1, 11, 14, 'foundry:vent_grille')
        s.box(16, 2, 17, 20, 2, 17, 'minecraft:dark_oak_planks')
        s.set(18, 3, 17, 'foundry:hazard_trim')
        # A second armored observation bastion gives this variant a distinct skyline.
        s.box(22, 7, 10, 30, 12, 20, 'minecraft:deepslate_bricks')
        s.box(23, 8, 11, 29, 11, 19, 'minecraft:air')
        s.box(24, 10, 10, 28, 10, 10, 'minecraft:glass')
        s.box(30, 10, 13, 30, 10, 17, 'minecraft:iron_bars')
        s.box(21, 13, 9, 31, 13, 21, 'minecraft:stone_bricks')
        s.box(24, 14, 12, 28, 14, 18, 'foundry:vent_grille')
        for y in range(2, 13): s.set(29, y, 18, 'minecraft:ladder', {'facing_direction': I(5)})
        s.set(25, 11, 15, 'foundry:facility_light')
    else:  # Expedition depot: service awning and a marked exterior loading bay.
        s.box(24, 1, 22, 31, 1, 27, 'minecraft:deepslate_tiles')
        s.box(24, 1, 22, 31, 1, 22, 'foundry:hazard_trim')
        for x in [24, 31]: s.box(x, 2, 27, x, 6, 27, wall)
        s.box(23, 7, 21, 32, 7, 28, 'minecraft:polished_blackstone_bricks')
        for x in [25, 28]:
            s.box(x, 2, 25, x+1, 3, 26, 'minecraft:dark_oak_planks')
            s.set(x, 4, 25, 'foundry:hazard_trim')
        s.set(31, 5, 24, 'foundry:facility_light')
        s.box(25, 2, 20, 30, 5, 20, 'foundry:blast_panel')
        s.set(24, 3, 19, 'foundry:bunker_switch')

def decorate_silo(s):
    dark = 'minecraft:polished_blackstone_bricks'
    # Marked surface landing apron, ring service walks and a reinforced gate.
    s.box(19, 32, 0, 45, 32, 11, 'minecraft:deepslate_tiles')
    for x in [19, 45]: s.box(x, 32, 0, x, 32, 11, 'foundry:hazard_trim')
    s.box(29, 32, 3, 29, 32, 8, 'minecraft:quartz_block')
    s.box(35, 32, 3, 35, 32, 8, 'minecraft:quartz_block')
    s.box(29, 32, 5, 35, 32, 5, 'minecraft:quartz_block')
    for x in [21, 43]:
        for z in [1, 10]: s.set(x, 33, z, 'foundry:facility_light')
    # Service plinth around the retracting cover; the entire panel travel is clear.
    for x in range(20, 41):
        for z in range(16, 37):
            if x in [20, 40] or z in [16, 36]: s.set(x, 35, z, 'foundry:hazard_trim')
    for x in [21, 39]:
        for z in [19, 26, 33]: s.set(x, 35, z, 'foundry:vent_grille')
    # Observation annex gains layered buttresses, a radio dish and roof plant.
    for z in [10, 18, 30]:
        s.box(2, 24, z, 2, 35, z, dark)
        s.set(2, 32, z+1, 'foundry:facility_light')
    s.box(8, 39, 23, 11, 39, 27, dark)
    s.set(9, 40, 25, 'foundry:radar_dish')
    s.box(6, 39, 12, 8, 40, 15, 'foundry:vent_grille')
    for y in [4, 11, 18]:
        for z in [10, 18, 21]: s.set(14, y, z, 'foundry:status_screen')
        s.box(4, y-1, 25, 10, y-1, 25, 'foundry:hazard_trim')
    s.set(6, 3, 31, 'minecraft:spruce_planks')
    s.set(6, 4, 31, 'foundry:range_target')
    for y in [6, 15, 19, 26]:
        for x, z in [(38, 24), (38, 28), (30, 35)]: s.set(x, y+1, z, 'foundry:status_screen')
    # A dry surface path joins the porch, the controller cover and the apron.
    s.box(11, 32, 0, 18, 32, 2, 'minecraft:deepslate_tiles')
