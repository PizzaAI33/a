"""Build Minecraft-only strategic missile assets and little-endian structure NBT."""
from pathlib import Path
import json,struct,math,random,wave,subprocess
from PIL import Image,ImageDraw,ImageFont
from siege_catalog import MISSILES,BLOCKS

def dump(p,v):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def image(p,im):p.parent.mkdir(parents=True,exist_ok=True);im.save(p)
def font(n):return ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',n)
def string(s):
 b=s.encode();return struct.pack('<H',len(b))+b
# Typed tags prevent ambiguity between Int, Long, Compound and Lists.
def I(n):return (3,n)
def L(n):return (4,n)
def S(s):return (8,s)
def C(d):return (10,d)
def A(t,values):return (9,(t,values))
def payload(tag):
 t,v=tag
 if t==3:return struct.pack('<i',v)
 if t==4:return struct.pack('<q',v)
 if t==8:return string(v)
 if t==9:
  kind,values=v;return bytes([kind])+struct.pack('<i',len(values))+b''.join(payload((kind,n)) for n in values)
 if t==10:return b''.join(bytes([tag[0]])+string(k)+payload(tag) for k,tag in v.items())+b'\0'
 raise ValueError(t)
class Structure:
 def __init__(self,size):
  self.size=size;self.palette=[];self.indices=[0]*math.prod(size);self.entities={};self.blockid('minecraft:air')
 def index(self,x,y,z):return (x*self.size[1]+y)*self.size[2]+z
 def blockid(self,name,states=None):
  value={'name':S(name),'states':C(states or {}),'version':I(18153472)}
  if value not in self.palette:self.palette.append(value)
  return self.palette.index(value)
 def set(self,x,y,z,name,states=None):self.indices[self.index(x,y,z)]=self.blockid(name,states)
 def box(self,x0,y0,z0,x1,y1,z1,name):
  bid=self.blockid(name)
  for x in range(x0,x1+1):
   for y in range(y0,y1+1):
    for z in range(z0,z1+1):self.indices[self.index(x,y,z)]=bid
 def chest(self,x,y,z,table):
  self.set(x,y,z,'minecraft:chest',{'facing_direction':I(2)})
  self.entities[str(self.index(x,y,z))]=C({'block_entity_data':C({'id':S('Chest'),'x':I(x),'y':I(y),'z':I(z),'Items':A(10,[]),'LootTable':S('loot_tables/chests/'+table+'.json'),'LootTableSeed':L(0)})})
 def save(self,path):
  data=C({'format_version':I(1),'size':A(3,list(self.size)),'structure':C({'block_indices':A(9,[(3,self.indices),(3,[-1]*len(self.indices))]),'entities':A(10,[]),'palette':C({'default':C({'block_palette':A(10,self.palette),'block_position_data':C(self.entities)})})}),'structure_world_origin':A(3,[0,0,0])})
  path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(b'\x0a\x00\x00'+payload(data))

def structures(bp):
 # Small buried bunkers; a stair opening meets the surface five blocks above origin.
 for variant in range(3):
  s=Structure((17,12,21));wall=['minecraft:stone','minecraft:blackstone','minecraft:obsidian'][variant]
  s.box(0,0,0,16,7,20,wall);s.box(1,2,1,15,6,19,'minecraft:air')
  s.box(0,1,0,16,1,20,'minecraft:iron_block')
  for x in [4,12]:s.box(x,2,8,x,6,8,wall)
  for y in [3,5]:
   for x in [0,16]:s.set(x,y,10,'minecraft:sea_lantern')
  # Six-block entrance staircase ascending toward the front surface.
  for z in range(7):
   step=max(1,6-z);s.box(7,step+1,z,9,10,z,'minecraft:air');s.box(7,0,z,9,step,z,'minecraft:stone')
  s.chest(3,2,16,'bunker_'+str(variant));s.chest(13,2,16,'bunker_'+str(variant))
  station=['foundry:ammo_press','foundry:attachment_bench','foundry:missile_fabricator'][variant]
  s.set(8,2,17,station);s.set(8,6,15,'minecraft:sea_lantern')
  name='bunker_'+str(variant);s.save(bp/'structures/foundry'/f'{name}.mcstructure')
  dump(bp/'features'/f'{name}.json',{'format_version':'1.13.0','minecraft:structure_template_feature':{'description':{'identifier':'foundry:'+name},'structure_name':'foundry:'+name,'adjustment_radius':0,'facing_direction':'random','constraints':{}}})
  dump(bp/'feature_rules'/f'{name}_rule.json',{'format_version':'1.13.0','minecraft:feature_rules':{'description':{'identifier':'foundry:'+name+'_rule','places_feature':'foundry:'+name},'conditions':{'placement_pass':'surface_pass','minecraft:biome_filter':{'all_of':[{'test':'has_biome_tag','operator':'==','value':'overworld'},{'test':'has_biome_tag','operator':'!=','value':'ocean'},{'test':'has_biome_tag','operator':'!=','value':'river'}]}},'distribution':{'iterations':1,'scatter_chance':.22,'coordinate_eval_order':'xzy','x':0,'z':0,'y':'query.heightmap(variable.worldx, variable.worldz) - 5'}}})
 # Dedicated 25×32×25 relic silo. Local controller coordinates are a runtime contract.
 s=Structure((25,32,25));s.box(0,0,0,24,24,24,'minecraft:stone');s.box(1,2,1,23,23,23,'minecraft:air')
 s.box(0,1,0,24,1,24,'minecraft:iron_block')
 for x in [1,23]:
  for z in [1,23]:s.box(x,2,z,x,23,z,'minecraft:obsidian')
 s.box(10,2,10,14,2,14,'foundry:silo_casing')
 for x in [10,14]:
  for z in [10,14]:s.set(x,3,z,'foundry:silo_stabilizer')
 s.set(12,3,12,'foundry:relic_controller');s.box(9,24,9,15,31,15,'minecraft:air')
 # Access hut and ladder beside the open shaft, entrance at X12,Z12, top Y26.
 s.box(2,24,10,6,28,14,'minecraft:iron_block');s.box(3,24,11,5,27,13,'minecraft:air')
 s.box(6,25,11,6,26,13,'minecraft:air')
 s.box(3,2,10,3,27,10,'minecraft:stone')
 for y in range(2,28):s.set(3,y,11,'minecraft:ladder',{'facing_direction':I(3)})
 for x,z in [(2,2),(22,2),(2,22),(22,22)]:s.set(x,20,z,'minecraft:sea_lantern');s.set(x,4,z,'minecraft:sea_lantern')
 for x,z in [(5,5),(19,5),(19,19)]:s.chest(x,2,z,'relic_silo')
 s.set(5,2,19,'foundry:missile_fabricator');s.set(6,2,19,'foundry:attachment_bench')
 s.save(bp/'structures/foundry/relic_silo.mcstructure')

def loot(bp):
 from catalog import GUNS,ATTACHMENTS,AMMO
 groups=[[g for g in GUNS if g['category'] in ['Pistols','Submachine guns']], [g for g in GUNS if g['category'] in ['Assault rifles','Shotguns']],GUNS]
 def entry(id,weight=1,count=None):
  e={'type':'item','name':id,'weight':weight}
  if count:e['functions']=[{'function':'set_count','count':{'min':count[0],'max':count[1]}}]
  return e
 for i in range(4):
  guns=groups[min(i,2)] or GUNS
  pools=[{'rolls':{'min':1,'max':2},'entries':[entry('foundry:'+g['id']) for g in guns]},
   {'rolls':{'min':3,'max':5},'entries':[entry('foundry:'+id,2,(12,40)) for id in AMMO]},
   {'rolls':{'min':1,'max':3},'entries':[entry('foundry:'+id) for id in ATTACHMENTS]},
   {'rolls':{'min':2,'max':4},'entries':[entry('foundry:reinforced_alloy',5,(1,4)),entry('foundry:circuit',5,(2,8)),entry('foundry:power_cell',4,(1,4)),entry('foundry:fluxite_crystal',4,(2,6)),entry('foundry:dense_alloy',2,(1,2)),entry('foundry:guidance_matrix',1),entry('minecraft:diamond',3,(1,3)),entry('minecraft:netherite_scrap',1)]}]
  dump(bp/'loot_tables/chests'/('relic_silo.json' if i==3 else f'bunker_{i}.json'),{'pools':pools})

def expand(bp,rp,out,root):
 for p in [bp/'manifest.json',rp/'manifest.json']:
  j=json.loads(p.read_text());j['header']['version']=[0,2,0]
  j['header']['description']='Foundry Arsenal 0.2: 120 guns, loot bunkers, buildable silos and four strategic missile tiers. Development build.'
  for m in j['modules']:m['version']=[0,2,0]
  for dep in j.get('dependencies',[]):
   if 'uuid' in dep:dep['version']=[0,2,0]
  dump(p,j)
 (bp/'scripts/siege_data.js').write_text('export const MISSILES = '+json.dumps(MISSILES)+';\n')
 with (bp/'scripts/data.js').open('a') as f:f.write('\nObject.assign(NAMES,'+json.dumps({'foundry:'+k:v for k,v in BLOCKS.items()})+');\n')
 atlas=json.loads((rp/'textures/item_texture.json').read_text());terrain=json.loads((rp/'textures/terrain_texture.json').read_text());sounds=json.loads((rp/'blocks.json').read_text())
 for id,name in BLOCKS.items():
  components={'minecraft:geometry':'minecraft:geometry.full_block','minecraft:material_instances':{'*':{'texture':id,'render_method':'opaque'}},'minecraft:destructible_by_mining':{'seconds_to_destroy':4},'minecraft:destructible_by_explosion':{'explosion_resistance':30},'minecraft:loot':'loot_tables/blocks/'+id+'.json','minecraft:map_color':'#657275'}
  if 'controller' in id:components['foundry:siege_control']={};components['minecraft:light_emission']=3
  dump(bp/'blocks'/f'{id}.json',{'format_version':'1.21.120','minecraft:block':{'description':{'identifier':'foundry:'+id,'menu_category':{'category':'construction'}},'components':components}})
  drop='silo_controller' if id=='relic_controller' else id
  dump(bp/'loot_tables/blocks'/f'{id}.json',{'pools':[{'rolls':1,'entries':[{'type':'item','name':'foundry:'+drop}]}]})
  im=Image.new('RGB',(16,16),'#4b5a60');dr=ImageDraw.Draw(im);dr.rectangle((0,0,15,15),outline='#1c2b33',width=2)
  for x,y in [(2,2),(13,2),(2,13),(13,13)]:dr.point((x,y),fill='#b3c4c1')
  if 'controller' in id:dr.rectangle((3,4,12,11),fill='#101e27');dr.line((4,7,11,7),fill='#abdf82');dr.point((10,10),fill='#ed804a')
  elif id=='silo_stabilizer':dr.rectangle((5,2,10,13),fill='#d8bd65');dr.line((7,3,7,12),fill='#282f32',width=2)
  else:dr.rectangle((4,4,11,11),outline='#a1aeac')
  image(rp/'textures/blocks'/f'{id}.png',im);image(rp/'textures/items'/f'{id}.png',im)
  atlas['texture_data'][id]={'textures':'textures/items/'+id};terrain['texture_data'][id]={'textures':'textures/blocks/'+id};sounds['foundry:'+id]={'sound':'metal'}
  for lang in ['en_US','en_GB']:
   with (rp/'texts'/f'{lang}.lang').open('a') as f:f.write('tile.foundry:'+id+'.name='+name+'\n')
 dump(rp/'textures/item_texture.json',atlas);dump(rp/'textures/terrain_texture.json',terrain);dump(rp/'blocks.json',sounds)
 for id,tier in MISSILES.items():
  im=Image.new('RGBA',(32,32));dr=ImageDraw.Draw(im);dr.polygon([(16,1),(21,9),(21,25),(25,30),(18,27),(14,27),(7,30),(11,25),(11,9)],fill=tier['color'],outline='#1b292f');dr.rectangle((12,12,20,15),fill='#35444a');dr.rectangle((14,25,18,29),fill='#fbaa4c');image(rp/'textures/items'/f'{id}.png',im)
  p=bp/'items'/f'{id}.json';j=json.loads(p.read_text());j['minecraft:item']['components']['minecraft:max_stack_size']=1;dump(p,j)
 for id in ['targeting_pad','laser_designator']:
  im=Image.new('RGBA',(32,32));dr=ImageDraw.Draw(im)
  if id=='targeting_pad':
   dr.rounded_rectangle((4,3,27,29),3,fill='#566771',outline='#111e28',width=2);dr.rectangle((7,6,24,24),fill='#173d38')
   for n in [10,16,22]:dr.line((7,n,24,n),fill='#3b6962');dr.line((n,6,n,24),fill='#3b6962')
   dr.ellipse((12,11,20,19),outline='#d6eb91');dr.line((16,8,16,22),fill='#d6eb91');dr.line((10,15,22,15),fill='#d6eb91')
  else:dr.rectangle((5,13,25,20),fill='#586970',outline='#17232d');dr.rectangle((10,19,15,28),fill='#34444e');dr.rectangle((17,8,23,12),fill='#cf6258');dr.line((24,11,31,6),fill='#f54d46',width=2)
  image(rp/'textures/items'/f'{id}.png',im)
 structures(bp);loot(bp);effects(bp,rp)
 (bp/'functions/foundry/siege_demo.mcfunction').write_text('\n'.join(['# Optional operator supplies. Does not launch or excavate anything.']+[f'give @s foundry:{id} {n}' for id,n in [('silo_casing',32),('silo_stabilizer',4),('silo_controller',1),('missile_fabricator',1),('targeting_pad',1),('laser_designator',1)]+[(id,1) for id in MISSILES]])+'\n')

def effects(bp,rp):
 dump(bp/'entities/silo_missile.json',{'format_version':'1.21.0','minecraft:entity':{'description':{'identifier':'foundry:silo_missile','is_spawnable':False,'is_summonable':True},'components':{'minecraft:type_family':{'family':['foundry_missile']},'minecraft:collision_box':{'width':0,'height':0},'minecraft:physics':{'has_gravity':False,'has_collision':False},'minecraft:pushable':{'is_pushable':False,'is_pushable_by_piston':False},'minecraft:persistent':{},'minecraft:damage_sensor':{'triggers':[{'cause':'all','deals_damage':'no'}]}}}})
 entity_path=bp/'entities/silo_missile.json';entity=json.loads(entity_path.read_text());body=entity['minecraft:entity']
 body['component_groups']={'foundry:flight':{'minecraft:timer':{'looping':False,'time':120,'time_down_event':{'event':'foundry:expire','target':'self'}}},'foundry:remove':{'minecraft:instant_despawn':{}}}
 body['events']={'foundry:flight':{'add':{'component_groups':['foundry:flight']}},'foundry:expire':{'add':{'component_groups':['foundry:remove']}}};dump(entity_path,entity)
 dump(rp/'entity/silo_missile.entity.json',{'format_version':'1.10.0','minecraft:client_entity':{'description':{'identifier':'foundry:silo_missile','materials':{'default':'entity_alphatest'},'textures':{'default':'textures/entity/silo_missile'},'geometry':{'default':'geometry.foundry.silo_missile'},'animations':{'orientation':'animation.foundry.missile_orientation'},'scripts':{'animate':['orientation']},'render_controllers':['controller.render.foundry.gun']}}})
 dump(rp/'animations/missile.animation.json',{'format_version':'1.8.0','animations':{'animation.foundry.missile_orientation':{'loop':True,'bones':{'root':{'rotation':['query.target_x_rotation',0,0]}}}}})
 cubes=[]
 def cube(o,s,color=0):cubes.append({'origin':o,'size':s,'uv':{f:{'uv':[color*8,0],'uv_size':[8,8]} for f in ['north','south','east','west','up','down']}})
 cube([-5,5,-5],[10,57,10]);cube([-4,62,-4],[8,6,8],1);cube([-3,68,-3],[6,5,6],1);cube([-2,73,-2],[4,4,4],1);cube([-1,77,-1],[2,3,2],1)
 cube([-5.1,45,-5.1],[10.2,6,10.2],2);cube([-3,0,-3],[6,5,6],2)
 for o,s in [([-11,3,-1],[6,16,2]),([5,3,-1],[6,16,2]),([-1,3,-11],[2,16,6]),([-1,3,5],[2,16,6])]:cube(o,s,1)
 dump(rp/'models/entity/silo_missile.geo.json',{'format_version':'1.12.0','minecraft:geometry':[{'description':{'identifier':'geometry.foundry.silo_missile','texture_width':24,'texture_height':8,'visible_bounds_width':4,'visible_bounds_height':12,'visible_bounds_offset':[0,2,0]},'bones':[{'name':'root','pivot':[0,40,0],'cubes':cubes}]}]})
 im=Image.new('RGBA',(24,8));dr=ImageDraw.Draw(im)
 for n,c in enumerate(['#c6cbc0','#637379','#babb64']):dr.rectangle((n*8,0,n*8+7,7),fill=c)
 image(rp/'textures/entity/silo_missile.png',im)
 # Soft pixel-cloud silhouette, generated deterministically as a native texture asset.
 im=Image.new('RGBA',(32,32));dr=ImageDraw.Draw(im)
 for r,alpha in [(15,20),(13,45),(11,80),(8,115),(5,170)]:dr.ellipse((16-r,16-r,16+r,16+r),fill=(255,255,255,alpha))
 image(rp/'textures/particle/cloud.png',im)
 styles={'target_marker':([1,.15,.1,1],2,0),'launch_exhaust':([1,.64,.18,.9],.65,-1),'missile_smoke':([.65,.68,.7,.65],3,.6),'nuclear_fire':([1,.60,.20,.9],2.5,1),'nuclear_cloud':([.44,.42,.38,.8],4,1.4),'shockwave_dust':([.72,.65,.48,.7],1.5,.3)}
 for id,(color,life,lift) in styles.items():
  color=color[:3]+[str(color[3])+' * (1 - variable.particle_age / variable.particle_lifetime)']
  dump(rp/'particles'/f'{id}.json',{'format_version':'1.10.0','particle_effect':{'description':{'identifier':'foundry:'+id,'basic_render_parameters':{'material':'particles_blend','texture':'textures/particle/cloud'}},'components':{'minecraft:emitter_rate_instant':{'num_particles':1},'minecraft:emitter_lifetime_once':{'active_time':.01},'minecraft:emitter_shape_point':{},'minecraft:particle_lifetime_expression':{'max_lifetime':life},'minecraft:particle_appearance_billboard':{'size':['variable.foundry_size','variable.foundry_size'],'facing_camera_mode':'lookat_xyz','uv':{'texture_width':32,'texture_height':32,'uv':[0,0],'uv_size':[32,32]}},'minecraft:particle_appearance_tinting':{'color':color},'minecraft:particle_motion_dynamic':{'linear_acceleration':[0,lift,0],'linear_drag_coefficient':.1},'minecraft:particle_initial_speed':0}}})
 soundfile=rp/'sounds/sound_definitions.json';j=json.loads(soundfile.read_text());rate=22050
 for name,duration in [('siren',.65),('nuclear_boom',6)]:
  rng=random.Random(name);samples=[];low=0
  for n in range(int(rate*duration)):
   t=n/rate;noise=rng.uniform(-1,1);low=.96*low+.04*noise
   if name=='siren':v=math.sin(2*math.pi*(460*t+100*t*t))*.4*min(1,t*30)*min(1,(duration-t)*20)
   else:v=(low*3+noise*.18+math.sin(2*math.pi*35*t)*.27)*math.exp(-t/.95)*min(1,t*100)
   samples.append(struct.pack('<h',int(max(-1,min(1,v))*28000)))
  wav=rp/(name+'.wav')
  with wave.open(str(wav),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(rate);w.writeframes(b''.join(samples))
  subprocess.run(['ffmpeg','-loglevel','error','-y','-i',str(wav),'-c:a','libvorbis',str(rp/'sounds/foundry'/f'{name}.ogg')],check=True);wav.unlink()
  j['sound_definitions']['foundry.'+name]={'category':'block','sounds':[{'name':'sounds/foundry/'+name,'stream':False}]}
 dump(soundfile,j)

def expand_guide(out):
 p=out/'Foundry_Arsenal_Field_Guide.html';s=p.read_text().replace('BUILD 0.1.0','BUILD 0.2.0').replace('Craft the four stations','Crafting stations').replace('Explosions do not break terrain in this version.','Handheld grenades and rockets do not break terrain. Strategic silo missiles do.').replace('homing launchers or destructive explosions.','homing handheld launchers.').replace('Cheats are only needed for the optional demo command.','Operator commands need cheats. Remote silo placement and strikes also depend on Minecraft allowing script-issued ticking-area commands and having free ticking-area capacity; failure is shown in the targeting status.')
 rows=''.join(f'<tr><td>{t["name"]}</td><td>{t["radius"]*2}</td><td>{t["depth"]}</td><td>{t["danger"]}</td><td>{t["safe"]}+</td></tr>' for t in MISSILES.values())
 extra='''<h2>Bunkers &amp; the relic silo — new in 0.2</h2><p>Three bunker variants generate sparsely in new Overworld land chunks. Search the entrances for randomized weapon, ammunition, attachment and component chests. One relic silo site is reserved near the world's original spawn and placed once by the script, with one loaded Apex Nuclear ICBM. Read <b>Field Manual → Bunkers, silos &amp; missiles</b> for its entrance coordinates and placement status. The missile never replenishes.</p><p>The reserved site is prepared using temporary chunk loading, so it does not require you to discover it first. If the game refuses chunk loading, it remains pending and the manual reports the problem. Bunkers only appear in newly generated chunks. The relic site may replace terrain or builds at its reserved location: start in a new test world.</p><h2>Build your missile silo</h2><ol><li>Craft a Missile Fabricator in a normal crafting table: top row <b>diamond / redstone block / diamond</b>; middle <b>obsidian / furnace / obsidian</b>; bottom <b>iron block / iron block / iron block</b>.</li><li>Use the Fabricator for all silo parts, targeting tools and missiles. The full recipes are listed below. Apex requires two Stellar Cores, each containing a Nether Star, four Netherite Ingots and eight Echo Shards, plus additional costly modules.</li><li>Build a full <b>5×5 Silo Casing foundation</b> (25 blocks). Place a Silo Controller one block above its center. Put a Silo Stabilizer at each of the four corners, level with the controller.</li><li>Leave a clear <b>3×3 shaft, 11 blocks high</b>, directly above the controller. A visible missile appears above the loaded controller. Keep the sky path open for the best launch visual.</li><li>Use the controller with an empty hand. Claim/bind the silo and receive its targeting pad; load a crafted missile. The first claimant controls loading and launch through the interface.</li></ol><h2>Choose and verify your target</h2><p><b>Laser Designator:</b> Use/right-click a block within 240 blocks to select its surface. Sneak + Use opens the targeting screen for distant coordinate entry. <b>Targeting Pad:</b> Use to enter exact X/Y/Z, review chunk grid, horizontal distance, damage radius and recommended separation. Y is the impact surface height and controls excavation depth. Aim at ground level for a crater.</p><p>Review the final launch confirmation, then a <b>10-second countdown</b> starts. Cancel your own countdown from the pad before launch. Once launched, the strike continues even if you leave the area. One strategic missile operation can run at a time. This expansion works in the Overworld.</p><table><tr><th>Missile</th><th>Crater width</th><th>Max depth</th><th>Damage radius</th><th>Recommended distance</th></tr>'''+rows+'''</table><p>All distances are Minecraft blocks. The display gives a modeled horizontal separation, not protection against falls, lava, other players or later terrain changes. Launches are publicly announced with coordinates. Strategic damage affects players and creatures.</p><h2>Apex detonation &amp; terrain excavation</h2><p>The Apex produces a flash, synthesized boom, expanding dust shockwave and rising particle mushroom cloud. Launch and descent use a stylized 3D missile with exhaust. Distant observers see a per-player projected particle effect in the direction of the real blast; it does not alter the real impact position. The four missile tiers share a missile model and use scaled effects.</p><p>The largest crater is a <b>500-block-wide circular bowl, up to 100 blocks deep at its center</b>, with progressively shallower edges. It is not a 500×500 square or a uniformly 100-deep cylinder. Terrain up to 80 blocks above impact is also cleared inside its circle. Bedrock and protected command/structure blocks remain, and world-height limits clip excavation. Lava, water, gravity and later game updates may alter the finished shape.</p><p>Excavation is permanent and runs in bounded, saved batches across temporarily loaded regions. It may take minutes and can cause lag on slower worlds. The pad shows progress and any pause reason. Leaving and reopening the world resumes saved work. Fallout applies poison and weakness within 300 blocks for approximately two minutes of active simulation. No real radiation simulation is attempted.</p><p><b>Development build:</b> these features have code and asset checks but no Minecraft client play-test. Test in a disposable world first. Natural placement, chest loot, missile animation, distant chunk loading and excavation need in-game validation. Do not treat a completed download as proof of client compatibility.</p><p>Optional operator supplies: <code>/function foundry/siege_demo</code>. This only gives equipment; it does not launch a missile.</p>'''
 s=s.replace('<h2>Controls</h2>',extra+'<h2>Controls</h2>');p.write_text(s)
 p=out/'Foundry_Arsenal_Preview.png';im=Image.open(p);dr=ImageDraw.Draw(im);dr.rectangle((45,96,1370,145),fill='#111c26');dr.text((57,104),'120 GUNS  /  BUNKERS  /  BUILDABLE SILOS  /  4 MISSILE TIERS',font=font(23),fill='#badb8b');im.save(p)
