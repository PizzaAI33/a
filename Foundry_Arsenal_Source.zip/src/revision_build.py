"""Version 0.4: original assets and repairs informed by the reference review."""
import json,copy,math
from pathlib import Path
from PIL import Image,ImageDraw
from siege_build import dump,image
from polish_build import box
from catalog import GUNS
from siege_catalog import MISSILES

def revise(bp,rp,out,root):
 # A static visible root and native synchronized scale replace the fragile Molang scale.
 p=bp/'entities/silo_missile.json';j=json.loads(p.read_text());e=j['minecraft:entity'];e['components']['minecraft:scale']={'value':1}
 sizes=[.25,.4,.65,1]
 for (id,m),scale in zip(MISSILES.items(),sizes):
  key='foundry:size_'+id;e['component_groups'][key]={'minecraft:scale':{'value':scale}}
  e['events'][key]={'remove':{'component_groups':['foundry:size_'+x for x in MISSILES]},'add':{'component_groups':[key]}}
 dump(p,j)
 # Unambiguous fractions: each of the three variants has a 1/4500 placement chance.
 for p in bp.glob('feature_rules/bunker_*_rule.json'):
  j=json.loads(p.read_text());j['minecraft:feature_rules']['distribution']['scatter_chance']={'numerator':1,'denominator':4500};dump(p,j)
 p=rp/'particles/target_marker.json';j=json.loads(p.read_text());j['particle_effect']['description']['identifier']='foundry:laser_beam'
 c=j['particle_effect']['components'];c['minecraft:particle_lifetime_expression']['max_lifetime']=.065
 c['minecraft:particle_appearance_billboard']['uv'].update(texture_width=64,texture_height=64,uv_size=[64,64])
 c['minecraft:particle_appearance_tinting']['color']=[1,.08,.025,1]
 dump(rp/'particles/laser_beam.json',j)
 workbenches(bp,rp)
 weapon_families(rp)
 for p in [bp/'manifest.json',rp/'manifest.json']:
  j=json.loads(p.read_text());j['header']['version']=[0,4,0];j['header']['name']=j['header']['name'].replace('120 individually','60 individually').replace('120 Weapons','60 Weapons')
  j['header']['description']='Foundry Arsenal 0.4 — 60 weapons, TNT-style explosives, locked laser targeting, detailed workbenches and an eight-deck silo. Client testing required.'
  for m in j['modules']:m['version']=[0,4,0]
  for d in j.get('dependencies',[]):
   if 'uuid' in d:d['version']=[0,4,0]
  dump(p,j)


def workbenches(bp,rp):
 ids=['gunsmith_bench','ammo_press','attachment_bench','missile_fabricator','alloy_forge']
 for n,id in enumerate(ids):
  cubes=[box([-8,12,-8],[16,3,16],0),box([-7,3,4],[14,2,3],1)]
  for x in [-7,5]:
   for z in [-7,5]:cubes.append(box([x,0,z],[2,12,2],1))
  # A small drawer bank, handles, cross braces, and an inset work mat.
  cubes.extend([box([1,6,-6],[5,6,11],1),box([2,8,-6.2],[3,.6,.5],2),box([2,11,-6.2],[3,.6,.5],2),box([-6,15,-5],[10,.2,10],3)])
  if id=='gunsmith_bench':
   cubes.extend([box([-6,15,1],[3,2,4],2),box([-6,17,1],[1,2,4],2),box([-3,17,1],[1,2,4],2),box([-7,16,2],[5,.7,.7],2),box([1,15.2,-4],[1,.5,6],2),box([.2,15.2,1],[2.6,.8,1.4],2)])
  elif id=='ammo_press':
   cubes.extend([box([-5,15,1],[4,1,5],2),box([-5,16,4],[1.3,7,1.3],2),box([-5,22,1],[4,1,4],2),box([-2,18,2],[.8,5,.8],2),box([-2,18,-2],[.7,.7,5],1)])
   for x in [1,3,5]:cubes.append(box([x,15,-3],[.8,2.5,.8],4))
  elif id=='attachment_bench':
   cubes.extend([box([-5,15,3],[7,1,3],2),box([-5,16,3],[1,3,3],2),box([1,16,3],[1,3,3],2),box([-3,15,-3],[4,1,1],2),box([3,15,-1],[1,.7,4],4)])
  elif id=='missile_fabricator':
   cubes.extend([box([-7,15,5],[14,1,2],2),box([-7,16,5],[1,6,2],2),box([6,16,5],[1,6,2],2),box([-7,21,5],[14,1,2],2),box([-1,17,5],[2,4,2],4),box([-1,15,-4],[5,.5,6],3)])
  else:
   cubes=[box([-8,0,-8],[16,3,16],2),box([-8,3,-8],[3,9,16],1),box([5,3,-8],[3,9,16],1),box([-5,3,5],[10,9,3],1),box([-8,12,-8],[16,3,16],2),box([-4,3,-6],[8,.5,10],4),box([-6,15,3],[5,7,4],2)]
  geo={'description':{'identifier':'geometry.foundry.'+id,'texture_width':64,'texture_height':16,'visible_bounds_width':2,'visible_bounds_height':3,'visible_bounds_offset':[0,1,0]},'bones':[{'name':'bench','pivot':[0,0,0],'cubes':cubes}]}
  dump(rp/'models/blocks'/f'{id}.geo.json',{'format_version':'1.12.0','minecraft:geometry':[geo]})
  im=Image.new('RGB',(64,16),'#464d49');dr=ImageDraw.Draw(im)
  for i,col in enumerate(['#9e7950','#514b40','#657577',['#385b55','#395447','#37576b','#31596b','#563c30'][n],'#c7944b']):
   dr.rectangle((i*8,0,i*8+7,15),fill=col)
   for y in range(1,16,4):dr.line((i*8,y,i*8+7,y),fill=tuple(min(255,v+14) for v in im.getpixel((i*8,y))))
  # Nine-square layout makes the top read as a crafting surface.
  for x in [25,27,29,31]:dr.line((x,0,x,7),fill='#98b8a2')
  for y in [0,2,4,6]:dr.line((24,y,31,y),fill='#98b8a2')
  image(rp/'textures/blocks'/f'{id}.png',im)
  p=bp/'blocks'/f'{id}.json';j=json.loads(p.read_text());c=j['minecraft:block']['components'];c['minecraft:geometry']='geometry.foundry.'+id
  c['minecraft:collision_box']={'origin':[-8,0,-8],'size':[16,15,16]};c['minecraft:selection_box']={'origin':[-8,0,-8],'size':[16,16,16]};dump(p,j)


def weapon_families(rp):
 p=rp/'animations/guns.animation.json';j=json.loads(p.read_text());a=j['animations'];base=a['animation.foundry.mechanism']
 for family in ['pistol','revolver','rifle','bolt','pump','belt','launcher']:
  rig=copy.deepcopy(base);b=rig['bones']
  if family=='revolver':
   b['magazine']={'position':['v.reload_curve * 2.3',0,0],'rotation':[0,0,'v.r * 720']};b['case']['scale']=0
  elif family=='pump':
   b['magazine']={'position':[0,0,0]};b['action']={'position':[0,0,'math.sin(math.clamp((1-v.k)*1.6,0,1)*180) * 2.5 * (v.k > 0 ? 1 : 0)']};b['support_hand']['position']=[0,'-v.reload_curve*2','v.k * 2 + v.reload_curve*3']
  elif family=='bolt':b['action']={'position':[0,0,'v.k*2.6'],'rotation':[0,0,'v.k*-40']}
  elif family=='belt':b['action']={'rotation':['v.reload_curve * -70',0,0]};b['magazine']['position']=[0,'-v.reload_curve*5',0]
  elif family=='launcher':
   b['magazine']={'position':[0,0,'v.reload_curve*-12'],'scale':'v.r > 0.05 ? 1 : 0'};b['case']['scale']=0
  a['animation.foundry.mechanism_'+family]=rig
 for g in GUNS:
  cat=g['category'];family='revolver' if g['style']=='revolver' else 'pistol' if cat=='Pistols' else 'pump' if cat=='Shotguns' and g['style']!='auto' else 'bolt' if cat=='Sniper rifles' else 'belt' if cat=='Machine guns' else 'launcher' if cat=='Launchers' else 'rifle'
  p2=rp/'attachables'/f'{g["id"]}.json';att=json.loads(p2.read_text());desc=att['minecraft:attachable']['description'];desc['animations']['mechanism']='animation.foundry.mechanism_'+family
  desc['scripts']['initialize']=['v.k = 0;','v.a = 0;','v.r = 0;']
  for prop,v,speed in [('kick','k',38),('aim','a',16)]:
   i=0 if prop=='kick' else 2
   desc['scripts']['pre_animation'][i]=f"v.{v} = math.lerp(v.{v}, query.has_property('foundry:{prop}') ? query.property('foundry:{prop}') : 0, math.min(1, query.delta_time * {speed}));"
  dump(p2,att)
  path=rp/'models/entity'/f'{g["id"]}.geo.json';geo=json.loads(path.read_text());bones={b['name']:b for b in geo['minecraft:geometry'][0]['bones']}
  # Functional parts receive silhouettes specific to their reload family.
  if family=='revolver':
   bones['action']['cubes']=[];bones['magazine']['pivot']=[0,1,0];bones['magazine']['cubes']=[box([-1.2,0,-1],[2.4,2.4,3],2)]
  if family=='pump':bones['action']['cubes']=[box([-1.25,-.7,-12],[2.5,2,5],1)]
  if family=='bolt':bones['action']['cubes']=[box([1.3,.8,0],[2,.5,.5],2),box([2.8,.2,0],[.6,1.2,.6],0)]
  if family=='launcher':bones['magazine']['cubes']=[box([-.75,0,-15],[1.5,1.5,7],1)]
  # Receiver bevel strips, trigger guard, butt-pad and visible ejection port.
  if cat!='Launchers':bones['weapon']['cubes'].extend([box([-1.25,-2,0],[.4,1.5,3],0),box([.85,-2,0],[.4,1.5,3],0),box([-1.25,-2.4,0],[2.5,.4,3],0),box([1.51,1,-1],[.08,.7,1.6],0)])
  dump(path,geo)
 dump(p,j)


def revise_guide(out,root):
 p=out/'Foundry_Arsenal_Field_Guide.html';s=p.read_text().replace('0.3.0','0.4.0').replace('0.3','0.4').replace('120 individually','60 individually').replace('120 Weapons','60 Weapons')
 s=s.replace('Activate computer laser','Aim laser / lock new target').replace('Review and launch','Fire at locked target')
 s=s.replace('Handheld grenades and rockets do not break terrain. Strategic silo missiles do.','Explosive handheld grenades and rockets damage terrain and entities using native explosions. Smoke and flash are non-destructive.').replace('Shock: damage, weakness and chaining.','Shock grenade: native blast with arc visuals. Shock firearm cores retain chaining.')
 s=s.replace('Handheld explosives damage entities, not terrain.','Frag grenades and launcher rounds damage terrain and entities using native explosions. Smoke and flash are non-destructive.')
 section='''<h2>Version 0.4 — repair build</h2><p><b>60 curated weapons.</b> Guns and the computer use hand-bound geometry. Recoil and reload rigs have seven families. The missile uses a static visible root with native entity scaling. These are candidate fixes: first-person alignment and actual rendering still require a Minecraft client test.</p><p><b>Targeting:</b> bind your computer at a loaded controller → Use computer → Aim laser / lock new target → aim at a surface → Use to lock → Fire at locked target → review distance and confirm. Turning away after locking does not change saved XYZ. Manual entry remains optional.</p><p><b>World changes:</b> bunker attempts are about ten times rarer: 1/4500 per variant per eligible chunk, approximately 1/1500 combined before placement rejection. Existing bunkers are not removed. New silos include eight annular decks, operations rooms, machine rooms and cable galleries. Old generated silos remain unchanged.</p><p><b>Explosives:</b> frag, frost, shock and incendiary explosives and launcher rounds now use native explosions; only incendiary payloads request fire. Smoke and flash remain non-destructive. Native explosion resistance and game settings apply. The Apex excavation remains a 500-block-wide circular bowl, up to 100 deep, bounded by world height; chunk loading and tick time limit speed.</p><p><b>Upgrade:</b> import both matching 0.4 packs into a new test world. Sixty removed weapon IDs are not migrated; keep your old world backed up. Disable other packs overriding player behavior during the rendering test. This pack adds visual properties to the vanilla player behavior and can conflict with other player overrides.</p>'''
 refs=(root/'src/reference_review.html').read_text();s=s.replace('</main>',section+refs+'</main>');p.write_text(s)
