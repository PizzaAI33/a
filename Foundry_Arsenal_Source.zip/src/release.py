VERSION = [0, 7, 0]
VERSION_TAG = '.'.join(map(str, VERSION))
