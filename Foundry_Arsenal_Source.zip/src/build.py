from pathlib import Path
import json,sys,uuid,shutil,zipfile,math,random,hashlib,html,subprocess,wave,struct
from PIL import Image,ImageDraw,ImageFont,ImageColor
from catalog import *

ROOT=Path(__file__).resolve().parents[1]; BUILD=ROOT/'build'; BP=BUILD/'Foundry_Arsenal_BP'; RP=BUILD/'Foundry_Arsenal_RP'; OUT=ROOT/'output'
def uid(s):return str(uuid.uuid5(uuid.NAMESPACE_URL,'https://foundry-arsenal.local/v1/'+s))
def dump(path,data):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(data,indent=2)+'\n')
def rgb(c):return ImageColor.getrgb(c)
def shade(c,n):return tuple(max(0,min(255,v+n)) for v in c)
def saveim(im,path):path.parent.mkdir(parents=True,exist_ok=True);im.save(path)
def font(size,bold=False):
 for p in ['/usr/share/fonts/truetype/dejavu/DejaVuSans'+('-Bold' if bold else '')+'.ttf','/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf']:
  if Path(p).exists():return ImageFont.truetype(p,size)
 return ImageFont.load_default()

if BUILD.exists():shutil.rmtree(BUILD)
BP.mkdir(parents=True);RP.mkdir(parents=True);OUT.mkdir(exist_ok=True)
bpuid,rpuid=uid('bp'),uid('rp')
dump(BP/'manifest.json',{'format_version':2,'header':{'name':'Foundry Arsenal | 60 Weapons','description':'60 firearms, 24 attachments, 6 ores, 4 stations. Development build 0.1.0.','uuid':bpuid,'version':[0,1,0],'min_engine_version':[1,21,120]},'modules':[{'type':'data','uuid':uid('bp-data'),'version':[0,1,0]},{'type':'script','language':'javascript','entry':'scripts/main.js','uuid':uid('script'),'version':[0,1,0]}],'dependencies':[{'uuid':rpuid,'version':[0,1,0]},{'module_name':'@minecraft/server','version':'2.3.0'},{'module_name':'@minecraft/server-ui','version':'2.0.0'}],'metadata':{'authors':['Created for Ethan Morgan'],'product_type':'addon'}})
dump(RP/'manifest.json',{'format_version':2,'header':{'name':'Foundry Arsenal | Models & Sounds','description':'Stylized block models, pixel icons, original synthesized sounds and particle effects.','uuid':rpuid,'version':[0,1,0],'min_engine_version':[1,21,120]},'modules':[{'type':'resources','uuid':uid('rp-data'),'version':[0,1,0]}]})

names={NS+':'+g['id']:g['name'] for g in GUNS}
for group in [MATERIALS,AMMO,GEAR,STATIONS]:names.update({NS+':'+k:v for k,v in group.items()})
for group in [ATTACHMENTS,GRENADES]:names.update({NS+':'+k:v['name'] for k,v in group.items()})
names.update({NS+':'+k+'_ore':v['name']+' Ore' for k,v in ORES.items()})
(BP/'scripts').mkdir()
for s in ['core.js','main.js','siege.js','siege_core.js','site_planning.js','experience.js','experience_core.js']:shutil.copy(ROOT/'src'/s,BP/'scripts'/s)
(BP/'scripts/data.js').write_text('\n'.join('export const '+key+' = '+json.dumps(val,separators=(',',':'))+';' for key,val in [('GUNS',GUNS),('ATTACHMENTS',ATTACHMENTS),('RECIPES',RECIPES),('GRENADES',GRENADES),('AMMO',AMMO),('STATIONS',STATIONS),('NAMES',names)]))
dump(ROOT/'src/catalog.json',{'guns':GUNS,'attachments':ATTACHMENTS,'ores':ORES,'station_recipes':RECIPES})

atlas={}; terrain={}; lang=[]
def register_item(id,name,components=None,stack=64,usable=False,gun=False):
 c={'minecraft:display_name':{'value':name},'minecraft:icon':id,'minecraft:max_stack_size':stack}
 if usable:
  c.update({'foundry:use':{},'minecraft:interact_button':True})
 if gun:
  c.update({'minecraft:hand_equipped':True,'minecraft:allow_off_hand':False,
   'minecraft:use_modifiers':{'use_duration':3600,'movement_modifier':.8},
   'minecraft:food':{'nutrition':0,'saturation_modifier':0,'can_always_eat':True},'minecraft:use_animation':'bow'})
 if components:c.update(components)
 dump(BP/'items'/f'{id}.json',{'format_version':'1.21.120','minecraft:item':{'description':{'identifier':NS+':'+id,'menu_category':{'category':'equipment' if gun or usable else 'items'}},'components':c}})
 atlas[id]={'textures':'textures/items/'+id};lang.append('item.'+NS+':'+id+'.name='+name)

def pal(g):
 style=g['style']; skins={'tan':('#80735a','#b4a580'),'wood':('#384046','#97603c'),'green':('#34403c','#67805b'),'silver':('#afb6b7','#4c5157')}
 a,b=skins.get(style,('#353e48',['#687c80','#778893','#6f7965','#677995'][sum(g['id'].encode())%4]));return rgb(a),rgb(b)

def gun_icon(g):
 im=Image.new('RGBA',(64,32));d=ImageDraw.Draw(im);metal,accent=pal(g);out=(14,19,26)
 cat=g['category']; pistol=cat=='Pistols';heavy=cat=='Launchers';wood=g['style']=='wood';bull=g['style']=='bullpup'
 def rect(box,c):d.rectangle(box,fill=c,outline=out)
 if pistol:
  rect((19,9,48,15),metal);rect((18,8,46,11),shade(metal,24));rect((21,14,28,25),accent);rect((29,16,36,20),metal);d.rectangle((30,16,34,18),fill=(0,0,0,0));rect((48,10,52,13),metal)
  if g['style']=='revolver':d.ellipse((25,10,35,19),fill=accent,outline=out)
 else:
  rect((17,10,39,17),metal);rect((38,11,52,15),accent);rect((50,12,61,14),shade(metal,-10));rect((21,17,26,25),accent)
  rect((4,11,16,19),accent);rect((14,12,20,16),metal)
  mx=15 if bull else 30;d.polygon([(mx,16),(mx+6,16),(mx+8,25),(mx+2,25)],fill=accent,outline=out)
  if cat=='Shotguns':rect((37,15,50,18),accent)
  if cat=='Machine guns':rect((29,17,39,26),accent);rect((44,16,46,24),metal)
  if cat in ['Marksman rifles','Sniper rifles']:
   rect((22,4,36,8),metal);rect((21,3,25,9),accent);rect((34,3,38,9),accent);rect((27,8,30,10),metal)
  if cat=='Sniper rifles':rect((50,12,63,14),metal);d.line((46,16,49,25),fill=metal,width=2)
 if heavy:
  im=Image.new('RGBA',(64,32));d=ImageDraw.Draw(im)
  d.rectangle((5,8,56,18),fill=accent,outline=out);d.rectangle((3,7,10,19),fill=metal,outline=out);d.rectangle((54,7,60,19),fill=metal,outline=out);d.rectangle((23,18,29,26),fill=metal,outline=out);d.rectangle((26,4,39,7),fill=metal,outline=out)
  if g['projectile']=='grenade':d.ellipse((25,13,40,25),fill=shade(accent,-15),outline=out)
 # Distinct vent counts, receiver marks and finish for each weapon.
 for i in range(2+sum(g['id'].encode())%5):d.line((38+i*2,10,38+i*2,13),fill=shade(metal,-22))
 d.point((25,10),fill=(224,187,87));return im

def gun_geometry(g):
 cat=g['category'];metal,accent=pal(g);pistol=cat=='Pistols';heavy=cat=='Launchers';bull=g['style']=='bullpup'
 cubes=[]
 # Cuboids use a small material swatch on each face, avoiding stretched baked detail.
 def cube(o,s,t=0,rotation=None):
  uv={face:{'uv':[t*8,0],'uv_size':[8,8]} for face in ['north','south','east','west','up','down']}
  v={'origin':o,'size':s,'uv':uv}
  if rotation:v.update(rotation=rotation,pivot=list(o))
  cubes.append(v)
 variation=(sum(g['id'].encode())%5)*.3
 if pistol:
  cube([-1,0,-6],[2,2,8+variation]);cube([-1,2,-6],[2,.6,8+variation],1)
  cube([-.8,-5,0],[1.6,5,2.3],1,[-12,0,0]);cube([-.4,-1.9,-2.5],[.8,.5,3]);cube([-.4,-1.8,-2.5],[.8,1.8,.5]);cube([-.5,2.5,-5],[1,.4,.6],2)
  if g['style']=='revolver':cube([-1.5,-.2,-1.5],[3,2.6,3],1)
 else:
  long=cat in ['Sniper rifles','Marksman rifles'];barrel=13+variation+(6 if long else 0)
  cube([-1.4,0,-5],[2.8,3,10]);cube([-1.2,.3,-barrel],[2.4,2.3,barrel-5],1)
  cube([-.55,.9,-barrel-5],[1.1,1.1,6]);cube([-1,0,5],[2,2,6],1);cube([-1,-2,10],[2,4,1.5],1)
  cube([-.8,-5,1],[1.6,5,2],1,[-15,0,0]);mz=4 if bull else -3;cube([-1,-5,mz],[2,5,3],1,[8,0,0])
  cube([-.45,-1.9,-1],[.9,.5,3]);cube([-.45,-1.8,-1],[.9,1.8,.5])
  cube([-.8,3,-4],[1.6,.5,8],2)
  for n in range(5):cube([-1.3,.8,-7-n*1.6],[2.6,.7,.45],0)
  if cat=='Machine guns':cube([-2,-5,-4],[4,5,5],1);cube([-2,-7,-12],[.7,7,.7]);cube([1.3,-7,-12],[.7,7,.7])
  if cat=='Shotguns':cube([-.7,-.2,-barrel],[1.4,1,barrel-5],0)
  if long:
   cube([-.5,3.4,-2],[1,1.3,1]);cube([-1,4.6,-7],[2,2,9]);cube([-1.4,4.2,-8],[2.8,2.8,1.5],1);cube([-1.3,4.3,1],[2.6,2.6,1.5],1);cube([-.9,4.7,-8.05],[1.8,1.8,.1],3)
 if heavy:
  cubes.clear();cube([-2,0,-17],[4,4,27],1);cube([-2.5,-.5,-18],[5,5,2]);cube([-2.5,-.5,9],[5,5,2]);cube([-1,-5,1],[2,5,2]);cube([-.5,4,-4],[1,3,1]);cube([-1,7,-5],[2,1,4]);
  if g['projectile']=='grenade':cube([-3,-3,-3],[6,5,5])
 for c in cubes:
  c['origin'][1]+=24
  if 'pivot' in c:c['pivot'][1]+=24
 return {'format_version':'1.16.0','minecraft:geometry':[{'description':{'identifier':'geometry.foundry.'+g['id'],'texture_width':32,'texture_height':8,'visible_bounds_width':5,'visible_bounds_height':4,'visible_bounds_offset':[0,1,0]},'bones':[{'name':'root','pivot':[0,24,0],'binding':'q.item_slot_to_bone_name(context.item_slot)','cubes':cubes}]}]}

for g in GUNS:
 id=g['id'];register_item(id,g['name'],stack=1,usable=True,gun=True)
 saveim(gun_icon(g),RP/'textures/items'/f'{id}.png')
 dump(RP/'models/entity'/f'{id}.geo.json',gun_geometry(g))
 tex=Image.new('RGB',(32,8));td=ImageDraw.Draw(tex);a,b=pal(g)
 for i,color in enumerate([a,b,shade(a,45),(73,168,183)]):
  td.rectangle((i*8,0,i*8+7,7),fill=color);td.line((i*8,0,i*8+7,0),fill=shade(color,24));td.line((i*8,7,i*8+7,7),fill=shade(color,-24))
 saveim(tex,RP/'textures/models'/f'{id}.png')
 dump(RP/'attachables'/f'{id}.json',{'format_version':'1.20.30','minecraft:attachable':{'description':{'identifier':NS+':'+id,'materials':{'default':'entity_alphatest'},'textures':{'default':'textures/models/'+id},'geometry':{'default':'geometry.foundry.'+id},'animations':{'first':'animation.foundry.first','third':'animation.foundry.third'},'scripts':{'animate':[{'first':'context.is_first_person'},{'third':'!context.is_first_person'}]},'render_controllers':['controller.render.foundry.gun']}}})
dump(RP/'render_controllers/guns.json',{'format_version':'1.8.0','render_controllers':{'controller.render.foundry.gun':{'geometry':'Geometry.default','materials':[{'*':'Material.default'}],'textures':['Texture.default']}}})
dump(RP/'animations/guns.animation.json',{'format_version':'1.8.0','animations':{
 'animation.foundry.first':{'loop':True,'bones':{'root':{'position':[0,-24,0],'rotation':[90,0,0],'scale':.65}}},
 'animation.foundry.third':{'loop':True,'bones':{'root':{'position':[0,-24,0],'rotation':[90,0,0],'scale':.65}}},
}})

def basic_icon(id,name):
 im=Image.new('RGBA',(32,32));d=ImageDraw.Draw(im);seed=int(hashlib.sha256(id.encode()).hexdigest()[:8],16);r=random.Random(seed);base=(95+r.randrange(50),105+r.randrange(50),110+r.randrange(50));dark=(18,25,32)
 if id in AMMO:
  for x in [7,14,21]:d.rectangle((x,9,x+4,25),fill=(174,127,55),outline=dark);d.polygon([(x,9),(x+2,4),(x+4,9)],fill=(206,193,152));d.line((x+1,12,x+1,23),fill=(232,198,94))
 elif id in ATTACHMENTS:
  a=ATTACHMENTS[id]
  if a['slot']=='optic':d.rectangle((5,12,26,20),fill=base,outline=dark);d.ellipse((3,9,13,23),fill=dark,outline=base);d.ellipse((5,11,11,21),fill=(69,173,195));d.rectangle((14,21,18,27),fill=base)
  elif a['slot']=='magazine':d.polygon([(10,4),(22,4),(24,25),(13,28)],fill=base,outline=dark);[d.line((13,y,21,y),fill=dark) for y in [9,14,19]]
  elif a['slot']=='payload':
   col={'fire':'#ef9844','ice':'#77dbea','shock':'#b8a0ff','poison':'#91ce69','piercing':'#dedfe5'}[a['effect']];d.polygon([(16,3),(26,11),(23,25),(10,28),(5,15)],fill=rgb(col),outline=dark);d.line((16,5,11,24),fill='white',width=2)
  else:d.rectangle((7,9,25,21),fill=base,outline=dark);d.rectangle((12,19,18,27),fill=shade(base,-30),outline=dark);d.line((9,11,23,11),fill=shade(base,45))
 elif id in GRENADES:
  colors={'frag':'#728259','smoke':'#b3b8b5','flash':'#d9c36e','fire':'#d77c46','ice':'#6bc1d8','shock':'#9376dc'};c=rgb(colors[GRENADES[id]['effect']]);d.ellipse((7,10,24,28),fill=c,outline=dark);d.rectangle((11,5,20,13),fill=base,outline=dark);d.line((20,6,25,20),fill=(198,199,176),width=3);d.arc((7,1,17,10),0,330,fill=base,width=2)
 elif id=='field_manual':d.rectangle((5,3,26,28),fill=(32,64,76),outline=dark);d.rectangle((8,5,10,26),fill=(77,124,131));d.text((13,10),'F',font=font(14,True),fill=(239,207,123))
 elif id=='medkit':d.rectangle((5,7,27,26),fill=(220,215,196),outline=dark);d.rectangle((13,10,18,23),fill=(189,65,68));d.rectangle((9,14,22,19),fill=(189,65,68))
 elif id=='night_vision_goggles':d.rectangle((4,12,28,21),fill=dark);d.ellipse((4,9,15,23),fill=(43,131,91),outline=base);d.ellipse((17,9,28,23),fill=(43,131,91),outline=base)
 elif id=='tactical_vest':d.polygon([(6,4),(12,4),(13,10),(19,10),(20,4),(26,4),(25,28),(7,28)],fill=(73,87,79),outline=dark);d.rectangle((10,14,15,23),fill=(108,119,98));d.rectangle((18,14,23,23),fill=(108,119,98))
 elif 'ingot' in id or 'alloy' in id or 'plate' in id:
  key=id.split('_')[0];base=rgb(ORES[key]['color']) if key in ORES else base;d.polygon([(4,14),(11,7),(25,7),(29,20),(21,25),(5,23)],fill=base,outline=dark);d.line((5,14,24,14,28,20),fill=shade(base,35),width=2)
 elif 'raw_' in id or 'dust' in id or 'crystal' in id:
  key=id.replace('raw_','').split('_')[0];base=rgb(ORES[key]['color']) if key in ORES else base
  d.polygon([(4,22),(8,11),(14,13),(17,4),(25,10),(27,25),(13,28)],fill=base,outline=dark);d.line((17,5,20,17,26,23),fill=shade(base,35),width=2)
 else:d.rounded_rectangle((5,7,27,25),3,fill=base,outline=dark);d.rectangle((10,11,21,20),fill=shade(base,-40));d.line((11,13,19,13),fill=(219,180,83),width=2)
 return im

for group in [MATERIALS,AMMO,ATTACHMENTS,GRENADES,GEAR]:
 for id,value in group.items():
  name=value['name'] if isinstance(value,dict) else value;extra={};stack=64
  if id=='night_vision_goggles':extra={'minecraft:wearable':{'slot':'slot.armor.head','protection':2},'minecraft:durability':{'max_durability':500}};stack=1
  if id=='tactical_vest':extra={'minecraft:wearable':{'slot':'slot.armor.chest','protection':7},'minecraft:durability':{'max_durability':900}};stack=1
  usable=id in GRENADES or id in ['field_manual','maintenance_kit','medkit','targeting_pad','laser_designator']
  if id=='field_manual':stack=1
  register_item(id,name,extra,stack,usable);saveim(basic_icon(id,name),RP/'textures/items'/f'{id}.png')

def block(id,name,texture,station=False):
 c={'minecraft:geometry':'minecraft:geometry.full_block','minecraft:material_instances':{'*':{'texture':texture,'render_method':'opaque'}},'minecraft:destructible_by_mining':{'seconds_to_destroy':3.5 if not station else 2},'minecraft:destructible_by_explosion':{'explosion_resistance':8},'minecraft:map_color':'#66747d','minecraft:loot':'loot_tables/blocks/'+id+'.json'}
 if station:c['foundry:station']={}
 dump(BP/'blocks'/f'{id}.json',{'format_version':'1.21.120','minecraft:block':{'description':{'identifier':NS+':'+id,'menu_category':{'category':'construction'}},'components':c}})
 lang.append('tile.'+NS+':'+id+'.name='+name);terrain[texture]={'textures':'textures/blocks/'+texture}
 atlas[id]={'textures':'textures/items/'+id}

for key,o in ORES.items():
 id=key+'_ore';block(id,o['name']+' Ore',id)
 im=Image.new('RGB',(16,16));d=ImageDraw.Draw(im);r=random.Random(key)
 for y in range(16):
  for x in range(16):v=r.randrange(84,130);d.point((x,y),fill=(v,v+1,v+3))
 for n in range(12):x,y=r.randrange(1,14),r.randrange(1,14);c=rgb(o['color']);d.rectangle((x,y,x+1,y+1),fill=c);d.point((x,y),fill=shade(c,35))
 saveim(im,RP/'textures/blocks'/f'{id}.png');saveim(im.convert('RGBA'),RP/'textures/items'/f'{id}.png')
 drop='raw_'+key if key in ['zinc','cobalt','titanium','tungsten'] else key+('_dust' if key=='sulfur' else '_crystal')
 dump(BP/'loot_tables/blocks'/f'{id}.json',{'pools':[{'rolls':1,'entries':[{'type':'item','name':NS+':'+drop,'weight':1}]}]})
 if drop.startswith('raw_'):
  dump(BP/'recipes'/f'smelt_{key}.json',{'format_version':'1.20.10','minecraft:recipe_furnace':{'description':{'identifier':NS+':smelt_'+key},'tags':['furnace','blast_furnace'],'input':NS+':'+drop,'output':NS+':'+key+'_ingot'}})
 dump(BP/'features'/f'{key}_vein.json',{'format_version':'1.13.0','minecraft:ore_feature':{'description':{'identifier':NS+':'+key+'_vein'},'count':o['vein'],'replace_rules':[{'places_block':NS+':'+id,'may_replace':['minecraft:stone','minecraft:deepslate','minecraft:granite','minecraft:diorite','minecraft:andesite']} ]}})
 dump(BP/'feature_rules'/f'{key}_rule.json',{'format_version':'1.13.0','minecraft:feature_rules':{'description':{'identifier':NS+':'+key+'_rule','places_feature':NS+':'+key+'_vein'},'conditions':{'placement_pass':'underground_pass','minecraft:biome_filter':[{'test':'has_biome_tag','operator':'==','value':'overworld'}]},'distribution':{'iterations':o['tries'],'coordinate_eval_order':'zyx','x':{'distribution':'uniform','extent':[0,16]},'y':{'distribution':'uniform','extent':o['y']},'z':{'distribution':'uniform','extent':[0,16]}}}})

colors={'alloy_forge':'#dc9459','gunsmith_bench':'#65bfc0','ammo_press':'#d4bc76','attachment_bench':'#a790cf','missile_fabricator':'#d0db7e'}
for id,name in STATIONS.items():
 block(id,name,id,True);im=Image.new('RGB',(16,16),(44,53,61));d=ImageDraw.Draw(im);c=rgb(colors[id]);d.rectangle((0,0,15,2),fill=c);d.rectangle((2,5,13,12),fill=(19,26,33));d.rectangle((3,6,12,7),fill=c);d.line((4,10,11,10),fill=(113,130,137));d.rectangle((0,14,15,15),fill=(24,30,39));saveim(im,RP/'textures/blocks'/f'{id}.png');saveim(im.convert('RGBA'),RP/'textures/items'/f'{id}.png')
 dump(BP/'loot_tables/blocks'/f'{id}.json',{'pools':[{'rolls':1,'entries':[{'type':'item','name':NS+':'+id,'weight':1}]}]})
def shaped(id,pattern,key,result=None,count=1):
 dump(BP/'recipes'/f'{id}.json',{'format_version':'1.20.10','minecraft:recipe_shaped':{'description':{'identifier':NS+':'+id},'tags':['crafting_table'],'pattern':pattern,'key':{k:{'item':v} for k,v in key.items()},'result':{'item':result or NS+':'+id,'count':count}}})
shaped('alloy_forge',['III','IFI','CCC'],{'I':'minecraft:iron_ingot','F':'minecraft:furnace','C':'minecraft:cobblestone'})
shaped('gunsmith_bench',['III','CTC','PPP'],{'I':'minecraft:iron_ingot','C':'minecraft:copper_ingot','T':'minecraft:crafting_table','P':'minecraft:oak_planks'})
shaped('ammo_press',['III','CRC','SSS'],{'I':'minecraft:iron_ingot','C':'minecraft:copper_ingot','R':'minecraft:redstone','S':'minecraft:stone'})
shaped('attachment_bench',['GIG','CTC','PPP'],{'G':'minecraft:glass','I':'minecraft:iron_ingot','C':'minecraft:copper_ingot','T':'minecraft:crafting_table','P':'minecraft:oak_planks'})
shaped('field_manual',['PC'],{'P':'minecraft:paper','C':'minecraft:copper_ingot'})
shaped('missile_fabricator',['DRD','OFO','III'],{'D':'minecraft:diamond','R':'minecraft:redstone_block','O':'minecraft:obsidian','F':'minecraft:furnace','I':'minecraft:iron_block'})

dump(RP/'textures/item_texture.json',{'resource_pack_name':'foundry_arsenal','texture_name':'atlas.items','texture_data':atlas})
dump(RP/'textures/terrain_texture.json',{'resource_pack_name':'foundry_arsenal','texture_name':'atlas.terrain','padding':8,'num_mip_levels':4,'texture_data':terrain})
dump(RP/'blocks.json',{'format_version':[1,1,0],**{NS+':'+k+'_ore':{'sound':'stone'} for k in ORES},**{NS+':'+k:{'sound':'metal'} for k in STATIONS}})
dump(RP/'texts/languages.json',['en_US','en_GB']);(RP/'texts/en_US.lang').write_text('\n'.join(lang)+'\n');shutil.copy(RP/'texts/en_US.lang',RP/'texts/en_GB.lang')

# Small custom projectile model, moved by the script's swept collision simulation.
dump(BP/'entities/projectile_marker.json',{'format_version':'1.21.0','minecraft:entity':{'description':{'identifier':'foundry:projectile_marker','is_spawnable':False,'is_summonable':True},'components':{'minecraft:type_family':{'family':['foundry_projectile']},'minecraft:collision_box':{'width':.1,'height':.1},'minecraft:physics':{'has_gravity':False,'has_collision':False},'minecraft:pushable':{'is_pushable':False,'is_pushable_by_piston':False},'minecraft:timer':{'looping':False,'time':8,'time_down_event':{'event':'foundry:expire','target':'self'}}},'component_groups':{'foundry:remove':{'minecraft:instant_despawn':{}}},'events':{'foundry:expire':{'add':{'component_groups':['foundry:remove']}}}}})
dump(RP/'entity/projectile_marker.entity.json',{'format_version':'1.10.0','minecraft:client_entity':{'description':{'identifier':'foundry:projectile_marker','materials':{'default':'entity_alphatest'},'textures':{'default':'textures/entity/projectile'},'geometry':{'default':'geometry.foundry.projectile'},'render_controllers':['controller.render.foundry.gun']}}})
dump(RP/'models/entity/projectile.geo.json',{'format_version':'1.12.0','minecraft:geometry':[{'description':{'identifier':'geometry.foundry.projectile','texture_width':16,'texture_height':16,'visible_bounds_width':2,'visible_bounds_height':2,'visible_bounds_offset':[0,0,0]},'bones':[{'name':'body','pivot':[0,0,0],'cubes':[{'origin':[-1,-1,-1],'size':[2,2,2],'uv':[0,0]}]}]}]})
saveim(Image.new('RGBA',(16,16),(155,157,106,255)),RP/'textures/entity/projectile.png')

particle_colors={'tracer':[1,.77,.32,1],'muzzle':[1,.92,.53,1],'impact':[.8,.83,.87,1],'frost':[.42,.9,1,1],'arc':[.72,.5,1,1],'ember':[1,.36,.1,1],'blast':[1,.65,.25,1],'smoke':[.47,.49,.53,.75],'laser':[1,.12,.12,1]}
saveim(Image.new('RGBA',(8,8),'white'),RP/'textures/particle/dot.png')
for id,col in particle_colors.items():
 size=.6 if id=='smoke' else .32 if id=='blast' else .035 if id=='laser' else .065
 lifetime=.9 if id=='smoke' else .22 if id in ['blast','muzzle'] else .12
 dump(RP/'particles'/f'{id}.json',{'format_version':'1.10.0','particle_effect':{'description':{'identifier':'foundry:'+id,'basic_render_parameters':{'material':'particles_blend','texture':'textures/particle/dot'}},'components':{'minecraft:emitter_rate_instant':{'num_particles':1},'minecraft:emitter_lifetime_once':{'active_time':.01},'minecraft:emitter_shape_point':{},'minecraft:particle_lifetime_expression':{'max_lifetime':lifetime},'minecraft:particle_appearance_billboard':{'size':[size,size],'facing_camera_mode':'lookat_xyz','uv':{'texture_width':8,'texture_height':8,'uv':[0,0],'uv_size':[8,8]}},'minecraft:particle_appearance_tinting':{'color':col},'minecraft:particle_motion_dynamic':{'linear_acceleration':[0,.35 if id=='smoke' else 0,0],'linear_drag_coefficient':0},'minecraft:particle_initial_speed':0}}})

# Original synthesized game effects; no third-party recordings.
sound_defs={};rate=22050
for id,dur,freq in [('shot',.20,125),('heavy',.38,65),('shotgun',.30,82),('suppressed',.12,230),('launch',.48,50),('reload',.42,850)]:
 r=random.Random(id);samples=[]
 for n in range(int(rate*dur)):
  t=n/rate;noise=r.uniform(-1,1)
  if id=='reload':envelope=sum(math.exp(-max(0,t-k)*80) if t>=k else 0 for k in [0,.18,.33]);val=(noise*.45+math.sin(2*math.pi*freq*t)*.2)*envelope
  else:envelope=math.exp(-t/(dur/5));val=(noise*.6+math.sin(2*math.pi*(freq*t-70*t*t))*.4)*envelope
  samples.append(struct.pack('<h',int(max(-.95,min(.95,val)) * 24000)))
 wav=BUILD/(id+'.wav')
 with wave.open(str(wav),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(rate);w.writeframes(b''.join(samples))
 ogg=RP/'sounds/foundry'/f'{id}.ogg';ogg.parent.mkdir(parents=True,exist_ok=True)
 subprocess.run(['ffmpeg','-loglevel','error','-y','-i',str(wav),'-c:a','libvorbis',str(ogg)],check=True)
 wav.unlink();sound_defs['foundry.'+id]={'category':'player','sounds':[{'name':'sounds/foundry/'+id,'stream':False}]}
dump(RP/'sounds/sound_definitions.json',{'format_version':'1.14.0','sound_definitions':sound_defs})

icon=Image.new('RGB',(256,256),'#101d28');d=ImageDraw.Draw(icon);d.rounded_rectangle((15,15,241,241),24,outline='#cfb572',width=5);d.text((38,38),'FOUNDRY',font=font(31,True),fill='#f1ecd9');d.text((39,193),'ARSENAL / 60',font=font(21,True),fill='#69c1c7');weapon=gun_icon(GUNS[43]).resize((224,112),Image.Resampling.NEAREST);icon.paste(weapon,(16,76),weapon)
saveim(icon,BP/'pack_icon.png');saveim(icon,RP/'pack_icon.png')

# Operator-only demo function: explicit, optional, and never runs automatically.
(BP/'functions/foundry').mkdir(parents=True,exist_ok=True)
demo=['# Run manually: /function foundry/demo. Requires command permission.',
 'give @s foundry:glock_17','give @s foundry:h_k_mp5','give @s foundry:ak_47','give @s foundry:accuracy_international_awm','give @s foundry:rpg_7',
 'give @s foundry:light_rounds 128','give @s foundry:rifle_rounds 128','give @s foundry:precision_rounds 64','give @s foundry:rocket 16',
 'give @s foundry:field_manual','give @s foundry:maintenance_kit 4','give @s foundry:scope_4x','give @s foundry:extended_mag','give @s foundry:cryo_core','give @s foundry:frag_grenade 8']
(BP/'functions/foundry/demo.mcfunction').write_text('\n'.join(demo)+'\n')

def make_pack():
 for pack,name in [(BP,'Foundry_Arsenal_Behavior.mcpack'),(RP,'Foundry_Arsenal_Resources.mcpack')]:
  with zipfile.ZipFile(BUILD/name,'w',zipfile.ZIP_DEFLATED) as z:
   for p in sorted(pack.rglob('*')):
    if p.is_file():z.write(p,p.relative_to(pack))
 with zipfile.ZipFile(OUT/'Foundry_Arsenal_60.mcaddon','w',zipfile.ZIP_DEFLATED) as z:
  for name in ['Foundry_Arsenal_Behavior.mcpack','Foundry_Arsenal_Resources.mcpack']:z.write(BUILD/name,name)

def make_guide():
 css='''body{margin:0;background:#101a24;color:#dbe5e8;font:16px/1.55 system-ui,sans-serif}main{max-width:1100px;margin:auto;padding:46px 24px}h1{font-size:56px;line-height:1.05;letter-spacing:-2px;margin:12px 0}h2{font-size:27px;color:#78d1d4;margin-top:42px}h3{color:#ead6a0}p{max-width:850px}.eyebrow{letter-spacing:4px;color:#d6bb77;font-size:13px;font-weight:700}.lead{font-size:21px;color:#a9bdc8}.note{padding:18px 22px;background:#25323a;border-left:4px solid #d6bb77;border-radius:4px}code{color:#e6c981}table{border-collapse:collapse;width:100%;font-size:14px}th{text-align:left;background:#22323e;color:#a7dfe1}th,td{padding:10px 12px;border-bottom:1px solid #334450}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px}.card{background:#1c2b37;padding:18px;border-radius:10px}.weapon img{image-rendering:pixelated;width:128px;height:64px;object-fit:contain}.weapon{display:flex;align-items:center;gap:12px}.muted{color:#9baeba}summary{cursor:pointer;font-size:22px;padding:15px;background:#1d2f3b}details{margin:10px 0}input{width:95%;padding:13px;background:#203440;border:1px solid #4f737a;border-radius:7px;color:white;font-size:16px}@media print{body{background:white;color:#182832}main{padding:0}details{break-inside:avoid}.note,.card,summary,th{background:#edf2f3}h1{font-size:35px}h2{color:#17636d}}'''
 import base64
 def embedded(path):return 'data:image/png;base64,'+base64.b64encode(path.read_bytes()).decode()
 body=f'''<div class="eyebrow">MINECRAFT BEDROCK • DEVELOPMENT BUILD 0.1.0</div><h1>Foundry Arsenal</h1><p class="lead">60 named weapons. Build your equipment from the ground up.</p><div class="note"><b>Validation status:</b> Pack structure, references, gameplay math and script types are checked automatically. This build has <b>not been imported or play-tested in Minecraft</b>. First-person model alignment, held-fire input, station forms and natural ore placement require a client test. Target: Windows Bedrock 1.21.120 or newer, with stable Script API 2.3.0. No native mod loader.</div>
 <h2>Install & start</h2><ol><li>Open <b>Foundry_Arsenal_60.mcaddon</b> with Minecraft for Windows. Both packs should import.</li><li>Create a <b>new test world</b>. Activate <b>Foundry Arsenal | 60 Weapons</b> under Behavior Packs. Verify the matching Models & Sounds pack is active under Resource Packs.</li><li>No experimental switches are intentionally required. Use a current retail Bedrock version. Cheats are only needed for the optional demo command.</li><li>Enter the world. A Field Manual is given once per player. If needed, craft one from paper + copper ingot.</li><li>For a quick creative test, use the Field Manual’s weapon catalogue to receive weapons and ammunition. Use an empty gun to reload it.</li><li>Optional operator command: <code>/function foundry/demo</code> supplies five sample weapons, ammunition, attachments and grenades.</li></ol>
 <h2>Controls</h2><table><tr><th>Action</th><th>Control</th></tr><tr><td>Fire</td><td>Right-click / Use. Hold for automatic weapons; tap for semi-auto and three-round burst.</td></tr><tr><td>Aim / zoom</td><td>Hold Sneak. Installed scopes narrow the field of view.</td></tr><tr><td>Reload when empty</td><td>Use the empty weapon; keep it selected until reload finishes.</td></tr><tr><td>Reload early / unload / repair</td><td>Use the Field Manual or Maintenance Kit → equipment → select weapon.</td></tr><tr><td>Fit attachments</td><td>Carry the attachment; select weapon through equipment → Install. One per slot. Unload before swapping magazine attachments.</td></tr><tr><td>Throw grenade</td><td>Use the grenade. Timed grenades bounce; launcher rounds detonate on impact.</td></tr><tr><td>Operate station</td><td>Place it, then use it with an empty hand. Choose a recipe and confirm.</td></tr><tr><td>Night vision / armor</td><td>Equip goggles in helmet slot or vest in chest slot.</td></tr></table>
 <h2>Survival progression</h2><p>Mine resources → smelt raw metals → refine modules at the Alloy Forge → assemble a weapon at the Gunsmith Bench → manufacture ammunition at the Ammo Press → fit upgrades from the Attachment Bench. Every recipe below is fictional game crafting.</p><table><tr><th>New deposit</th><th>Height</th><th>Drop / processing</th></tr>'''
 for id,o in ORES.items():body+=f'<tr><td>{o["name"]}</td><td>Y {o["y"][0]} to {o["y"][1]}</td><td>{"Raw metal → furnace or blast furnace → ingot" if id in ["zinc","cobalt","titanium","tungsten"] else "Dust" if id=="sulfur" else "Crystal"}</td></tr>'
 body+='</table><p class="muted">Deposits only generate in new Overworld chunks. Existing explored chunks are not modified. This build uses simple ore drops without Fortune/Silk Touch specialization.</p><h2>Craft the four stations</h2><p>Use the normal 3×3 crafting table. Rows are top to bottom; oak planks are required for the two benches.</p><div class="grid">'
 stationRows={
 'Alloy Forge':['Iron · Iron · Iron','Iron · Furnace · Iron','Cobblestone · Cobblestone · Cobblestone'],
 'Gunsmith Bench':['Iron · Iron · Iron','Copper · Crafting table · Copper','Oak planks · Oak planks · Oak planks'],
 'Ammo Press':['Iron · Iron · Iron','Copper · Redstone · Copper','Stone · Stone · Stone'],
 'Attachment Bench':['Glass · Iron · Glass','Copper · Crafting table · Copper','Oak planks · Oak planks · Oak planks']}
 for name,rows in stationRows.items():body+='<div class="card"><h3>'+name+'</h3>'+''.join('<p>'+r+'</p>' for r in rows)+'</div>'
 body+='</div><h2>Attachments that change gameplay</h2><table><tr><th>Attachment</th><th>Slot</th><th>Effect</th></tr>'
 for id,a in ATTACHMENTS.items():
  effects=[]
  for prop,desc in [('accuracy','spread ×'),('range','range ×'),('reload','reload time ×'),('capacity','magazine size ×'),('damage','damage ×')]:
   if prop in a:effects.append(desc+str(a[prop]))
  if 'fov' in a:effects.append('aim FOV '+str(a['fov'])+'°')
  if a.get('effect'):effects.append({'fire':'ignites targets','ice':'slows targets','shock':'weakens and chains to one nearby target','poison':'poisons targets','piercing':'hits up to three entities (does not penetrate walls)'}[a['effect']])
  if a.get('quiet'):effects.append('quieter firing sound')
  if a.get('night'):effects.append('night vision while aiming')
  if a.get('laser'):effects.append('visible laser dot while aiming')
  if a.get('crouchOnly'):effects.append('accuracy bonus only while aiming')
  body+='<tr><td>'+a['name']+'</td><td>'+a['slot']+'</td><td>'+'; '.join(effects)+'</td></tr>'
 body+='</table><p class="muted">Pistols do not accept stocks or underbarrel attachments. Revolvers do not accept magazine attachments. Launchers accept optics and stocks only. Chokes fit shotguns only. Attachments are functional inventory upgrades; the 3D models do not show each fitted attachment.</p><h2>Weapon catalogue</h2><p>Damage is measured in Minecraft health points (2 points = 1 heart), before distance and headshot adjustments. These are balanced game values, not claims about real-world performance.</p><input id="search" placeholder="Find Glock, H&amp;K, AK, rocket…" aria-label="Search weapons">'
 for cat in ROWS:
  body+='<details open><summary>'+cat+' · '+str(len([g for g in GUNS if g['category']==cat]))+'</summary><table><tr><th>Weapon</th><th>Damage</th><th>Magazine</th><th>Ammo</th><th>Range</th></tr>'
  for g in [g for g in GUNS if g['category']==cat]:
   body+=f'<tr class="gunrow" data-name="{html.escape(g["name"].lower())}"><td class="weapon"><img src="{embedded(RP/"textures/items"/(g["id"]+".png"))}" alt=""><span>{html.escape(g["name"])}<br><small class="muted">{g["mode"].upper()}</small></span></td><td>{g["damage"]}{" × "+str(g["pellets"]) if g["pellets"]>1 else ""}</td><td>{g["capacity"]}</td><td>{AMMO[g["ammo"]]}</td><td>{g["range"]} blocks</td></tr>'
  body+='</table></details>'
 body+='<h2>All station recipes</h2><p>Stations use the native crafting grid and recipe book. Quantities below are raw material totals; pack large quantities at a Foundry station before assembly.</p>'
 for station in STATIONS:
  body+='<details><summary>'+STATIONS[station]+'</summary><table><tr><th>Output</th><th>Ingredients</th></tr>'
  for r in RECIPES:
   if r['station']!=station:continue
   ingredients=', '.join(str(n)+' × '+names.get(k,k.replace('minecraft:','').replace('_',' ')) for k,n in r['inputs'].items())
   body+='<tr><td>'+html.escape(r['name'])+'</td><td>'+html.escape(ingredients)+'</td></tr>'
  body+='</table></details>'
 body+='''<h2>Grenades & special effects</h2><p>Fragmentation: splash damage. Smoke: a smoke cloud and temporary blindness inside it. Flash: line-of-sight blindness and a short white fade for players. Incendiary: burning cloud. Cryo: slowing cloud. Shock: damage, weakness and chaining. Explosions do not break terrain in this version. Rockets travel visibly; firearm bullets use immediate raycasts.</p>
 <h2>What this build does not claim</h2><ul><li>No completed in-game compatibility or multiplayer play-test.</li><li>Models are stylized cuboid interpretations with shared class construction and shared hold animations, not exact branded replicas. No custom per-weapon reload animation.</li><li>No native R-key binding, working bipod deployment animation or visible attachment swaps.</li><li>No real ballistic simulation, armor penetration simulation, homing launchers or destructive explosions.</li><li>Goggles and vest have functional equipment effects and icons; custom worn armor meshes are not included.</li></ul>
 <h2>If something fails</h2><p>Verify both packs are enabled and update Minecraft. For detailed errors, enable the content log in Minecraft's Creator settings. Send the version number and the first Foundry-related content-log error. An empty gun needs matching rounds and one Use action to reload. Close chat and release Use if a menu does not open. For new ores, start a new world or travel to unexplored chunks.</p>
 <h2>Build & source</h2><p>The companion source ZIP contains the generated behavior/resource packs, editable catalog, generator, gameplay scripts and automated tests. Rebuild with Python 3 + Pillow and FFmpeg; run the Node test suite as described in README.md. Weapon names identify the inspirations; this is an unofficial fan-made Minecraft add-on, unaffiliated with Mojang or the named manufacturers.</p>
 <h2>Technical references</h2><ul><li><a href="https://learn.microsoft.com/en-us/minecraft/creator/documents/scripting/custom-components">Microsoft: Custom Components v2</a></li><li><a href="https://learn.microsoft.com/en-us/minecraft/creator/scriptapi/minecraft/server/itemcustomcomponent">Microsoft: Item events</a></li><li><a href="https://learn.microsoft.com/en-us/minecraft/creator/documents/attachables">Microsoft: Attachables</a></li><li><a href="https://learn.microsoft.com/en-us/minecraft/creator/reference/content/featuresreference/examples/features/minecraft_ore_feature">Microsoft: Ore features</a></li></ul>'''
 page='<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Foundry Arsenal — Field Guide</title><style>'+css+'</style><main>'+body+'</main><script>document.getElementById("search").addEventListener("input",e=>{let q=e.target.value.toLowerCase();document.querySelectorAll(".gunrow").forEach(r=>r.hidden=!r.dataset.name.includes(q));if(q)document.querySelectorAll("details").forEach(d=>{if(d.querySelector(".gunrow"))d.open=true})});</script></html>'
 (OUT/'Foundry_Arsenal_Field_Guide.html').write_text(page)

def preview():
 im=Image.new('RGB',(1400,1000),'#111c26');d=ImageDraw.Draw(im)
 d.text((55,38),'FOUNDRY ARSENAL',font=font(48,True),fill='#f1e8d0');d.text((57,104),'60 WEAPONS   /   24 ATTACHMENTS   /   6 ORES   /   4 STATIONS',font=font(20),fill='#7ed0d3')
 chosen=[GUNS[i] for i in list(range(0,60,3))]
 for i,g in enumerate(chosen):
  x=50+(i%4)*335;y=160+(i//4)*150;d.rounded_rectangle((x,y,x+318,y+134),10,fill='#1f303c')
  icon=gun_icon(g).resize((256,128),Image.Resampling.NEAREST);im.paste(icon,(x+25,y-10),icon)
  d.text((x+15,y+103),g['name'],font=font(16),fill='#dce7e9')
 d.text((55,942),'GENERATED ITEM ART • DEVELOPMENT BUILD • NOT AN IN-GAME SCREENSHOT',font=font(17),fill='#96aab6')
 saveim(im,OUT/'Foundry_Arsenal_Preview.png')

from siege_build import expand, expand_guide
expand(BP,RP,OUT,ROOT)
from polish_build import polish, polish_guide
polish(BP,RP,OUT,ROOT)
from revision_build import revise, revise_guide
revise(BP,RP,OUT,ROOT)
from v5_build import upgrade, guide_v5
upgrade(BP,RP,OUT,ROOT)
from v6_build import upgrade_v6,guide_v6
upgrade_v6(BP,RP)
from v7_build import upgrade_v7,guide_v7
upgrade_v7(BP,RP)
make_pack();make_guide();preview();expand_guide(OUT);polish_guide(OUT);revise_guide(OUT,ROOT);guide_v5(OUT,ROOT);guide_v6(OUT,ROOT);guide_v7(OUT,ROOT)
from render_review import main as render_review
render_review()
print(json.dumps({'guns':len(GUNS),'attachments':len(ATTACHMENTS),'ores':len(ORES),'stations':len(STATIONS),'recipes':len(RECIPES),'items':len(atlas),'output':str(OUT)}))
