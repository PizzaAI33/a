// Optional goals and feedback use Minecraft game values only.
const integer=(value,max=1000000)=>Math.min(max,Math.max(0,Math.floor(Number(value)||0)));
export const HOSTILES=new Set(['zombie','husk','drowned','skeleton','stray','bogged','wither_skeleton','creeper','spider','cave_spider','pillager','vindicator','evoker','witch','phantom','slime','magma_cube','blaze','ghast','breeze','enderman'].map(id=>'minecraft:'+id));
export const STATION_IDS=['alloy_forge','gunsmith_bench','ammo_press','attachment_bench','missile_fabricator'].map(id=>'foundry:'+id);
export const TASKS=[
 {id:'reload',name:'Ready for the field',hint:'Complete a reload with real ammunition.',key:'reloads',goal:1,rewards:{'foundry:maintenance_kit':1}},
 {id:'workshop',name:'Build a workshop',hint:'Place three different Foundry crafting stations.',key:'stations',goal:3,rewards:{'foundry:polymer':4}},
 {id:'upgrade',name:'Make it yours',hint:'Install an attachment on a weapon.',key:'attachments',goal:1,rewards:{'foundry:light_rounds':16}},
 {id:'range',name:'Range qualification',hint:'Score ten bullseyes on practice targets.',key:'bullseyes',goal:10,rewards:{'foundry:circuit':2}},
 {id:'explore',name:'Field explorer',hint:'Operate a bunker door or silo controller.',key:'facilities',goal:1,rewards:{'minecraft:bread':4}},
 {id:'defend',name:'Hold the line',hint:'Defeat five hostile mobs with your firearms.',key:'hostileKills',goal:5,rewards:{'foundry:maintenance_kit':2,'foundry:cobalt_ingot':2}},
];
export function freshJournal(){return {version:1,settings:{feedback:true,sounds:true,navigation:true},stats:{hits:0,headshots:0,kills:0,hostileKills:0,reloads:0,attachments:0,bullseyes:0,bestDistance:0},range:{hits:0,score:0,streak:0,bestStreak:0},stations:[],facilities:[],waypoint:null,claimed:[]};}
export function parseJournal(raw){
 let data;try{data=JSON.parse(raw);}catch{return freshJournal();}
 const out=freshJournal();if(!data||typeof data!=='object')return out;
 for(const key of Object.keys(out.settings))if(typeof data.settings?.[key]==='boolean')out.settings[key]=data.settings[key];
 for(const key of Object.keys(out.stats))out.stats[key]=integer(data.stats?.[key]);
 for(const key of Object.keys(out.range))out.range[key]=integer(data.range?.[key]);
 if(Array.isArray(data.stations))out.stations=[...new Set(data.stations.filter(id=>STATION_IDS.includes(id)))];
 if(Array.isArray(data.claimed))out.claimed=[...new Set(data.claimed.filter(id=>TASKS.some(task=>task.id===id)))];
 if(Array.isArray(data.facilities))out.facilities=data.facilities.filter(f=>f&&['minecraft:overworld','minecraft:nether','minecraft:the_end'].includes(f.dimension)&&[f.x,f.y,f.z].every(Number.isFinite)&&Math.abs(f.x)<30000000&&Math.abs(f.z)<30000000&&Math.abs(f.y)<1000).slice(-8).map(f=>({name:f.name==='Silo'?'Silo':'Bunker',dimension:f.dimension,x:Math.floor(f.x),y:Math.floor(f.y),z:Math.floor(f.z)}));
 if(Number.isInteger(data.waypoint)&&data.waypoint>=0&&out.facilities[data.waypoint])out.waypoint=data.waypoint;
 return out;
}
export function taskProgress(journal,task){const value=task.key==='stations'?journal.stations.length:task.key==='facilities'?journal.facilities.length:journal.stats[task.key];return Math.min(task.goal,value||0);}
export function claimTask(journal,id){const task=TASKS.find(t=>t.id===id);if(!task||journal.claimed.includes(id)||taskProgress(journal,task)<task.goal)return null;journal.claimed.push(id);return {...task.rewards};}
export function targetScore(face,point,facing='north'){
 const side=String(face).toLowerCase();
 const sideways=facing==='east'||facing==='west';
 if(!(sideways?['east','west']:['north','south']).includes(side))return 0;
 const pair=sideways?[point?.z,point?.y]:[point?.x,point?.y];
 if(!pair.every(Number.isFinite))return 0;
 // The printed plate is 14 pixels wide, from y=2 to y=16; ignore its wooden foot.
 if(pair[0]<1/16||pair[0]>15/16||pair[1]<2/16||pair[1]>1)return 0;
 const radius=Math.hypot((pair[0]-.5)/(14/16),(pair[1]-9/16)/(14/16));
 return radius<=3/32?10:radius<=8/32?7:radius<=14/32?3:1;
}
export function recordRange(journal,score,distance){
 journal.range.hits++;journal.range.score+=score;
 journal.range.streak=score===10?journal.range.streak+1:0;
 journal.range.bestStreak=Math.max(journal.range.bestStreak,journal.range.streak);
 if(score===10){journal.stats.bullseyes++;journal.stats.bestDistance=Math.max(journal.stats.bestDistance,Math.floor(distance));}
}
export function discoverFacility(journal,name,dimension,pos){
 const existing=journal.facilities.findIndex(f=>f.name===name&&f.dimension===dimension&&Math.hypot(f.x-pos.x,f.z-pos.z)<48);
 if(existing>=0)return false;
 if(journal.facilities.length===8){journal.facilities.shift();journal.waypoint=journal.waypoint===0?null:journal.waypoint===null?null:journal.waypoint-1;}
 journal.facilities.push({name,dimension,x:Math.floor(pos.x),y:Math.floor(pos.y),z:Math.floor(pos.z)});return true;
}
export function navigation(journal,dimension,pos){
 const target=journal.waypoint===null?null:journal.facilities[journal.waypoint];
 if(!journal.settings.navigation||!target)return '';
 if(target.dimension!==dimension)return target.name+' · another dimension';
 const dx=target.x-pos.x,dz=target.z-pos.z,distance=Math.floor(Math.hypot(dx,dz));
 if(distance<=8)return target.name+' · HERE';
 const bearing=['N','NE','E','SE','S','SW','W','NW'][(Math.round(Math.atan2(dx,-dz)/(Math.PI/4))+8)%8];
 return target.name+' · '+distance+' blocks '+bearing;
}
export function salvagePlan(state,attachments){
 if(!state?.uid||state.loaded!==0)return null;
 const output={'foundry:steel_plate':1,'foundry:polymer':1};
 for(const [slot,id] of Object.entries(state.attachments||{}))if(attachments[id]?.slot===slot)output['foundry:'+id]=(output['foundry:'+id]||0)+1;
 return output;
}
