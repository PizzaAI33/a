"""Entirely fictional Minecraft missile tiers and crafting progression."""
MISSILES={
 'kestrel_missile':dict(name='Kestrel Tactical Missile',radius=12,depth=8,danger=22,safe=40,flight=180,damage=36,color='#e5b565',tier=1),
 'tempest_missile':dict(name='Tempest Cruise Missile',radius=32,depth=18,danger=48,safe=75,flight=260,damage=60,color='#79c6e2',tier=2),
 'titan_missile':dict(name='Titan Heavy Missile',radius=80,depth=40,danger=115,safe=160,flight=360,damage=100,color='#e87b51',tier=3),
 'apex_icbm':dict(name='Apex Nuclear ICBM',radius=250,depth=100,danger=400,safe=500,flight=600,damage=100,color='#d6f287',tier=4),
}
MATERIALS={
 'dense_alloy':'Dense Alloy','guidance_matrix':'Guidance Matrix','sealed_drive':'Sealed Drive Module',
 'warhead_module':'Warhead Module','stellar_core':'Stellar Core',
 'laser_designator':'Laser Designator','targeting_pad':'Field Targeting Computer',
}
BLOCKS={'silo_casing':'Reinforced Silo Casing','silo_stabilizer':'Silo Stabilizer','silo_controller':'Silo Controller','relic_controller':'Sealed Relic Silo Controller'}
def recipe(id,name,inputs,count=1,category='Missile components'):
 return dict(id=id,name=name,station='missile_fabricator',inputs=inputs,output='foundry:'+id,count=count,category=category)
RECIPES=[
 recipe('dense_alloy','Dense Alloy ×2',{'foundry:reinforced_alloy':4,'minecraft:netherite_scrap':1,'minecraft:diamond':2},2),
 recipe('guidance_matrix','Guidance Matrix',{'foundry:circuit':8,'minecraft:ender_pearl':4,'minecraft:diamond':2}),
 recipe('sealed_drive','Sealed Drive Module',{'foundry:dense_alloy':4,'foundry:power_cell':8,'minecraft:blaze_rod':8}),
 recipe('warhead_module','Warhead Module',{'foundry:dense_alloy':3,'foundry:fluxite_crystal':12,'minecraft:tnt':8}),
 recipe('stellar_core','Stellar Core',{'minecraft:nether_star':1,'minecraft:netherite_ingot':4,'minecraft:echo_shard':8,'foundry:fluxite_crystal':32}),
 recipe('laser_designator','Laser Designator',{'foundry:lens':2,'foundry:circuit':4,'minecraft:emerald':4,'foundry:polymer':4},category='Targeting equipment'),
 recipe('targeting_pad','Field Targeting Computer',{'foundry:guidance_matrix':1,'foundry:lens':1,'foundry:polymer':4,'minecraft:redstone_block':2},category='Targeting equipment'),
 recipe('silo_casing','Reinforced Silo Casing ×16',{'foundry:reinforced_alloy':4,'minecraft:iron_block':2,'minecraft:stone':16},16,category='Silo construction'),
 recipe('silo_stabilizer','Silo Stabilizer ×4',{'foundry:reinforced_alloy':4,'minecraft:redstone_block':2,'minecraft:obsidian':4},4,category='Silo construction'),
 recipe('silo_controller','Silo Controller',{'foundry:guidance_matrix':1,'foundry:reinforced_alloy':4,'minecraft:comparator':2},category='Silo construction'),
 recipe('kestrel_missile','Kestrel Tactical Missile',{'foundry:sealed_drive':1,'foundry:guidance_matrix':1,'foundry:warhead_module':1,'foundry:dense_alloy':2},category='Missiles'),
 recipe('tempest_missile','Tempest Cruise Missile',{'foundry:sealed_drive':2,'foundry:guidance_matrix':2,'foundry:warhead_module':3,'foundry:dense_alloy':4,'minecraft:diamond_block':1},category='Missiles'),
 recipe('titan_missile','Titan Heavy Missile',{'foundry:sealed_drive':4,'foundry:guidance_matrix':3,'foundry:warhead_module':6,'foundry:dense_alloy':8,'minecraft:netherite_ingot':2,'minecraft:diamond_block':2},category='Missiles'),
 recipe('apex_icbm','Apex Nuclear ICBM',{'foundry:stellar_core':2,'foundry:sealed_drive':8,'foundry:guidance_matrix':4,'foundry:warhead_module':12,'foundry:dense_alloy':16,'minecraft:diamond_block':4},category='Missiles'),
]
