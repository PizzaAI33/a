import {world,system,EntityDamageCause} from '@minecraft/server';
import {ActionFormData,MessageFormData} from '@minecraft/server-ui';
import {TASKS,HOSTILES,STATION_IDS,parseJournal,taskProgress,claimTask,targetScore,recordRange,discoverFacility,navigation} from './experience_core.js';

const KEY='foundry:journal_v1',cache=new Map(),feedback=new Map(),recentHits=new Map();
let H;
function state(p){if(!cache.has(p.id))cache.set(p.id,parseJournal(p.getDynamicProperty(KEY)));return cache.get(p.id);}
function save(p){p.setDynamicProperty(KEY,JSON.stringify(state(p)));}
export function recordMilestone(p,key){const j=state(p);if(key in j.stats){j.stats[key]++;save(p);}}
function cue(p,text,sound='random.orb'){
 const j=state(p),last=feedback.get(p.id);
 feedback.set(p.id,{text:j.settings.feedback?text:'',end:system.currentTick+24,tick:system.currentTick});
 if(j.settings.sounds&&(!last||last.tick!==system.currentTick)){try{p.playSound(sound,{volume:.25,pitch:1.4});}catch{}}
}
export function combatHit(p,entity,headshot){
 const j=state(p);j.stats.hits++;if(headshot)j.stats.headshots++;
 recentHits.set(entity.id,{owner:p.id,tick:system.currentTick});save(p);
 cue(p,headshot?'§6✦ HEADSHOT':'§f× HIT');
}
export function practiceHit(p,face,point,distance,facing='north'){
 const j=state(p),score=targetScore(face,point,facing);if(!score)return;
 recordRange(j,score,distance);save(p);
 cue(p,score===10?`§a◎ BULLSEYE · ${Math.floor(distance)} blocks`:`§bTARGET +${score}`,'random.click');
}
export function feedbackText(p){const f=feedback.get(p.id);return f&&f.end>=system.currentTick?f.text:'';}
export function navigationText(p){return navigation(state(p),p.dimension.id,p.location);}
export function installExperience(helpers){
 H=helpers;
 system.beforeEvents.startup.subscribe(e=>e.blockComponentRegistry.registerCustomComponent('foundry:range_target',{onPlayerInteract:e=>{
  if(e.player)system.run(()=>{const item=e.player.getComponent('minecraft:inventory')?.container?.getItem(e.player.selectedSlotIndex);if(!item&&!H.busy(e.player))rangeMenu(e.player);});
 }}));
 world.afterEvents.playerPlaceBlock.subscribe(e=>{
  try{if(!STATION_IDS.includes(e.block.typeId))return;const j=state(e.player);if(!j.stations.includes(e.block.typeId)){j.stations.push(e.block.typeId);save(e.player);}}catch(e){console.warn('[Foundry journal] '+e);}
 });
 world.afterEvents.playerInteractWithBlock.subscribe(e=>{
  try{
   if(!e.isFirstEvent)return;
   const name=e.block.typeId==='foundry:bunker_switch'?'Bunker':['foundry:silo_controller','foundry:relic_controller'].includes(e.block.typeId)?'Silo':null;
   if(name&&discoverFacility(state(e.player),name,e.block.dimension.id,e.block.location)){save(e.player);H.message(e.player,name+' recorded in your Field Journal.');}
  }catch(e){console.warn('[Foundry journal] '+e);}
 });
 world.afterEvents.entityDie.subscribe(e=>{
  try{
   const last=recentHits.get(e.deadEntity.id);recentHits.delete(e.deadEntity.id);
   const p=e.damageSource.damagingEntity;if(!last||p?.id!==last.owner||system.currentTick-last.tick>100||p.typeId!=='minecraft:player'||e.damageSource.cause!==EntityDamageCause.projectile)return;
   const j=state(p);j.stats.kills++;if(HOSTILES.has(e.deadEntity.typeId))j.stats.hostileKills++;save(p);cue(p,'§a✦ CONFIRMED','random.levelup');
  }catch(e){console.warn('[Foundry journal] '+e);}
 });
 world.afterEvents.playerLeave.subscribe(e=>{cache.delete(e.playerId);feedback.delete(e.playerId);});
 system.runInterval(()=>{
  for(const [id,last] of recentHits)if(system.currentTick-last.tick>100)recentHits.delete(id);
  for(const [id,f] of feedback)if(f.end<system.currentTick)feedback.delete(id);
 },100);
}
export async function fieldJournal(p){
 const j=state(p),complete=TASKS.filter(t=>taskProgress(j,t)===t.goal).length;
 const f=new ActionFormData().title('FIELD JOURNAL').body(`Field tasks: ${complete}/${TASKS.length} complete\nHits: ${j.stats.hits} · headshots: ${j.stats.headshots}\nConfirmed defeats: ${j.stats.kills}\nBullseyes: ${j.stats.bullseyes} · longest: ${j.stats.bestDistance} blocks\n\nOptional goals. Rewards can be claimed once. Nothing gates crafting.`).button('Field tasks & rewards').button('Saved facilities').button('Feedback / navigation settings');
 const a=await H.show(p,f);if(a.canceled)return;if(a.selection===0)return taskMenu(p);if(a.selection===1)return facilitiesMenu(p);if(a.selection===2)return settingsMenu(p);
}
async function taskMenu(p){
 const j=state(p),f=new ActionFormData().title('FIELD TASKS');
 TASKS.forEach(t=>f.button((j.claimed.includes(t.id)?'§7CLAIMED':taskProgress(j,t)===t.goal?'§aREADY':'§f'+taskProgress(j,t)+'/'+t.goal)+' · '+t.name));
 const a=await H.show(p,f);if(a.canceled)return;const task=TASKS[a.selection];if(!task)return;
 const ready=taskProgress(state(p),task)===task.goal&&!state(p).claimed.includes(task.id);
 const body=task.hint+'\n\nRewards:\n'+Object.entries(task.rewards).map(([id,n])=>n+' × '+id.replace('foundry:','').replace('minecraft:','').replaceAll('_',' ')).join('\n');
 const f2=new ActionFormData().title(task.name).body(body).button(ready?'Claim reward':'Back');const answer=await H.show(p,f2);if(answer.canceled||answer.selection!==0)return;
 if(ready){const reward=claimTask(state(p),task.id);if(reward){save(p);for(const [id,n] of Object.entries(reward))H.give(p,id,n);H.message(p,'Completed: '+task.name);}}
 return taskMenu(p);
}
async function facilitiesMenu(p){
 const j=state(p),f=new ActionFormData().title('SAVED FACILITIES').body('Operate a bunker door or silo controller to remember it. Select a site for compass directions. This does not teleport you.');
 j.facilities.forEach(site=>f.button(site.name+' · '+site.x+', '+site.y+', '+site.z));f.button('Clear navigation');
 const snapshot=JSON.stringify(j.facilities),a=await H.show(p,f);if(a.canceled)return;
 if(JSON.stringify(state(p).facilities)!==snapshot){H.message(p,'Locations changed. Reopen the journal.');return;}
 state(p).waypoint=a.selection<j.facilities.length?a.selection:null;save(p);H.message(p,a.selection<j.facilities.length?'Navigation set. Directions appear on your HUD.':'Navigation cleared.');
}
async function settingsMenu(p){
 const j=state(p),f=new ActionFormData().title('PERSONAL SETTINGS');
 for(const [key,name] of [['feedback','Hit feedback'],['sounds','Feedback sounds'],['navigation','Facility directions']])f.button(name+': '+(j.settings[key]?'ON':'OFF'));
 const a=await H.show(p,f);if(a.canceled)return;const key=['feedback','sounds','navigation'][a.selection];if(!key)return;state(p).settings[key]=!state(p).settings[key];save(p);
 if(key==='feedback'&&!state(p).settings.feedback)feedback.delete(p.id);
 return settingsMenu(p);
}
async function rangeMenu(p){
 const j=state(p),f=new ActionFormData().title('PRACTICE RANGE').body(`Hits: ${j.range.hits}\nScore: ${j.range.score}\nBullseye streak: ${j.range.streak}\nBest streak: ${j.range.bestStreak}\n\nCenter: 10 points · inner ring: 7 · outer ring: 3\nFirearms use their normal ammunition. Shotgun pellets score individually.`).button('Reset session score').button('Field journal');
 const a=await H.show(p,f);if(a.canceled)return;
 if(a.selection===0){const answer=await H.show(p,new MessageFormData().title('RESET RANGE SESSION').body('Clear only your current range score and streak. Lifetime bullseyes and field tasks remain.').button1('Reset').button2('Cancel'));if(!answer.canceled&&answer.selection===0){state(p).range={hits:0,score:0,streak:0,bestStreak:0};save(p);}}
 else if(a.selection===1)return fieldJournal(p);
}
