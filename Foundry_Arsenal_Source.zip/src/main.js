import {world,system,ItemStack,EquipmentSlot,EntityDamageCause,GameMode} from '@minecraft/server';
import {ActionFormData,MessageFormData,FormCancelationReason} from '@minecraft/server-ui';
import {GUNS,ATTACHMENTS,RECIPES,GRENADES,AMMO,STATIONS,NAMES} from './data.js';
import {add,mul,normalize,length,distance,spreadRay,stats,compatible,parseState,inventoryTotals,canAfford,reloadPlan,blastDamage} from './core.js';
import {installSiege,siegeUse,siegeManual} from './siege.js';

import {muzzlePoint} from './weapon_view.js';
import './doors.js';
import {shotVisual,updateVisual,forgetVisual} from './presentation.js';
import {installExperience,recordMilestone,combatHit,practiceHit,feedbackText,navigationText,fieldJournal} from './experience.js';
import {salvagePlan} from './experience_core.js';

const gunMap=new Map(GUNS.map(g=>['foundry:'+g.id,g]));
const runtime=new Map(), flights=[], clouds=[];
const logOnce=new Set();
function report(where,error) {if(!logOnce.has(where)){console.warn(`[Foundry] ${where}: ${error}`);logOnce.add(where);}}
function rt(p) {if(!runtime.has(p.id))runtime.set(p.id,{next:0,held:false,slot:-1,reload:null,fov:0,ui:false,lastUse:-100,burst:0,uid:''});return runtime.get(p.id);}
function inv(p) {return p.getComponent('minecraft:inventory')?.container;}
function selected(p) {return inv(p)?.getItem(p.selectedSlotIndex);}
function creative(p) {return p.getGameMode()===GameMode.Creative;}
function message(p,s) {p.sendMessage('§b[Foundry] §r'+s);}
function sound(p,id,volume=1,pitch=1) {try{p.dimension.playSound(id,p.location,{volume,pitch});}catch(e){report('sound:'+id,e);}}
function particle(d,id,pos) {try{d.spawnParticle('foundry:'+id,pos);}catch(e){report('particle:'+id,e);}}
function gunState(item) {return parseState(item.getDynamicProperty('foundry:state'));}
function writeGun(p,slot,item,state) {
 item.setDynamicProperty('foundry:state',JSON.stringify(state));
 const g=gunMap.get(item.typeId),s=stats(g,state,ATTACHMENTS);
 const mods=Object.values(state.attachments).map(id=>ATTACHMENTS[id]?.name).filter(Boolean);
 item.setLore([`§7${g.category} · ${g.mode.toUpperCase()}`,`§e${state.loaded}/${s.capacity} §7${AMMO[g.ammo]}`,`§7Condition: ${Math.max(0,100-Math.floor(state.wear/10))}%`,...mods.map(n=>'§b'+n)].slice(0,10));
 inv(p).setItem(slot,item);
}
function ensureGun(p,item) {
 const s=gunState(item);if(!s.uid){s.uid=p.id+':'+system.currentTick+':'+Math.random().toString(36).slice(2,10);writeGun(p,p.selectedSlotIndex,item,s);}return s;
}
function allItems(p) {const c=inv(p);return Array.from({length:c.size},(_,i)=>c.getItem(i));}
function count(p,id) {return inventoryTotals(allItems(p))[id]||0;}
function consume(p,cost) {
 const c=inv(p);if(!c||!canAfford(inventoryTotals(allItems(p)),cost))return false;
 for(const [id,n] of Object.entries(cost)) {
  let left=n;
  for(let i=0;i<c.size&&left>0;i++) {const it=c.getItem(i);if(it?.typeId!==id)continue;const take=Math.min(left,it.amount);left-=take;if(take===it.amount)c.setItem(i);else{it.amount-=take;c.setItem(i,it);}}
 }return true;
}
function give(p,id,n=1) {
 const c=inv(p);while(n>0){const item=new ItemStack(id);item.amount=Math.min(n,item.maxAmount);n-=item.amount;const rem=c.addItem(item);if(rem)p.dimension.spawnItem(rem,p.location);}
}
function damageable(e,owner) {
 if(!e?.isValid||['minecraft:item','minecraft:xp_orb','foundry:projectile_marker'].includes(e.typeId))return false;
 if(!e.getComponent('minecraft:health'))return false;
 if(e.typeId==='minecraft:player'&&(!world.gameRules.pvp||e.getGameMode()===GameMode.Creative||e.getGameMode()===GameMode.Spectator))return false;
 return true;
}
function hit(e,damage,p,effect='normal',headshot=false) {
 if(!damageable(e,p))return;
 try{
  if(!e.applyDamage(damage,{cause:EntityDamageCause.projectile,damagingEntity:p}))return false;
  combatHit(p,e,headshot);
  if(effect==='fire')e.setOnFire(4,true);
  if(effect==='ice')e.addEffect('slowness',70,{amplifier:3,showParticles:true});
  if(effect==='poison')e.addEffect('poison',90,{amplifier:0,showParticles:true});
  if(effect==='shock'){
   e.addEffect('weakness',60,{amplifier:1});particle(e.dimension,'arc',e.getHeadLocation());
   for(const other of e.dimension.getEntities({location:e.location,maxDistance:3.5})){if(other.id===e.id||other.id===p.id||!damageable(other,p))continue;other.applyDamage(Math.max(1,damage*.30),{cause:EntityDamageCause.projectile,damagingEntity:p});particle(e.dimension,'arc',other.location);break;}
  }
  return true;
 }catch(err){report('hit',err);}
}
function clearAim(p,r) {if(r.fov){try{p.camera.setFov();}catch(e){report('clear-fov',e);}r.fov=0;}}
function reload(p) {
 const item=selected(p),g=item&&gunMap.get(item.typeId);if(!g)return;
 const r=rt(p);if(r.reload)return;
 const state=ensureGun(p,item),s=stats(g,state,ATTACHMENTS),reserve=count(p,'foundry:'+g.ammo);
 if(!reloadPlan(state.loaded,s.capacity,reserve)){message(p,state.loaded>=s.capacity?'Magazine is full.':'No '+AMMO[g.ammo]+' in your inventory.');return;}
 r.reload={end:system.currentTick+s.reload,duration:s.reload,slot:p.selectedSlotIndex,uid:state.uid,type:item.typeId};r.held=false;r.burst=0;
 sound(p,'foundry.reload',.65);message(p,'Reloading '+g.name+'…');
}
function finishReload(p,r,item,g,state) {
 const task=r.reload;
 if(task.slot!==p.selectedSlotIndex||task.uid!==state.uid||task.type!==item.typeId){r.reload=null;return;}
 if(system.currentTick<task.end)return;
 const s=stats(g,state,ATTACHMENTS),n=reloadPlan(state.loaded,s.capacity,count(p,'foundry:'+g.ammo));
 if(n>0&&consume(p,{['foundry:'+g.ammo]:n})){state.loaded+=n;writeGun(p,p.selectedSlotIndex,item,state);recordMilestone(p,'reloads');sound(p,'foundry.reload',.5,1.4);}
 r.reload=null;
}
function rayShot(p,s) {
 const d=p.dimension,eye=p.getHeadLocation(),view=p.getViewDirection();
 const cameraHit=d.getBlockFromRay(eye,view,{maxDistance:s.range,includeLiquidBlocks:false,includePassableBlocks:false});
 const aim=cameraHit?add(cameraHit.block.location,cameraHit.faceLocation):add(eye,mul(view,s.range));
 const origin=muzzlePoint(p,s),direction=spreadRay(normalize({x:aim.x-origin.x,y:aim.y-origin.y,z:aim.z-origin.z}),s.spread);
 let wallDist=s.range,end=add(origin,mul(direction,s.range));
 const wall=d.getBlockFromRay(origin,direction,{maxDistance:s.range,includeLiquidBlocks:false,includePassableBlocks:false});
 if(wall){end=add(wall.block.location,wall.faceLocation);wallDist=distance(origin,end);}
 const targets=d.getEntitiesFromRay(origin,direction,{maxDistance:wallDist,ignoreBlockCollision:false}).filter(h=>h.entity.id!==p.id&&damageable(h.entity,p)).sort((a,b)=>a.distance-b.distance);
 for(const h of targets.slice(0,s.effect==='piercing'?3:1)) {
  const point=add(origin,mul(direction,h.distance)),head=h.entity.getHeadLocation();
  const headshot=point.y>=head.y-.25;
  hit(h.entity,Math.max(1,Math.round(s.damage*(headshot?1.4:1)*(1-.35*h.distance/s.range))),p,s.effect,headshot);
  particle(d,s.effect==='ice'?'frost':s.effect==='shock'?'arc':'impact',point);
  if(s.effect!=='piercing'){end=point;break;}
 }
 // Score the plate only if the bullet reaches it, not through a living target.
 if(wall?.block.typeId==='foundry:range_target'&&distance(end,add(wall.block.location,wall.faceLocation))<.001)practiceHit(p,wall.face,wall.faceLocation,wallDist,wall.block.permutation.getState('minecraft:cardinal_direction'));
 const len=distance(origin,end),steps=Math.min(12,Math.ceil(len/3));
 for(let i=1;i<=steps;i++)particle(d,s.effect==='ice'?'frost':s.effect==='shock'?'arc':'tracer',add(origin,mul(direction,len*i/steps)));
}
function launch(p,s,grenade=null) {
 if(flights.length>=96){message(p,'Too many active projectiles; wait a moment.');return false;}
 const dir=p.getViewDirection(),pos=grenade?add(p.getHeadLocation(),mul(dir,.75)):muzzlePoint(p,s);
 const lob=grenade||s.projectile==='grenade';
 const velocity=add(mul(dir,lob?1.05:2.8),{x:0,y:lob?.22:0,z:0});
 let marker;try{marker=p.dimension.spawnEntity('foundry:projectile_marker',pos);}catch(e){report('projectile-marker',e);}
 flights.push({pos,velocity,dimension:p.dimension,owner:p,marker,age:0,kind:grenade?.effect||'frag',fuse:grenade?.fuse||(lob?48:90),radius:grenade?.radius||(s.blast||4),damage:grenade?.damage||s.damage,lob:!!lob,impact:!grenade,maxRange:s.range||80,travel:0});return true;
}
function shoot(p,forced=false) {
 const item=selected(p),g=item&&gunMap.get(item.typeId);if(!g)return false;
 const r=rt(p);if(r.ui||r.reload||system.currentTick<r.next)return false;
 const state=ensureGun(p,item),s=stats(g,state,ATTACHMENTS,p.isSneaking);
 if(state.wear>=1000&&!creative(p)){message(p,'Weapon needs a Field Maintenance Kit.');r.held=false;return false;}
 if(state.loaded<=0){r.held=false;r.burst=0;reload(p);return false;}
 if(g.projectile&&!launch(p,s))return false;
 r.next=system.currentTick+(g.mode==='burst'?2:s.interval);
 shotVisual(p);
 state.loaded--;if(!creative(p))state.wear+=1;
 writeGun(p,p.selectedSlotIndex,item,state);
 if(!g.projectile)for(let i=0;i<s.pellets;i++)rayShot(p,s);
 sound(p,s.quiet?'foundry.suppressed':g.category==='Shotguns'?'foundry.shotgun':g.projectile?'foundry.launch':g.category==='Sniper rifles'?'foundry.heavy':'foundry.shot',s.quiet?.22:.85,1+(GUNS.indexOf(g)%5)*.04);
 particle(p.dimension,'muzzle',muzzlePoint(p,s));
 return true;
}
function beginUse(p,item,pressed=false) {
 if(gunMap.has(item.typeId)&&!pressed)return;
 const r=rt(p);if(r.ui||system.currentTick-r.lastUse<2)return;r.lastUse=system.currentTick;
 if(gunMap.has(item.typeId)){
  // Custom onUse callbacks may arrive on release. Only the native start signal
  // may arm a gun; late callbacks must never restart automatic fire.
  const g=gunMap.get(item.typeId);r.slot=p.selectedSlotIndex;r.uid=ensureGun(p,selected(p)).uid;r.held=g.mode==='auto';r.burst=g.mode==='burst'?3:0;
  if(shoot(p)&&r.burst>0)r.burst--;return;
 }
 const id=item.typeId.replace('foundry:','');
 if(siegeUse(p,item))return;
 if(GRENADES[id]){
  if(system.currentTick<r.next)return;
  if(launch(p,{range:80,damage:GRENADES[id].damage},GRENADES[id])){if(!creative(p))consume(p,{[item.typeId]:1});r.next=system.currentTick+12;sound(p,'random.bow',.5);}return;
 }
 if(id==='field_manual'){system.run(()=>manual(p));return;}
 if(id==='maintenance_kit'){system.run(()=>equipmentMenu(p));return;}
 if(id==='medkit'){
  if(system.currentTick<r.next)return;if(!creative(p)&&!consume(p,{[item.typeId]:1}))return;
  p.addEffect('regeneration',100,{amplifier:1});r.next=system.currentTick+120;message(p,'Medkit applied.');
 }
}
system.beforeEvents.startup.subscribe(e=>{
 e.itemComponentRegistry.registerCustomComponent('foundry:use',{
  onUse:event=>beginUse(event.source,event.itemStack),
  onUseOn:event=>{const item=selected(event.source);if(item)beginUse(event.source,item);},
 });
 e.blockComponentRegistry.registerCustomComponent('foundry:station',{
  onPlayerInteract:event=>{if(event.player)system.run(()=>stationMenu(event.player,event.block));},
 });
});
world.afterEvents.itemStartUse.subscribe(e=>beginUse(e.source,e.itemStack,true));
function stopUse(p){const r=rt(p);r.held=false;r.burst=0;}
world.afterEvents.itemStopUse.subscribe(e=>stopUse(e.source));
world.afterEvents.itemReleaseUse.subscribe(e=>stopUse(e.source));
world.afterEvents.itemCompleteUse.subscribe(e=>stopUse(e.source));
world.afterEvents.playerLeave.subscribe(e=>{runtime.delete(e.playerId);forgetVisual(e.playerId);});
world.afterEvents.playerSpawn.subscribe(e=>{
 const p=e.player;runtime.delete(p.id);forgetVisual(p.id);try{p.camera.setFov();}catch{}
 if(!p.getDynamicProperty('foundry:welcomed'))system.run(()=>{try{give(p,'foundry:field_manual');p.setDynamicProperty('foundry:welcomed',true);message(p,'Welcome to Foundry Arsenal. Use your Field Manual to learn the controls and crafting chain.');}catch(err){report('welcome',err);}});
});
system.afterEvents.scriptEventReceive.subscribe(e=>{if(e.id==='foundry:help'&&e.sourceEntity?.typeId==='minecraft:player')system.run(()=>manual(e.sourceEntity));});

function visible(d,origin,target) {
 const delta={x:target.x-origin.x,y:target.y-origin.y,z:target.z-origin.z},len=length(delta);
 if(len<.2)return true;
 try{return !d.getBlockFromRay(origin,normalize(delta),{maxDistance:Math.max(.1,len-.3),includePassableBlocks:false,includeLiquidBlocks:false});}catch{return false;}
}
function explode(f) {
 try{f.marker?.remove();}catch{}
 const d=f.dimension,pos=f.pos;
 if(['smoke','fire','ice'].includes(f.kind))clouds.push({dimension:d,pos,kind:f.kind,owner:f.owner,radius:f.radius,ttl:f.kind==='smoke'?200:100});
 for(let i=0;i<24;i++){const offset={x:(Math.random()-.5)*f.radius,y:Math.random()*2,z:(Math.random()-.5)*f.radius};particle(d,f.kind==='ice'?'frost':f.kind==='shock'?'arc':f.kind==='smoke'?'smoke':'blast',add(pos,offset));}
 try{d.playSound(f.kind==='smoke'?'random.fizz':'random.explode',pos,{volume:1,pitch:f.kind==='flash'?1.8:1});}catch{}
 if(!f.owner?.isValid)return;
 // Native TNT-style blast handles both terrain and entity damage exactly once.
 const destructive=!['smoke','flash'].includes(f.kind);
 if(destructive){
  try{d.createExplosion(pos,Math.min(5,Math.max(2.5,f.radius)),{breaksBlocks:true,causesFire:f.kind==='fire',source:f.owner});}
  catch(e){report('projectile explosion',e);}
  return;
 }
 for(const e of d.getEntities({location:pos,maxDistance:f.radius})){
  if(!damageable(e,f.owner)||!visible(d,add(pos,{x:0,y:.1,z:0}),e.getHeadLocation()))continue;
  if(f.kind==='flash'){e.addEffect('blindness',70,{amplifier:0});e.addEffect('slowness',30,{amplifier:1});if(e.typeId==='minecraft:player')try{e.camera.fade({fadeColor:{red:1,green:1,blue:1},fadeTime:{fadeInTime:.05,holdTime:.12,fadeOutTime:.7}});}catch{} }
  else if(f.kind!=='smoke')hit(e,blastDamage(f.damage,distance(pos,e.location),f.radius),f.owner,f.kind==='frag'?'normal':f.kind);
 }
}
function tickProjectiles() {
 for(let i=flights.length-1;i>=0;i--){const f=flights[i];try{
  f.age++;if(!f.owner?.isValid){try{f.marker?.remove();}catch{}flights.splice(i,1);continue;}
  if(f.lob)f.velocity.y-=.035;
  const len=length(f.velocity),dir=normalize(f.velocity);let collision=f.dimension.getBlockFromRay(f.pos,dir,{maxDistance:len,includeLiquidBlocks:false,includePassableBlocks:false});
  const entityHit=f.dimension.getEntitiesFromRay(f.pos,dir,{maxDistance:len,ignoreBlockCollision:false}).find(h=>h.entity.id!==f.owner.id&&damageable(h.entity,f.owner));
  let detonate=false;
  if(entityHit&&f.impact){f.pos=add(f.pos,mul(dir,entityHit.distance));detonate=true;}
  else if(collision){
   const point=add(collision.block.location,collision.faceLocation);f.pos=add(point,mul(dir,-.08));
   if(f.impact)detonate=true;
   else {const face=String(collision.face).toLowerCase();if(face==='up'||face==='down')f.velocity.y*=-.45;else if(face==='east'||face==='west')f.velocity.x*=-.45;else f.velocity.z*=-.45;f.velocity.x*=.65;f.velocity.z*=.65;}
  }else f.pos=add(f.pos,f.velocity);
  f.travel+=len;
  if(f.marker?.isValid)f.marker.teleport(f.pos);
  particle(f.dimension,f.kind==='ice'?'frost':f.kind==='shock'?'arc':'smoke',f.pos);
  if(detonate||f.age>=f.fuse||f.travel>f.maxRange){explode(f);flights.splice(i,1);}
 }catch(e){try{f.marker?.remove();}catch{}flights.splice(i,1);report('projectile-tick',e);}}
 for(let i=clouds.length-1;i>=0;i--){const c=clouds[i];c.ttl--;if(c.ttl<=0){clouds.splice(i,1);continue;}if(system.currentTick%5)continue;
  try{
   for(let n=0;n<10;n++)particle(c.dimension,c.kind==='ice'?'frost':c.kind==='fire'?'ember':'smoke',add(c.pos,{x:(Math.random()-.5)*c.radius*2,y:Math.random()*2.8,z:(Math.random()-.5)*c.radius*2}));
   if(c.owner?.isValid)for(const e of c.dimension.getEntities({location:c.pos,maxDistance:c.radius})){
    if(!damageable(e,c.owner)||!visible(c.dimension,add(c.pos,{x:0,y:.2,z:0}),e.getHeadLocation()))continue;
    if(c.kind==='smoke')e.addEffect('blindness',15,{showParticles:false});
    if(c.kind==='fire')e.setOnFire(2,true);
    if(c.kind==='ice')e.addEffect('slowness',25,{amplifier:2});
   }
  }catch(e){report('cloud',e);}
 }
}
system.runInterval(()=>{
 for(const p of world.getAllPlayers())try{
  const r=rt(p),item=selected(p),g=item&&gunMap.get(item.typeId);
  updateVisual(p,g,r,item?gunState(item):null);
  if(!g){r.held=false;r.burst=0;r.reload=null;clearAim(p,r);if(system.currentTick%20===0){const text=[feedbackText(p),navigationText(p)].filter(Boolean).join(' §r| ');if(text)p.onScreenDisplay.setActionBar(text);}continue;}
  const state=ensureGun(p,item),s=stats(g,state,ATTACHMENTS,p.isSneaking);
  if(r.slot!==p.selectedSlotIndex||r.uid!==state.uid){r.held=false;r.burst=0;r.slot=p.selectedSlotIndex;r.uid=state.uid;}
  if(r.reload)finishReload(p,r,item,g,state);
  if((r.held||r.burst>0)&&system.currentTick>=r.next&&!r.reload){if(shoot(p)&&r.burst>0){r.burst--;if(!r.burst)r.next=system.currentTick+g.interval;}}
  if(p.isSneaking&&!r.ui){if(r.fov!==s.fov){p.camera.setFov({fov:s.fov});r.fov=s.fov;}if(s.night&&system.currentTick%20===0)p.addEffect('night_vision',50,{showParticles:false});}
  else clearAim(p,r);
  if(system.currentTick%4===0){const current=gunState(selected(p)),extra=[feedbackText(p),navigationText(p)].filter(Boolean).join(' §r| ');p.onScreenDisplay.setActionBar(`§b${g.name} §r| §e${current.loaded}/${s.capacity} §r| ${AMMO[g.ammo]}: ${count(p,'foundry:'+g.ammo)}${r.reload?' §6RELOADING':''}${p.isSneaking?' §aAIM':''}${extra?' §r| '+extra:''}`);}
  if(s.laser&&p.isSneaking&&system.currentTick%6===0){const h=p.getBlockFromViewDirection({maxDistance:32});if(h)particle(p.dimension,'laser',add(h.block.location,h.faceLocation));}
 }catch(e){report('player-tick',e);}
 tickProjectiles();
},1);
system.runInterval(()=>{
 for(const p of world.getAllPlayers())try{const eq=p.getComponent('minecraft:equippable');if(eq?.getEquipment(EquipmentSlot.Head)?.typeId==='foundry:night_vision_goggles')p.addEffect('night_vision',50,{showParticles:false});}catch(e){report('gear',e);}
},20);

// Forms re-check inventory and station proximity at commit time.
async function show(p,form) {
 const r=rt(p);r.ui=true;r.held=false;r.burst=0;clearAim(p,r);
 try {
  for(let retry=0;retry<3;retry++){
   const result=await form.show(p);
   if(!result.canceled||result.cancelationReason!==FormCancelationReason.UserBusy)return result;
   await new Promise(resolve=>system.runTimeout(()=>resolve(undefined),10));
  }
  message(p,'Release Use and close chat, then try again.');return {canceled:true};
 }catch(e){report('form',e);return {canceled:true};}finally{r.ui=false;}
}
async function manual(p) {
 const f=new ActionFormData().title('FOUNDRY / FIELD MANUAL').body('60 weapons • 24 attachments • 6 new ores\n\nUSE: fire; hold for automatic weapons.\nSNEAK: aim / scope zoom. Empty magazine: use to reload.\nMaintenance Kit: reload a partial magazine, unload, repair or change attachments.\n\nNew ores generate in NEW Overworld chunks. Craft five stations at a crafting table. See Bunkers, silos & missiles for the expansion.');
 f.button('Weapon catalogue').button('Mining & crafting guide').button('Equipment / attachments').button('Controls & limitations').button('Bunkers, silos & missiles').button('Field journal / tasks');
 const a=await show(p,f);if(a.canceled)return;
 if(a.selection===0)return catalogue(p);
 if(a.selection===1)return textForm(p,'From ore to arsenal','1. Mine zinc (Y 0–80), sulfur (−16–64), cobalt (−40–40), titanium (−56–8), tungsten (−60 to −16), fluxite (−60 to −32). Use a pickaxe.\n2. Smelt raw metals in a furnace.\n3. Craft an Alloy Forge; use it for plates, modules and composites.\n4. Use the Gunsmith Bench to build a weapon.\n5. Make matching rounds at the Ammo Press.\n6. Use the Attachment Bench for attachments and equipment.\n\nAll recipes are fictional Minecraft recipes. Each station displays exactly what you need.');
 if(a.selection===2)return equipmentMenu(p);
 if(a.selection===4)return siegeManual(p);
 if(a.selection===5)return fieldJournal(p);
 return textForm(p,'Controls & notes','Right-click / Use: fire. Hold Use: full-auto. Burst weapons fire three rounds per press. Sneak: steady aim and scope zoom.\n\nUse an empty weapon to reload. For manual reloads or attachments, use a Field Maintenance Kit or the Field Manual equipment menu. Reloads cancel on switching weapon.\n\nFrag grenades and launcher rounds use native TNT-style explosions that damage entities and terrain. Smoke and flash remain non-destructive. Silo missiles permanently excavate terrain. Smoke affects vision; flash blinds; frost slows; arc chains; ember burns.\n\n60 individually named, balanced weapons with stylized block models. Shared class animations; installed optics change visible sight meshes; other attachments change stats.\n\nThis release has static/automated validation, but has not yet been play-tested in the Bedrock client.');
}
async function textForm(p,title,body) {await show(p,new ActionFormData().title(title).body(body).button('Close'));}
async function catalogue(p,filter=null) {
 if(!filter){const cats=[...new Set(GUNS.map(g=>g.category))];const f=new ActionFormData().title('WEAPON CATALOGUE').body('Select a class. Damage values are Minecraft health points.');cats.forEach(c=>f.button(c+' · '+GUNS.filter(g=>g.category===c).length));const a=await show(p,f);if(!a.canceled)return catalogue(p,cats[a.selection]);return;}
 const guns=GUNS.filter(g=>g.category===filter),f=new ActionFormData().title(filter).body('Select a weapon for details.');guns.forEach(g=>f.button(g.name,'textures/items/'+g.id));const a=await show(p,f);if(a.canceled)return;
 const g=guns[a.selection],recipe=RECIPES.find(r=>r.id===g.id),details=`${g.category} / ${g.mode.toUpperCase()}\nDamage: ${g.damage}${g.pellets>1?' × '+g.pellets+' pellets':''}\nRange: ${g.range} blocks\nMagazine: ${g.capacity}\nAmmo: ${AMMO[g.ammo]}\nReload: ${(g.reload/20).toFixed(1)} sec\n\nGunsmith Bench ingredients:\n${costText(recipe.inputs)}`;
 const form=new ActionFormData().title(g.name).body(details).button('Back');if(creative(p))form.button('Creative: receive weapon + ammo');
 const b=await show(p,form);if(!b.canceled&&b.selection===1&&creative(p)){give(p,'foundry:'+g.id);give(p,'foundry:'+g.ammo,g.projectile?16:128);message(p,'Added '+g.name+' and ammunition. Use the empty gun to reload.');}else if(!b.canceled)return catalogue(p,filter);
}
function costText(cost){return Object.entries(cost).map(([id,n])=>`${n} × ${NAMES[id]||id.replace('minecraft:','').replaceAll('_',' ')}`).join('\n');}
function nearStation(p,b){try{return b.isValid&&p.dimension.id===b.dimension.id&&distance(p.location,b.location)<7;}catch{return false;}}
async function stationMenu(p,b,category=null) {
 const id=b.typeId.replace('foundry:','');if(!STATIONS[id]||rt(p).ui)return;
 const rows=RECIPES.filter(r=>r.station===id),categories=[...new Set(rows.map(r=>r.category))];
 if(!category&&categories.length>1){const f=new ActionFormData().title(STATIONS[id]).body('Choose a crafting category. Ingredients are taken only after confirmation.');categories.forEach(c=>f.button(c));const a=await show(p,f);if(!a.canceled&&nearStation(p,b))return stationMenu(p,b,categories[a.selection]);return;}
 const list=category?rows.filter(r=>r.category===category):rows,totals=inventoryTotals(allItems(p));
 const f=new ActionFormData().title(STATIONS[id]).body(category||'Refine materials and produce modules.');list.forEach(r=>f.button((canAfford(totals,r.inputs)?'§a':'§7')+r.name,'textures/items/'+r.id));
 const a=await show(p,f);if(a.canceled)return;const row=list[a.selection];
 const confirm=new MessageFormData().title(row.name).body('Required:\n'+costText(row.inputs)+'\n\nProduces: '+row.count+' × '+(NAMES[row.output]||row.name)).button1('Craft').button2('Cancel');
 const answer=await show(p,confirm);if(answer.canceled||answer.selection!==0)return;
 if(!nearStation(p,b)||b.typeId!=='foundry:'+row.station){message(p,'Return to the correct station.');return;}
 if(!consume(p,row.inputs)){message(p,'Missing materials. No ingredients were taken.');return;}
 give(p,row.output,row.count);sound(p,'random.anvil_use',.4,1.3);message(p,'Crafted '+row.name);return stationMenu(p,b,category);
}
async function equipmentMenu(p) {
 const c=inv(p),guns=[];for(let i=0;i<c.size;i++){const it=c.getItem(i);if(it&&gunMap.has(it.typeId))guns.push({slot:i,id:it.typeId,name:gunMap.get(it.typeId).name});}
 if(!guns.length){message(p,'Carry a weapon to manage it.');return;}
 const f=new ActionFormData().title('EQUIPMENT / WEAPONS').body('Select a weapon in your inventory.');guns.forEach(g=>f.button(g.name+' · slot '+(g.slot+1)));
 const a=await show(p,f);if(a.canceled)return;const entry=guns[a.selection],item=c.getItem(entry.slot);if(item?.typeId!==entry.id)return;
 const g=gunMap.get(item.typeId),state=gunState(item);if(!state.uid){state.uid=p.id+':'+system.currentTick+':'+Math.random();writeGun(p,entry.slot,item,state);}
 const uid=state.uid,s=stats(g,state,ATTACHMENTS);
 const menu=new ActionFormData().title(g.name).body(`Loaded: ${state.loaded}/${s.capacity}\nCondition: ${100-Math.floor(state.wear/10)}%\n\n${Object.entries(state.attachments).map(([slot,id])=>slot+': '+ATTACHMENTS[id]?.name).join('\n')||'No fitted attachments.'}`);
 menu.button('Reload (weapon must be in hotbar)').button('Unload magazine').button('Install / replace attachment').button('Remove attachment').button('Repair · 1 Maintenance Kit').button('Recycle weapon');
 const b=await show(p,menu);if(b.canceled)return;
 const live=c.getItem(entry.slot);if(live?.typeId!==entry.id||gunState(live).uid!==uid){message(p,'Weapon moved. Reopen equipment.');return;}
 if(b.selection===0){if(entry.slot>8){message(p,'Move this weapon into your hotbar before reloading.');return;}p.selectedSlotIndex=entry.slot;reload(p);return;}
 if(b.selection===1){const st=gunState(live);const n=st.loaded;st.loaded=0;writeGun(p,entry.slot,live,st);if(n)give(p,'foundry:'+g.ammo,n);message(p,'Magazine unloaded.');return;}
 if(b.selection===4){if(!creative(p)&&!consume(p,{'foundry:maintenance_kit':1})){message(p,'You need a Field Maintenance Kit.');return;}const st=gunState(live);st.wear=0;writeGun(p,entry.slot,live,st);message(p,'Weapon repaired.');return;}
 if(b.selection===2)return fitAttachment(p,entry,uid);
 if(b.selection===3)return removeAttachment(p,entry,uid);
 if(b.selection===5)return recycleWeapon(p,entry,uid);
}
async function recycleWeapon(p,entry,uid){
 const c=inv(p),item=c.getItem(entry.slot);if(item?.typeId!==entry.id||gunState(item).uid!==uid)return;
 const plan=salvagePlan(gunState(item),ATTACHMENTS);if(!plan){message(p,'Unload the magazine before recycling.');return;}
 const form=new MessageFormData().title('RECYCLE '+gunMap.get(entry.id).name).body('This permanently removes the selected weapon.\n\nReturn: 1 Steel Plate + 1 Polymer, plus every fitted attachment. Ammunition must be unloaded first.').button1('Recycle weapon').button2('Keep weapon');
 const answer=await show(p,form);if(answer.canceled||answer.selection!==0)return;
 const live=c.getItem(entry.slot);if(live?.typeId!==entry.id||gunState(live).uid!==uid){message(p,'Weapon moved. Reopen equipment.');return;}
 const output=salvagePlan(gunState(live),ATTACHMENTS);if(!output){message(p,'Magazine changed. Unload it first.');return;}
 c.setItem(entry.slot);const r=rt(p);if(r.reload?.uid===uid)r.reload=null;r.held=false;r.burst=0;
 for(const [id,n] of Object.entries(output))give(p,id,n);message(p,'Weapon recycled; fitted attachments returned.');
}
async function fitAttachment(p,entry,uid) {
 const c=inv(p),g=gunMap.get(entry.id),totals=inventoryTotals(allItems(p));
 const choices=Object.entries(ATTACHMENTS).filter(([id,a])=>compatible(g,a)&&totals['foundry:'+id]>0);
 if(!choices.length){message(p,'No compatible attachments in inventory. Craft them at the Attachment Bench.');return;}
 const f=new ActionFormData().title('INSTALL ATTACHMENT').body('One attachment per slot. Replaced attachments are returned. Unload first when changing magazines.');choices.forEach(([id,a])=>f.button(a.name+' / '+a.slot));const a=await show(p,f);if(a.canceled)return;
 const [id,mod]=choices[a.selection],item=c.getItem(entry.slot);if(item?.typeId!==entry.id||gunState(item).uid!==uid)return;
 const st=gunState(item);if(st.attachments[mod.slot]===id){message(p,'Already installed.');return;}
 if(mod.slot==='magazine'&&st.loaded){message(p,'Unload the weapon before changing its magazine attachment.');return;}
 if(!consume(p,{['foundry:'+id]:1})){message(p,'Attachment no longer in inventory.');return;}
 const previous=st.attachments[mod.slot];st.attachments[mod.slot]=id;writeGun(p,entry.slot,item,st);recordMilestone(p,'attachments');if(previous)give(p,'foundry:'+previous);message(p,'Installed '+mod.name+'.');
}
async function removeAttachment(p,entry,uid) {
 const c=inv(p),item=c.getItem(entry.slot);if(item?.typeId!==entry.id)return;
 const choices=Object.entries(gunState(item).attachments);if(!choices.length){message(p,'No attachments installed.');return;}
 const f=new ActionFormData().title('REMOVE ATTACHMENT');choices.forEach(([slot,id])=>f.button(ATTACHMENTS[id]?.name||id));const a=await show(p,f);if(a.canceled)return;
 const live=c.getItem(entry.slot);if(live?.typeId!==entry.id||gunState(live).uid!==uid)return;
 const [slot,id]=choices[a.selection],st=gunState(live);if(st.attachments[slot]!==id)return;
 if(slot==='magazine'&&st.loaded){message(p,'Unload the weapon before removing its magazine attachment.');return;}
 delete st.attachments[slot];writeGun(p,entry.slot,live,st);give(p,'foundry:'+id);message(p,'Attachment returned.');
}
installSiege({show,give,consume,count,message});
installExperience({show,give,message,busy:p=>rt(p).ui});
